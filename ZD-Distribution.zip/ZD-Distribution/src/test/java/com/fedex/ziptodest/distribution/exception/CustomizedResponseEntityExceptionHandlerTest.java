/*package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.springframework.web.context.request.WebRequest;

public class CustomizedResponseEntityExceptionHandlerTest {
	private CustomizedResponseEntityExceptionHandler customizedResponseEntityExceptionHandler;

	@Before
	public void init() {
		customizedResponseEntityExceptionHandler = new CustomizedResponseEntityExceptionHandler();
	}

	@Test
	public void handleApplicationExceptionsTest() {
		WebRequest webRequest = Mock(WebRequest.class);
		customizedResponseEntityExceptionHandler.handleApplicationExceptions(new ApplicationException(), webRequest);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}

	private WebRequest Mock(Class<WebRequest> class1) {
		return null;
	}

	@Test
	public void invalidEpochTimeFormatExceptionTest() {
		EpochTimeFormatException epe = new EpochTimeFormatException();
		customizedResponseEntityExceptionHandler.invalidEpochTimeFormatException(epe);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}

	@Test
	public void invalidApiKeyException() {
		UnauthorizedException ue = new UnauthorizedException();
		customizedResponseEntityExceptionHandler.invalidApiKeyException(ue);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}

	@Test
	public void handleInternalServerExceptionsTest() {
		HTTPInternalServerException he = new HTTPInternalServerException();
		customizedResponseEntityExceptionHandler.handleInternalServerExceptions(he);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}
	@Test
	public void invalidNetworkExceptionTest(){
		InvalidNetworkException in=new InvalidNetworkException();
		customizedResponseEntityExceptionHandler.invalidNetworkException(in);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}
	
	@Test
	public void invalidZipCodeExceptionTest(){
		InvalidZipCodeException ie=new InvalidZipCodeException();
		customizedResponseEntityExceptionHandler.invalidZipCodeException(ie);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}
//	@Test
//	public void zipCodeNotFoundExceptionTest(){
//		ZipCodeNotFoundException zf=new ZipCodeNotFoundException();
//		customizedResponseEntityExceptionHandler.zipCodeNotFoundException(zf);
//		assertNotNull(customizedResponseEntityExceptionHandler);
//	}
	
	@Test
	public void invalidFacilityIdExceptionTest(){
		InvalidFacilityIdException ie=new InvalidFacilityIdException();
		customizedResponseEntityExceptionHandler.invalidFacilityIdException(ie);
		assertNotNull(customizedResponseEntityExceptionHandler);
	}

}
*/