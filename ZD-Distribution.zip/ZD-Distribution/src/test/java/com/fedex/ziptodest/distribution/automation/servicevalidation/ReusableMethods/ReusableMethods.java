package com.fedex.ziptodest.distribution.automation.servicevalidation.ReusableMethods;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ReusableMethods {

	/**
	 * method : rawToJSON
	 * @param res
	 * @return
	 */
	public static JsonPath rawToJSON(Response res){

		String responseString = res.asString();	
		JsonPath js = new JsonPath(responseString);
		return js;
	}

}

