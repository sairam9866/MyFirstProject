/*package com.fedex.ziptodest.distribution.service.impl;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.dao.ZipToDestHasDeltaDao;
import com.fedex.ziptodest.distribution.service.ZipToDestHasDeltaService;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.ZipToDestHasDelta;
import com.fedex.ziptodest.model.ZipToDestHasDeltaResponse;

@RunWith(SpringRunner.class)
public class ZipToDestHasDeltaServieImplTest {

	@InjectMocks
	ZipToDestHasDeltaServiceImpl zipToDestHasDeltaServiceImpl;

	@Mock
	ZipToDestHasDeltaService zipToDestHasDeltaService;

	@Mock
	ZipToDestHasDeltaDao zipToDestHasDeltaDao;
	@Mock
	ZipToDestUtil zipToDestUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void isDeltaExistTest() {
		ZipToDestHasDeltaResponse zipToDestHasDeltaResponse = new ZipToDestHasDeltaResponse();
		zipToDestHasDeltaResponse.setHasChanged(true);
		zipToDestHasDeltaResponse.setNetwork("FXG");
		String userGivenTimestamp="1572816143L";
		zipToDestHasDeltaResponse.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));
		zipToDestHasDeltaServiceImpl.isDeltaExist(Mockito.anyString(), Mockito.anyLong());
		assertNotNull(zipToDestHasDeltaResponse);
	}
	
	@Test
	public void isDeltaExistNegitiveTest(){
		@SuppressWarnings("unused")
		ZipToDestHasDelta delta=new ZipToDestHasDelta();

		ZipToDestHasDeltaResponse zipToDestHasDeltaResponse = new ZipToDestHasDeltaResponse();
		zipToDestHasDeltaResponse.setHasChanged(false);
		zipToDestHasDeltaResponse.setNetwork("FXG");
		String userGivenTimestamp="1572816143L";
		zipToDestHasDeltaResponse.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));
		
		delta=zipToDestHasDeltaDao.isDeltaExist(Mockito.anyString(), Mockito.anyLong());
		delta=null;
		
		zipToDestHasDeltaResponse=zipToDestHasDeltaServiceImpl.isDeltaExist(Mockito.anyString(), Mockito.anyLong());
		assertNotNull(zipToDestHasDeltaResponse);
		
	}
}
*/