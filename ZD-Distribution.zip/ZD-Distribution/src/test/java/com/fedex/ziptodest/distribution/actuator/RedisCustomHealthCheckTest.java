package com.fedex.ziptodest.distribution.actuator;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RedisCustomHealthCheckTest {
	@InjectMocks
	RedisCustomHealthCheck redisCustomHealthCheck;
	@Mock
	RedisConnectionFactory connectionFactory;
	
	@Mock
	RedisTemplate<?, ?> redisTemplate;

	@Test
	public void healthTest() {
		
		when(redisTemplate.getConnectionFactory()).thenReturn(connectionFactory);
		redisCustomHealthCheck.health();
		assertNotNull(redisCustomHealthCheck);
		

	}

}
