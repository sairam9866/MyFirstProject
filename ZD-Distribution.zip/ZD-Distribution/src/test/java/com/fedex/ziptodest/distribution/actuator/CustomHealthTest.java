package com.fedex.ziptodest.distribution.actuator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class CustomHealthTest {

	@InjectMocks
	CustomHealth customHealth;

	@Mock
	Map<String, Object> healthDetails;

	@Test
	public void setHealthDetailsTest() {
		customHealth.setHealthDetails(healthDetails);
		assertTrue(1<2);
	}

	@Test
	public void getHealthDetailsTest() {
		Map<String, Object> map = customHealth.getHealthDetails();
		assertNotNull(map);
	}

}
