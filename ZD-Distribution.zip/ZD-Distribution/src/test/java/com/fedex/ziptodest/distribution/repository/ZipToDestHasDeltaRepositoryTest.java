/*package com.fedex.ziptodest.distribution.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.ziptodest.distribution.repository.redis.ZipToDestHasDeltaRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

@RunWith(SpringRunner.class)
@Profile("local")
public class ZipToDestHasDeltaRepositoryTest {

	@InjectMocks
	ZipToDestHasDeltaRepository zipToDestHasDeltaRepository;

	@Mock
	ZipToDestHasDeltaRedisRepository zipToDestHasDeltaRedisRepository;

	@Mock
	private ZSetOperations<String, ZipToDestHasDelta> sortedzipToDestHasDeltaSetOperations;
	
	@Mock
	ZipToDestUtil zipToDestUtil;

	ZipToDestHasDelta zipToDestHasDelta;

	@Before
	public void init() {
		zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setLastUpdateTimestamp(1234L);
		zipToDestHasDelta.setNetwork("LPN");
		ReflectionTestUtils.setField(zipToDestHasDeltaRepository, "keyspace", "local");
	}

	@Test
	public void saveTest() {
		when(zipToDestHasDeltaRedisRepository.save(zipToDestHasDelta)).thenReturn(zipToDestHasDelta);
		ZipToDestHasDelta zipToDest = zipToDestHasDeltaRepository.save(zipToDestHasDelta);
		assertNotNull(zipToDest);

	}

	@Test
	public void isDeltaExistTest() {
		String keyspace = "local";
		ZipToDestHasDelta one = new ZipToDestHasDelta();
		ZipToDestHasDelta two = new ZipToDestHasDelta();
		one.setLastUpdateTimestamp(1234L);
		one.setNetwork("LPN");

		two.setLastUpdateTimestamp(4567L);
		two.setNetwork("LPN");

		Set<ZipToDestHasDelta> setZipToDestHasDelta = new HashSet<>();
		setZipToDestHasDelta.add(one);
		setZipToDestHasDelta.add(two);
		when(sortedzipToDestHasDeltaSetOperations.rangeByScore(
				keyspace + " - " + ZipToDestConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY, 1234L, Long.MAX_VALUE))
						.thenReturn(setZipToDestHasDelta);
		ZipToDestHasDelta delta = zipToDestHasDeltaRepository.isDeltaExist("LPN", 1234L);
		assertNotNull(delta);
	}

	@Test
	public void deleteAllTest() {
		zipToDestHasDeltaRepository.deleteAll();
		assertTrue(1<2);
	}

	@Mock
	Iterable<? extends ZipToDestHasDelta> iterableZip;

	@Test
	public void deleteAllWithParamTest() {
		zipToDestHasDeltaRepository.deleteAll(iterableZip);
		assertTrue(1<2);
	}

	@Test
	public void deleteTest() {
		zipToDestHasDeltaRepository.delete(zipToDestHasDelta);
		assertTrue(1<2);
	}

	@Test
	public void deleteByIdTest() {
		zipToDestHasDeltaRepository.deleteById("123");
		assertTrue(1<2);
	}

	@Test
	public void countTest() {
		Long valueLong = zipToDestHasDeltaRepository.count();
		assertNotNull(valueLong);
	}

	@Mock
	Iterable<String> ids;

	@Test
	public void findAllByIdTest() {
		Iterable<ZipToDestHasDelta> iterableDelta = zipToDestHasDeltaRepository.findAllById(ids);
		assertNotNull(iterableDelta);
	}

	@Test
	public void findAllTest() {
		Iterable<ZipToDestHasDelta> delta = zipToDestHasDeltaRepository.findAll();
		assertNotNull(delta);
	}

	@Test
	public void findByIdTest() {
		Optional<ZipToDestHasDelta> optinalZipToDestHasDelta = zipToDestHasDeltaRepository.findById("123");
		assertNotNull(optinalZipToDestHasDelta);

	}

	@Test
	public void existsByIdTest() {
		boolean resultBoolean = zipToDestHasDeltaRepository.existsById("123");
		assertNotNull(resultBoolean);
	}

	@Mock
	Iterable<ZipToDestHasDelta> iterableEntinty;

	@Test
	public void saveAllTest() {
		Iterable<ZipToDestHasDelta> iterableZipToDest = zipToDestHasDeltaRepository.saveAll(iterableEntinty);
		assertNotNull(iterableZipToDest);
	}

}
*/