/*package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.FacilityDelta;

public class FacilityDeltaTest {

	Long epoch = 1572816143L;
	FacilityDelta facilityDelta = new FacilityDelta();
	String toStringCheck = "FacilityDelta [id=NewId, network=LPZ, facilityId=105, zipCode=A0A, effectiveDateTime=1572816143, transactionType=A, uuId=Abcd, state=Canada]";

	@Before
	public void FacilityId_Positive() {

		facilityDelta.setState("Canada");
		facilityDelta.setTransactionType("A");
		facilityDelta.setUuId("Abcd");
		facilityDelta.setFacilityId(105);
		facilityDelta.setNetwork("LPZ");
		facilityDelta.setZipCode("A0A");
		facilityDelta.setEffectiveDateTime(epoch);
		facilityDelta.setId("NewId");

	}

	@Test
	public void TestFacilityId_Positive() {

		assertEquals("Canada", facilityDelta.getState());
		assertEquals("A", facilityDelta.getTransactionType());
		assertEquals("Abcd", facilityDelta.getUuId());
		assertNotNull(facilityDelta.getFacilityId());
		assertEquals("LPZ", facilityDelta.getNetwork());
		assertEquals("A0A", facilityDelta.getZipCode());
		assertEquals(epoch, facilityDelta.getEffectiveDateTime());
		assertEquals("NewId", facilityDelta.getId());

	}

	@Test
	public void hashCodeTest() {
		assertNotNull(facilityDelta.hashCode());
		FacilityDelta tx = new FacilityDelta();
		tx.setId(null);
		assertNotNull(tx.hashCode());

	}

	@Test
	public void toStringTest() {
		assertEquals(toStringCheck, facilityDelta.toString());
	}

	@Test
	public void equalsTest() {
		FacilityDelta secound = new FacilityDelta();
		secound.buildKey();
		secound.setEffectiveDateTime(1234L);
		secound.setFacilityId(12);
		secound.setId("OldId");
		secound.setNetwork("LPN");
		assertEquals(false, facilityDelta.equals(secound));
	}

	@Test
	public void equalsTestNullTest() {
		FacilityDelta tx = null;
		assertEquals(false, facilityDelta.equals(tx));

	}

	@Test
	public void equalsSameObjectTest() {
		assertEquals(true, facilityDelta.equals(facilityDelta));

	}

	@Test
	public void equalsNotSameObjectTest() {
		Object obj = new Object();
		assertEquals(false, facilityDelta.equals(obj));
	}

	@Test
	public void equalsIdNullTest() {

		FacilityDelta tx = new FacilityDelta();
		tx.setId(null);

		FacilityDelta ty = new FacilityDelta();
		ty.setId("12");

		assertEquals(false, tx.equals(ty));

		FacilityDelta tz = new FacilityDelta();
		tz.setId("12");
		assertEquals(true, ty.equals(tz));

		FacilityDelta ta = new FacilityDelta();
		ta.setId("34");

		assertEquals(false, ty.equals(ta));

	}
}
*/