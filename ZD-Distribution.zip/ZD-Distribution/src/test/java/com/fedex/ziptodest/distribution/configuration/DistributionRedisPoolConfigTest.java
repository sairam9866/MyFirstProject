package com.fedex.ziptodest.distribution.configuration;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import redis.embedded.RedisServer;

@RunWith(SpringRunner.class)
@Profile("local")
@ContextConfiguration(classes = DistributionRedisPoolConfig.class)
public class DistributionRedisPoolConfigTest {

	@InjectMocks
	DistributionRedisPoolConfig distributionRedisPoolConfig;

	@Before
	public void setup() {
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "redisHostName",
				"redis-12006.test8-edc-bo.redis.fedex.com");
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "redisPort", 12006);
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "redisPassword", "changeme");
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "keyspace", "local");
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "maxIdle", 300);
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "minIdle", 300);
		ReflectionTestUtils.setField(distributionRedisPoolConfig, "timeOut", 300);
	}
	
	@Test
	public void zipToDestJedisConnectionFactoryTest() {
		distributionRedisPoolConfig.zipToDestJedisConnectionFactory();
		assertTrue(1<2);
	}

	@Test
	public void testZipToDestRedisTemplate() {
		distributionRedisPoolConfig.zipToDestRedisTemplate();
		assertTrue(1<2);
	}

	@Test
	public void PoolTest() {
		distributionRedisPoolConfig.pool();
		assertTrue(1<2);
	}

	@Test
	public void zDDistributionKeyspaceConfigurationTest() {
		distributionRedisPoolConfig.zDDistributionKeyspaceConfiguration();
		assertTrue(1<2);
	}

	@Mock
	ZDDistributionKeyspaceConfiguration zDDistributionKeyspaceConfiguration;

	@Test
	public void keyValueMappingContextTest() {
		distributionRedisPoolConfig.keyValueMappingContext(zDDistributionKeyspaceConfiguration);
		assertTrue(1<2);
	}
	
	@Mock
	RedisServer redisServer;
	
	@Test
	public void closeTest() throws Exception{
		distributionRedisPoolConfig.close();
		assertTrue(1<2);
	}
	
}
