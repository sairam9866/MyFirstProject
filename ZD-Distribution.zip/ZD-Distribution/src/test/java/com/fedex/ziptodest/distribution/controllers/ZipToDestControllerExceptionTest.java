/*package com.fedex.ziptodest.distribution.controllers;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.exception.EpochTimeFormatException;
import com.fedex.ziptodest.distribution.exception.InvalidFacilityIdException;
import com.fedex.ziptodest.distribution.exception.InvalidNetworkException;
import com.fedex.ziptodest.distribution.exception.UnauthorizedException;
import com.fedex.ziptodest.distribution.service.ZipToDestService;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;

@RunWith(SpringRunner.class)
public class ZipToDestControllerExceptionTest {
	@InjectMocks
	private ZipToDestController zipToDestController;

	@Mock
	ZipToDestService zipToDestService;

	@Mock
	ZipToDestValidatorService zipToDestValidatorService;

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Test
	public void testGetAllDistributionsUnauthorizedException() {
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");
		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getAllDistributions("LPN", "A4218C67947A8"))
				.withMessage(ZipToDestConstants.MSG_API_KEY_UNAUTHORIZED);
	}

	// Start -- On hold this test cases for time being.
	@Test
	public void getAllFacilityDistributionsByNetworkUnauthorizedException() {
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");		
		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getAllFacilityDistributionsByNetwork("LPN", "A4218C67947A8"));
	}

	@Test
	public void getAllFacilityDistributionsByNetworkException() {
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		Mockito.doReturn(false).when(zipToDestValidatorService).isNetworkExist("LPNM");
		assertThatExceptionOfType(InvalidNetworkException.class).isThrownBy(() -> zipToDestController
				.getAllFacilityDistributionsByNetwork("LPNM", "l7f607f4c712a84f1fb199811ff3a22a67"));
	}	

	@Test
	public void getFacilityDistributionByIDUnauthorizedException() {		
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");
		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getFacilityDistributionByID("0011", "A4218C67947A8"));
	}

	@Test
	public void getFacilityDistributionByIdInvalidFacilityIdException() {
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidFacilityId("abcd");
		assertThatExceptionOfType(InvalidFacilityIdException.class).isThrownBy(
				() -> zipToDestController.getFacilityDistributionByID("abcd", "l7f77f456afcd24b51a145feb7d3997b84"));
	}

	@Test
	public void getTimeStampChangeUnauthorizedException() {		
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");		
		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getTimeStampChange("LPN", "1567493798", "A4218C67947A8"));
	}

	@Test
	public void getTimeStampChangeInvalidNetworkException() {		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		Mockito.doReturn(false).when(zipToDestValidatorService).isNetworkExist("LPNM");		
		assertThatExceptionOfType(InvalidNetworkException.class).isThrownBy(() -> zipToDestController
				.getTimeStampChange("LPNM", "1567493798", "l7f607f4c712a84f1fb199811ff3a22a67"));
	}

	@Test
	public void getTimeStampChangeEpochTimeFormatException() {
		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist("LPN");
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidEpochTime("0");
		
		assertThatExceptionOfType(EpochTimeFormatException.class).isThrownBy(
				() -> zipToDestController.getTimeStampChange("LPN", "0", "l7f607f4c712a84f1fb199811ff3a22a67"));
	}

	@Test
	public void getChangedDistributionsUnauthorizedException() {		
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");

		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getChangedDistributions("LPN", "1567493798", "A4218C67947A8"));
	}

	@Test
	public void getChangedDistributionsInvalidNetworkException() {		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		Mockito.doReturn(false).when(zipToDestValidatorService).isNetworkExist("LPNM");

		assertThatExceptionOfType(InvalidNetworkException.class).isThrownBy(() -> zipToDestController
				.getChangedDistributions("LPNM", "1567493798", "l7f607f4c712a84f1fb199811ff3a22a67"));
	}

	@Test
	public void getChangedDistributionsEpochTimeFormatException() {
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_SORT_X,
				"l7f607f4c712a84f1fb199811ff3a22a67");
		Mockito.doReturn(true).when(zipToDestValidatorService).isNetworkExist("LPN");
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidEpochTime("0");

		assertThatExceptionOfType(EpochTimeFormatException.class).isThrownBy(
				() -> zipToDestController.getChangedDistributions("LPN", "0", "l7f607f4c712a84f1fb199811ff3a22a67"));
	}

	@Test
	public void getDestinationUnauthorizedException() {		
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");
		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getDestination("LPN", "A0D0E5", "A4218C67947A8"));
	}

	@Test
	public void getDestinationInvalidNetworkException() {		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_DDS,
				"A4218C67947A8");
		Mockito.doReturn(false).when(zipToDestValidatorService).isNetworkExist("LPNM");
		
		assertThatExceptionOfType(InvalidNetworkException.class)
				.isThrownBy(() -> zipToDestController.getDestination("LPNM", "A0D0E5", "A4218C67947A8"));
	}	

	@Test
	public void getDeltaByFacilityIdUnauthorizedException() {		
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");

		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getDeltaByFacilityId(1234, "1567493798", "A4218C67947A8"));
	}

	@Test
	public void getDeltaByFacilityIdInvalidFacilityIdException() {
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidFacilityId(12356);

		assertThatExceptionOfType(InvalidFacilityIdException.class).isThrownBy(() -> zipToDestController
				.getDeltaByFacilityId(12356, "1567493798", "l7f77f456afcd24b51a145feb7d3997b84"));
	}

	@Test
	public void getDeltaByFacilityIdEpochTimeFormatException() {		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidFacilityId(0011);
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidEpochTime("0");

		assertThatExceptionOfType(EpochTimeFormatException.class).isThrownBy(
				() -> zipToDestController.getDeltaByFacilityId(0011, "0", "l7f77f456afcd24b51a145feb7d3997b84"));
	}

	@Test
	public void getHasDeltaByFacilityIdUnauthorizedException() {		
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidApiKey("api.key.invalid", "A4218C67947A8");
		
		assertThatExceptionOfType(UnauthorizedException.class)
				.isThrownBy(() -> zipToDestController.getHasDeltaByFacilityId(1234, "1567493798", "A4218C67947A8"));
	}

	@Test
	public void getHasDeltaByFacilityIdInvalidFacilityIdException() {		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidFacilityId(12356);
		
		assertThatExceptionOfType(InvalidFacilityIdException.class).isThrownBy(() -> zipToDestController
				.getHasDeltaByFacilityId(12356, "1567493798", "l7f77f456afcd24b51a145feb7d3997b84"));
	}

	@Test
	public void getHasDeltaByFacilityIdEpochTimeFormatException() {		
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidApiKey(ZipToDestConstants.API_KEY_LINEHAUL,
				"l7f77f456afcd24b51a145feb7d3997b84");
		Mockito.doReturn(true).when(zipToDestValidatorService).isValidFacilityId(0011);
		Mockito.doReturn(false).when(zipToDestValidatorService).isValidEpochTime("0");		
		
		assertThatExceptionOfType(EpochTimeFormatException.class).isThrownBy(
				() -> zipToDestController.getHasDeltaByFacilityId(0011, "0", "l7f77f456afcd24b51a145feb7d3997b84"));
	}

}
*/