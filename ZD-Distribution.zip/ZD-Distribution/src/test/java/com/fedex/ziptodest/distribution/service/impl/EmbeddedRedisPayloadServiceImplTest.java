/*package com.fedex.ziptodest.distribution.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fedex.ziptodest.distribution.repository.FacilityRepository;
import com.fedex.ziptodest.distribution.repository.ZipToDestHasDeltaRepository;
import com.fedex.ziptodest.distribution.repository.ZipToDestRepository;

public class EmbeddedRedisPayloadServiceImplTest {

	@InjectMocks
	private EmbeddedRedisPayloadServiceImpl embeddedRedisPayloadServiceImpl;
	
	@Mock
	ZipToDestRepository zipToDestRepository;

	@Mock
	FacilityRepository facilityRepository;

	@Mock
	ZipToDestHasDeltaRepository ZipToDestHasDeltaRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSaveDestinations() {
		embeddedRedisPayloadServiceImpl.init();
	}

}
*/