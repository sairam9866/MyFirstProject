/*package com.fedex.ziptodest.distribution.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.ziptodest.distribution.repository.redis.FacilityRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.FacilityDelta;

@RunWith(SpringRunner.class)
public class FacilityRepositoryTest {

	@InjectMocks
	FacilityRepository facilityRepository;

	@Mock
	private ZSetOperations<String, FacilityDelta> sortedFacilitySetOperations;

	@Mock
	FacilityRedisRepository facilityRedisRepository;
	
	@Mock
	ZipToDestUtil zipToDestUtil;

	List<FacilityDelta> facilityList;

	FacilityDelta facilityDelta = new FacilityDelta();

	String epochTime;

	@Before
	public void init() {
		facilityDelta.buildKey();
		facilityDelta.setEffectiveDateTime(123456L);
		facilityDelta.setFacilityId(1241);
		facilityDelta.setId("12");
		facilityDelta.setState("CA");
		facilityDelta.setTransactionType("A");
		facilityDelta.setUuId("12345");
		facilityDelta.setZipCode("100");
		ReflectionTestUtils.setField(facilityRepository, "keyspace", "local");
		epochTime = "1551863000";
		facilityList = listOfFacilityDeltas();
	}

	@Test
	public void saveTest() {
		when(facilityRedisRepository.save(facilityDelta)).thenReturn(facilityDelta);
		FacilityDelta facilityDeltaRecord = facilityRepository.save(facilityDelta);
		assertNotNull(facilityDeltaRecord);
	}

	@Test
	public void testFindById() {
		when(facilityRedisRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(facilityDelta));
		Optional<FacilityDelta> optFacility = facilityRepository.findById(1123L);
		assertNotNull(optFacility);
	}

	@Test
	public void testExistsById() {
		facilityRepository.existsById(2L);
		assertTrue(1<2);
	}

	@Test
	public void testFindAll() {
		facilityRepository.findAll();
		assertTrue(1<2);
	}

	@Test
	public void testFindAllById() {
		List<Long> ids = Arrays.asList(1132L, 1133L, 1234L);
		facilityRepository.findAllById(ids);
		assertTrue(1<2);
	}

	@Test
	public void testCount() {
		facilityRepository.count();
		assertTrue(1<2);
	}

	@Test
	public void testDeleteAll() {
		facilityRepository.deleteAll();
		assertTrue(1<2);
	}

	@Test
	public void testFindByFacilityId() {
		Set<FacilityDelta> facilitySet = new HashSet<FacilityDelta>(facilityList);
		when(sortedFacilitySetOperations.rangeByScore(Mockito.anyString(), Mockito.anyDouble(), Mockito.anyDouble()))
				.thenReturn(facilitySet);
		facilityRepository.findByFacilityId("A", 1123, Long.parseLong(epochTime));
		assertTrue(1<2);
	}

	public List<FacilityDelta> listOfFacilityDeltas() {
		FacilityDelta facilityDelta1 = new FacilityDelta();
		facilityDelta1.buildKey();
		facilityDelta1.setEffectiveDateTime(123456L);
		facilityDelta1.setFacilityId(1123);
		facilityDelta1.setId("12");
		facilityDelta1.setState("CA");
		facilityDelta1.setTransactionType("A");
		facilityDelta1.setUuId("12345");
		facilityDelta1.setZipCode("11234");

		FacilityDelta facilityDelta2 = new FacilityDelta();
		facilityDelta2.buildKey();
		facilityDelta2.setEffectiveDateTime(123457L);
		facilityDelta2.setFacilityId(1123);
		facilityDelta2.setId("12");
		facilityDelta2.setState("CA");
		facilityDelta2.setTransactionType("M");
		facilityDelta2.setUuId("12345");
		facilityDelta2.setZipCode("11236");

		FacilityDelta facilityDelta3 = new FacilityDelta();
		facilityDelta3.buildKey();
		facilityDelta3.setEffectiveDateTime(123457L);
		facilityDelta3.setFacilityId(1123);
		facilityDelta3.setId("12");
		facilityDelta3.setState("PA");
		facilityDelta3.setTransactionType("D");
		facilityDelta3.setUuId("12345");
		facilityDelta3.setZipCode("11237");

		List<FacilityDelta> deltaList = Arrays.asList(facilityDelta1, facilityDelta2, facilityDelta3);
		return deltaList;
	}

	@Mock
	Iterable<FacilityDelta> entities;

	@Test
	public void saveAllTest() {
		facilityRepository.saveAll(entities);
		assertTrue(1<2);

	}

	@Test
	public void deleteByIdTest() {
		facilityRepository.deleteById(123L);
		assertTrue(1<2);
	}

	@Test
	public void deleteTest() {
		facilityRepository.delete(facilityDelta);
		assertTrue(1<2);

	}

	@Test
	public void deleteAllTest() {
		facilityRepository.deleteAll(entities);
		assertTrue(1<2);
	}

	@Test
	public void findFacilityHasDeltaTest() {
		List<FacilityDelta> failityListReturn;

		String keyspace = "local";
		Set<FacilityDelta> facilitySet = new HashSet<FacilityDelta>(facilityList);

		FacilityDelta one = new FacilityDelta();
		FacilityDelta two = new FacilityDelta();

		one.setEffectiveDateTime(1234L);
		one.setFacilityId(12);
		one.setNetwork("LPN");
		one.setTransactionType("A");
		one.setUuId("MPHASIS-CHECK");
		one.setZipCode("12345");
		one.buildKey();

		two.setEffectiveDateTime(1234L);
		two.setFacilityId(12);
		two.setNetwork("LPN");
		two.setTransactionType("A");
		two.setUuId("MPHASIS-CHECK");
		two.setZipCode("12345");
		two.buildKey();

		facilitySet.add(one);
		facilitySet.add(two);

		when(sortedFacilitySetOperations.rangeByScore(keyspace + " - " + ZipToDestConstants.FACILITY_HASH_KEY, 1234L,
				Long.MAX_VALUE)).thenReturn(facilitySet);
		failityListReturn = facilityRepository.findFacilityHasDelta(12, 1234L);
		assertNotNull(failityListReturn);

	}

}
*/