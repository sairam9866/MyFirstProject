package com.fedex.ziptodest.distribution.automation.cucumber.stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static com.fedex.ziptodest.distribution.automation.utils.ConfigFileReader.DistributionAPIProp;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.junit.Ignore;

import com.fedex.ziptodest.distribution.automation.cucumber.SpringBootBaseIT;
import com.fedex.ziptodest.distribution.automation.servicevalidation.Resources;
import com.fedex.ziptodest.distribution.automation.servicevalidation.ReusableMethods.ReusableMethods;

@Ignore
public class DistributionAPIStepDefinition extends SpringBootBaseIT{

	Response response;
	ValidatableResponse json;
	
	Date date =new Date();
	String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
	
	String[] network = {"FDX", "LPN", "FHG"};
	
	@Given("^The base URI is up and running for Distribution for \"([^\"]*)\"$")
    public void the_base_URI_is_up_and_running_distribution(String network) {
		
		RestAssured.baseURI = DistributionAPIProp.getProperty("Distribution.lcl.byNetwork.get")+"/"+network;
    }
    
    @When("^User verifies distribution ID$")
    public void user_verifies_distribution() {
       
    	response = given().header("apiKey","l7f607f4c712a84f1fb199811ff3a22a67").contentType(ContentType.JSON).accept(ContentType.JSON).when().get();
    	
    }
    
    @Then("^User should see the status code (\\d+)$")
	public void user_should_see_the_status_code(int statuscode) {
   	
		json = response.then().assertThat().statusCode(statuscode);
		json.log().all().extract();
		
	}
    
    @And("^verify rows of Distribution API \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
   	public void verify_first_row_of_Distribution_API(String countryjson, String zipfromjson
   			, String ziptojson, String destjson, String statejson, int row) {
      	
    	response = given().header("apiKey","l7f607f4c712a84f1fb199811ff3a22a67").contentType(ContentType.JSON).accept(ContentType.JSON).when().get();
           
        List<String> rows = response.jsonPath().getList("$");
   		System.out.println("First row of Distribution API is: "+rows.get(row));
   		
   		String Country = rows.get(row).substring(0, 3);
   		System.out.println("First row country code is: "+Country);
   		assertEquals(countryjson, Country);
   		
   		String zipfrom = rows.get(row).substring(4, 15);
   		System.out.println("First row zip from is: "+zipfrom);
   		assertEquals(zipfromjson, zipfrom);
   		
   		String zipto = rows.get(row).substring(16, 27);
   		System.out.println("First row zip to is: "+zipto);
   		assertEquals(ziptojson, zipto);
   		
   		String destination = rows.get(row).substring(28, 32);
   		System.out.println("First row destination is: "+destination);
   		assertEquals(destjson, destination);
   		
   		String state = rows.get(row).substring(33, 35);
   		System.out.println("First row state code is: "+state);
   		assertEquals(statejson, state);
   	}
    
    @When("^user performs invalid request$")
	public void user_perform_invalid_request() {
   	
       response = given().header("apiKey","l7f607f4c712a84f1fb199811ff3a22a67").contentType(ContentType.JSON).accept(ContentType.JSON).when().get(DistributionAPIProp.getProperty("Distribution.lcl.byNetwork.get.invalid"));
	}
    
    @Given("^The base URI is up and running for Distribution for zipcode to network$")
    public void the_base_URI_is_up_and_running_distribution_zipcode_network() {
    	
    	RestAssured.baseURI = DistributionAPIProp.getProperty("Distribution.lcl.byZipcode.get");
    	
    }
    
    @When("^User sends network \"([^\"]*)\" and zipcode \"([^\"]*)\" to get destination$")
   	public void verify_user_sends_network_and_zipcode(String network, String zipcode) {
      	
    	response = given().header("apiKey","l7e3cec65912a94392a73b1e3ffa8957d7").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byZipcode_network+"/"+network+"/"+zipcode);
        
   	}
    
    @And("^User verify destination \"([^\"]*)\"$")
   	public void User_verify_destination(String destination) {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		String dest = js.get("destination");
		
		assertEquals(destination, dest);
        
   	}
    
    @And("^User verify message \"([^\"]*)\"$")
   	public void User_verify_message(String message) {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		String invalidmessage = js.get("message");
		
		assertEquals(message, invalidmessage);
        
   	}
    
    @When("^User sends invalid URL network \"([^\"]*)\" and zipcode \"([^\"]*)\" to get destination$")
   	public void verify_user_sends_network_and_zipcode_invalid_URL(String network, String zipcode) {
      	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byZipcode_network_invalid+"/"+network+"/"+zipcode);
        
   	}
    
    @When("^User sends facility ID \"([^\"]*)\" to get zipcode and country$")
   	public void verify_user_sends_facilityID(String facilityID) {
      	
    	response = given().header("apiKey","l7f77f456afcd24b51a145feb7d3997b84").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byFacilityID+"/"+facilityID);
        
   	}
    
    
    @And("^User should be able to verify country code \"([^\"]*)\" and location number \"([^\"]*)\"$")
   	public void User_verifies_countrycode(String countryCode, String locationNumber) {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		
		String countryCodeJson = js.get("countryCD");
		assertEquals(countryCode, countryCodeJson);
		
        String legacyLocationNumber = js.get("legacyLocationNumber");
		assertEquals(locationNumber, legacyLocationNumber);
    	
        
   	}
    
    @When("^User sends invalid facility ID \"([^\"]*)\" to get zipcode and country$")
   	public void verify_user_sends_invalid_facilityID(String facilityID) {
      	
    	response = given().header("apiKey","l7f77f456afcd24b51a145feb7d3997b84").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.byFacilityIDinvalid+"/"+facilityID);
        
   	}
    
    @When("^User sends facility ID \"([^\"]*)\" and \"([^\"]*)\" to get data$")
   	public void verify_user_sends_deltafacilityID(String facilityID, String epochTime) {
      	
    	response = given().header("apiKey","l7f77f456afcd24b51a145feb7d3997b84").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.deltabyFacilityID+"/"+facilityID+"/"+epochTime);
        
   	}
    
    @And("^Verify transaction type \"([^\"]*)\" of row \"([^\"]*)\" and zipcode \"([^\"]*)\" of \"([^\"]*)\" for \"([^\"]*)\" and \"([^\"]*)\"$")
   	public void verify_transaction_and_zipcode(String transactionType, int row, String zipcode, int arrayrow, String network, String state) {
    	
    	String transactionType_json  = response.jsonPath().getString("transactionType["+arrayrow+"]");
    	System.out.println("Transaction Type  is: "+transactionType_json);
    	assertEquals(transactionType, transactionType_json);
    	
    	String zipcode_json  = response.jsonPath().getString("changeNetworks["+arrayrow+"]."+network+"."+state+"["+row+"]");
    	System.out.println("Zipcode is: "+zipcode_json);
    	assertEquals(zipcode, zipcode_json);
      	
   	}
    
    @When("^User sends facility ID \"([^\"]*)\" and \"([^\"]*)\" to get data for delta by network$")
   	public void verify_user_sends_deltabyNetwork(String network, String epochTime) {
      	
    	response = given().header("apiKey","l7f607f4c712a84f1fb199811ff3a22a67").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.deltabyNetwork+"/"+network+"/"+epochTime);
        
   	}
    
    @And("^verify rows of Distribution API \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" for delta by network$")
   	public void verify_first_row_of_Distribution_API_deltabyNetwork(String countryjson, String zipfromjson
   			, String ziptojson, String destjson, String statejson, int row) {
           
        List<String> rows = response.jsonPath().getList("$");
   		System.out.println("First row of Distribution API is: "+rows.get(row));
   		
   		String Country = rows.get(row).substring(0, 3);
   		System.out.println("First row country code is: "+Country);
   		assertEquals(countryjson, Country);
   		
   		String zipfrom = rows.get(row).substring(4, 15);
   		System.out.println("First row zip from is: "+zipfrom);
   		assertEquals(zipfromjson, zipfrom);
   		
   		String zipto = rows.get(row).substring(16, 27);
   		System.out.println("First row zip to is: "+zipto);
   		assertEquals(ziptojson, zipto);
   		
   		String destination = rows.get(row).substring(28, 32);
   		System.out.println("First row destination is: "+destination);
   		assertEquals(destjson, destination);
   		
   		String state = rows.get(row).substring(33, 35);
   		System.out.println("First row state code is: "+state);
   		assertEquals(statejson, state);
   	}
    
    @And("^User verify has changed status \"([^\"]*)\"$")
   	public void User_verify_hasChanges_status(boolean status) {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		boolean statusJson = js.get("hasChanged");
		System.out.println("has changed status is: " +statusJson);
		
		assertEquals(status, statusJson);
		System.out.println("Boolean values are equal");
        
   	}
    
    @When("^User sends network \"([^\"]*)\" and \"([^\"]*)\" to get data for hasDelta by network$")
   	public void verify_user_sends_hasDeltabyNetwork(String network, String epochTime) {
      	
    	response = given().header("apiKey","l7f607f4c712a84f1fb199811ff3a22a67").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.hasDeltaByNetwork+"/"+network+"/"+epochTime);
        
   	}
    
    @When("^User sends facility ID \"([^\"]*)\" and \"([^\"]*)\" to get data of has delta by facility ID$")
   	public void verify_user_sends_hasdeltafacilityID(String facilityID, String epochTime) {
      	
    	response = given().header("apiKey","l7f77f456afcd24b51a145feb7d3997b84").contentType(ContentType.JSON).accept(ContentType.JSON).when().
    			   get(Resources.hasDeltaByFacilityId+"/"+facilityID+"/"+epochTime);
        
   	}
    
    @And("^User verify network and haschanged status$")
   	public void User_verify_network_hasChanges_status() {
      	
    	response = json.log().all().extract().response();
		JsonPath js = ReusableMethods.rawToJSON(response);
		
		for(int i=0; i<3; i++) {
		
			for (int j=0; j<network.length; j++){
				
				String networkJson = js.getString("hasDeltaByNetwork.network["+i+"]");
				System.out.println("Network Array is : " +networkJson);
				if(networkJson.equals(network[j]))
			    break;
			
			}
		}	
				
        
   	}
    
      
}

