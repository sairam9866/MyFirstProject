package com.fedex.ziptodest.distribution.actuator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class RestCustomEndPointTest {

	@InjectMocks
	RestCustomEndPoint restCustomEndPoint;

	@Test
	public void testCustomEndPoint() {
		assertEquals(200, restCustomEndPoint.customEndPoint().getStatusCode().value());
	}

}
