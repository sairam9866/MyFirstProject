package com.fedex.ziptodest.distribution.controllers;

import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.exception.UnauthorizedException;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

@RunWith(SpringRunner.class)
public class ZipToDestConfigsTest {
	
	@InjectMocks
	ZipToDestConfigs zipToDestConfigs;
	
	@Mock
	ConfigurableEnvironment  env;
	
	@Mock
	ZipToDestUtil zipToDestUtil;
	
	
	@Test(expected=UnauthorizedException.class)
	public void getAllPropertiesTest(){
		
		when(!zipToDestUtil.isValidApiKey(ZipToDestConstants.CONFIG_API_KEY, "someKey")).thenReturn(false);
		zipToDestConfigs.getAllProperties("someKey");	
	}

}
