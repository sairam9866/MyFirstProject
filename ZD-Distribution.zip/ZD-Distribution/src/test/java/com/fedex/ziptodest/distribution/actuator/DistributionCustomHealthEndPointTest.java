package com.fedex.ziptodest.distribution.actuator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class DistributionCustomHealthEndPointTest {

	@InjectMocks
	DistributionCustomHealthEndPoint distributionCustomHealthEndPoint;

	@Test
	public void healthTest() {
		CustomHealth customHealth = new CustomHealth();
		customHealth = distributionCustomHealthEndPoint.health();
		assertNotNull(customHealth);
	}
	
	@Test
	public void distributionCutomEndPointByNameTest(){
		String retrunString=distributionCustomHealthEndPoint.distributionCutomEndPointByName("someName");
		assertNotNull(retrunString);
	}
	
	@Test
	public void distributionWriteOperationTest(){
		distributionCustomHealthEndPoint.distributionWriteOperation("SomeName");
		assertTrue(1<2);
	}
	
	@Test
	public void distributionDeleteOperationTest(){
		distributionCustomHealthEndPoint.distributionDeleteOperation("SomeName");
		assertTrue(1<2);
	}
	
}
