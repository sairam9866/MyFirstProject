package com.fedex.ziptodest.distribution.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.model.ZipToDestination;


@RunWith(SpringRunner.class)
public class ZipToDestUtilTest {

	@InjectMocks
	private ZipToDestUtil zipToDestUtil;
	
	@Mock
	Environment environment;
	
	@SuppressWarnings("rawtypes")
	@Mock
	CsvReader csvReader;
	
	@Test
	public void testIsValidUsaZipCode() {
		assertTrue(zipToDestUtil.isValidUsaZipCode("12458"));
		assertFalse(zipToDestUtil.isValidUsaZipCode("124580"));
		assertFalse(zipToDestUtil.isValidUsaZipCode("124abc"));
		assertFalse(zipToDestUtil.isValidUsaZipCode(""));
	}

	@Test
	public void isValidCanadaZipCode() {
		assertTrue(zipToDestUtil.isValidCanadaZipCode("A0D0E5"));
		assertFalse(zipToDestUtil.isValidCanadaZipCode("12458"));
		assertFalse(zipToDestUtil.isValidCanadaZipCode("124abc"));
		assertFalse(zipToDestUtil.isValidCanadaZipCode("abxe"));
	}

	@Test
	public void testIsValidUsCanadaZipCode() {
		assertTrue(zipToDestUtil.isValidUsCanadaZipCode("A0D0E5"));
		assertTrue(zipToDestUtil.isValidUsCanadaZipCode("12458"));
		assertFalse(zipToDestUtil.isValidUsCanadaZipCode("1245"));
		assertFalse(zipToDestUtil.isValidUsCanadaZipCode("124abc"));
		assertFalse(zipToDestUtil.isValidUsCanadaZipCode("abxe"));
	}

	@Test
	public void testIsValidFacilityId() {
		assertTrue(zipToDestUtil.isValidFacilityId("1245"));
		assertTrue(zipToDestUtil.isValidFacilityId("0011"));

		assertFalse(zipToDestUtil.isValidFacilityId("abxe"));
		assertFalse(zipToDestUtil.isValidFacilityId("12589"));
		assertFalse(zipToDestUtil.isValidFacilityId("0000"));
		assertFalse(zipToDestUtil.isValidFacilityId(""));
	}

	@Test
	public void testIsValidFacilityIdNumeric() {
		assertTrue(zipToDestUtil.isValidFacilityId(1245));
		assertTrue(zipToDestUtil.isValidFacilityId(0011));

		assertFalse(zipToDestUtil.isValidFacilityId(12589));
		assertFalse(zipToDestUtil.isValidFacilityId(0000));
	}

	@Test
	public void testIsValidEpochTime() {
		assertTrue(zipToDestUtil.isValidEpochTime("1567493798"));

		assertFalse(zipToDestUtil.isValidEpochTime(""));
		assertFalse(zipToDestUtil.isValidEpochTime("-2342353"));
		assertFalse(zipToDestUtil.isValidEpochTime("5645756756756"));
		assertFalse(zipToDestUtil.isValidEpochTime("2343asdf"));

	}

	@Test
	public void testIsValidApiKey() {	
		
		Mockito.doReturn(true).when(environment).containsProperty(ZipToDestConstants.API_KEY_SORT_X);
		
		Mockito.doReturn("l7f607f4c712a84f1fb199811ff3a22a67").when(environment).getProperty(ZipToDestConstants.API_KEY_SORT_X);
		
		assertTrue(zipToDestUtil.isValidApiKey(ZipToDestConstants.API_KEY_SORT_X, "l7f607f4c712a84f1fb199811ff3a22a67"));		
		
		assertFalse(zipToDestUtil.isValidApiKey("", ""));
		assertFalse(zipToDestUtil.isValidApiKey(ZipToDestConstants.API_KEY_SORT_X, ""));
		assertFalse(zipToDestUtil.isValidApiKey("", "A4218C67947A8"));
		
		Mockito.doReturn(false).when(environment).containsProperty("api.invalid.key.xxx");
		assertFalse(zipToDestUtil.isValidApiKey("api.invalid.key.xxx", "A4218C67947A8"));	
		
	}
	
	
	@Test
	public void getZipCode(){
		assertEquals("A0A0A0", ZipToDest.getZipCode(124, "A0A0A0"));
		assertEquals("11234", ZipToDest.getZipCode(840, "11234"));
	}
	
	@Test
	public void getZipCodeNegative(){
		assertEquals("A0A0A0", ZipToDest.getZipCode(125, "A0A0A0"));
	}
	
	@Test
	public <T> void beanBuilderTestNegative(){
		@SuppressWarnings("unchecked")
		List<T> emptyList = csvReader.beanBuilderExample(ZipToDestination.class, "zipToDestFail.csv");
		assertNotNull(emptyList);
	}
	
	@Test
	public void getTimestampFromEpochTime(){
		long dateValue = ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond();
		Timestamp timeStamp = zipToDestUtil.getTimestampFromEpochTime(String.valueOf(dateValue));
		assertNotNull(timeStamp);
	}
}
