package com.fedex.ziptodest.distribution.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

@RunWith(SpringRunner.class)
public class ZipToDestValidatorServiceImplTest {

	@InjectMocks
	ZipToDestValidatorServiceImpl zipToDestValidatorService;


	@Mock
	ZipToDestUtil zipToDestUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	
	@Test
	public void testIsValidFacilityIdInteger() {
		when(zipToDestUtil.isValidFacilityId(1245)).thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidFacilityId(1245));
		assertFalse(zipToDestValidatorService.isValidFacilityId(12045));
	}

	@Test
	public void testIsValidFacilityIdString() {
		when(zipToDestUtil.isValidFacilityId("1245")).thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidFacilityId("1245"));
		assertFalse(zipToDestValidatorService.isValidFacilityId("12045"));
	}

	@Test
	public void testIsValidEpochTime() {
		when(zipToDestUtil.isValidEpochTime("1567493798")).thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidEpochTime("1567493798"));
		assertFalse(zipToDestValidatorService.isValidEpochTime("-123"));
	}

	@Test
	public void testIsValidApiKey() {
		when(zipToDestUtil.isValidApiKey(ZipToDestConstants.API_KEY_DDS, "l7e3cec65912a94392a73b1e3ffa8957d7"))
				.thenReturn(true);
		assertTrue(zipToDestValidatorService.isValidApiKey(ZipToDestConstants.API_KEY_DDS,
				"l7e3cec65912a94392a73b1e3ffa8957d7"));
		assertFalse(zipToDestValidatorService.isValidApiKey("api.key.invalid", "A4218C67947A8"));
	}
}
