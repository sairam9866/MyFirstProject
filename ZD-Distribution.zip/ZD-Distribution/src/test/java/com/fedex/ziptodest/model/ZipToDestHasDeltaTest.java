package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.ZipToDestHasDelta;

public class ZipToDestHasDeltaTest {

	ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
	ZipToDestHasDelta secound = new ZipToDestHasDelta();
	Long epoch = 1572816143L;
	String toStringCheck = "ZipToDestHasDelta [network=LPN, lastUpdateTimestamp=1572816143]";

	@Before
	public void zipToDestIntialData() {
		zipToDestHasDelta.setLastUpdateTimestamp(epoch);
		zipToDestHasDelta.setNetwork("LPN");
		zipToDestHasDelta.toString();

		secound.setLastUpdateTimestamp(1572816142L);
		secound.setNetwork("FXG");
	}

	@Test
	public void networkEpochTest() {
		Long local = zipToDestHasDelta.getLastUpdateTimestamp();
		assertNotNull(local);
		assertEquals("LPN", zipToDestHasDelta.getNetwork());

	}

	@Test
	public void toStringTest() {
		assertEquals(toStringCheck, zipToDestHasDelta.toString());
	}

	@Test
	public void hashCodeTest() {
		assertNotNull(zipToDestHasDelta.hashCode());
		ZipToDestHasDelta tx = new ZipToDestHasDelta();
		tx.setLastUpdateTimestamp(null);
		tx.setNetwork(null);
		assertNotNull(tx.hashCode());

	}

	@Test
	public void equalsTest() {

		assertEquals(false, zipToDestHasDelta.equals(secound));
	}

	@Test
	public void equalsobjectTrueTest() {
		assertEquals(false, zipToDestHasDelta.equals(new Object()));
		ZipToDestHasDelta temp = new ZipToDestHasDelta();
		assertEquals(false, secound.equals(temp));
		assertEquals(true, zipToDestHasDelta.equals(zipToDestHasDelta));
		ZipToDestHasDelta nullcheck = null;
		assertEquals(false, zipToDestHasDelta.equals(nullcheck));
		ZipToDestHasDelta allNullsCheck = new ZipToDestHasDelta();
		allNullsCheck.setLastUpdateTimestamp(null);
		allNullsCheck.setNetwork(null);
		ZipToDestHasDelta one = new ZipToDestHasDelta();

		one.setLastUpdateTimestamp(null);
		one.setNetwork(null);
		assertEquals(true, one.equals(allNullsCheck));
	}

	@Test
	public void lastUpdatedTimestampEqualsTest() {
		ZipToDestHasDelta tx = new ZipToDestHasDelta();
		tx.setLastUpdateTimestamp(null);

		ZipToDestHasDelta ty = new ZipToDestHasDelta();
		ty.setLastUpdateTimestamp(123L);

		assertEquals(false, tx.equals(ty));

		ZipToDestHasDelta tz = new ZipToDestHasDelta();
		tz.setLastUpdateTimestamp(123L);

		assertEquals(true, ty.equals(tz));

	}

	@Test
	public void networkEqualsTest() {
		ZipToDestHasDelta tx = new ZipToDestHasDelta();
		tx.setNetwork(null);

		ZipToDestHasDelta ty = new ZipToDestHasDelta();
		ty.setNetwork("FXG");

		assertEquals(false, tx.equals(ty));

		ZipToDestHasDelta tz = new ZipToDestHasDelta();
		tz.setNetwork("FXG");
		assertEquals(true, ty.equals(tz));
		
		ZipToDestHasDelta ta=new ZipToDestHasDelta();
		ta.setNetwork("LPN");
		assertEquals(false, ty.equals(ta));

	}

}
