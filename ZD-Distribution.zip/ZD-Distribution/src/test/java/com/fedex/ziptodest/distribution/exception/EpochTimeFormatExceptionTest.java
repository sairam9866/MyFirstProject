package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class EpochTimeFormatExceptionTest {

	private EpochTimeFormatException epochTimeFormatException;
	
	private EpochTimeFormatException epochTimeFormatExceptionParam;
	
	@Before
	public void init(){
		epochTimeFormatException = new EpochTimeFormatException();
		epochTimeFormatExceptionParam = new EpochTimeFormatException("Invalid Epoch Time.");
	}
	
	@Test
	public void testEpochTimeFormatException(){
		
		assertNotNull(epochTimeFormatException);
		assertNotNull(epochTimeFormatExceptionParam);
		assertNotNull(epochTimeFormatExceptionParam.getMessage());
	}
}
