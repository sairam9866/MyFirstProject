package com.fedex.ziptodest.distribution.configuration;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.data.redis.core.convert.KeyspaceConfiguration.KeyspaceSettings;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.model.ZipToDestination;

@RunWith(SpringRunner.class)
public class ZDDistributionKeyspaceConfigurationTest {
	
	@InjectMocks
	ZDDistributionKeyspaceConfiguration zDDistributionKeyspaceConfiguration;
	
	@Test
	public void getKeyspaceSettingsTest() {
		ZDDistributionKeyspaceConfiguration keySpaceConfig=new ZDDistributionKeyspaceConfiguration("local");
		KeyspaceSettings keySpace = keySpaceConfig.getKeyspaceSettings(ZipToDestination.class);
		assertEquals("{LOCAL-ZIPTODESTINATION}", keySpace.getKeyspace());
	}
}
