package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class InvalidZipCodeExceptionTest {
	private InvalidZipCodeException invalidZipCodeException;
	private InvalidZipCodeException invalidZipCodeExceptionParam;

	@Before
	public void init() {
		invalidZipCodeException = new InvalidZipCodeException();
		invalidZipCodeExceptionParam = new InvalidZipCodeException("Invalid Zipcode.");
	}

	@Test
	public void testEpochTimeFormatException() {
		assertNotNull(invalidZipCodeException);
		assertNotNull(invalidZipCodeExceptionParam);
		assertNotNull(invalidZipCodeExceptionParam.getMessage());
	}
}
