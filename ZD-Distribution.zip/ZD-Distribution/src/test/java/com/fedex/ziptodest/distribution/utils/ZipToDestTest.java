package com.fedex.ziptodest.distribution.utils;

import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import javassist.Modifier;

@RunWith(SpringRunner.class)
public class ZipToDestTest {
	@Test
	public void privateConstructorTest() throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		final Constructor<?>[] constructors=ZipToDest.class.getDeclaredConstructors();
		for(final Constructor<?> constructor:constructors){
			assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		}
		constructors[0].setAccessible(true);
		constructors[0].newInstance((Object[]) null);
	}

}
