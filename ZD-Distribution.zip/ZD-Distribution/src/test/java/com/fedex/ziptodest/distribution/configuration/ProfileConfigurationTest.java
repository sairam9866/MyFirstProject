package com.fedex.ziptodest.distribution.configuration;

import static org.junit.Assert.assertTrue;

import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@Profile("local")
@ContextConfiguration(classes = ProfileConfiguration.class)
public class ProfileConfigurationTest {

	@InjectMocks
	ProfileConfiguration profileConfiguration;

	@Test
	public void initializeApplicationPropMapTest() {
		Map<String, String> propMap = new LinkedHashMap<>();
		propMap.put("OneKey", "OneValue");

		profileConfiguration.initializeApplicationPropMap();
		assertTrue(1<2);

	}

}
