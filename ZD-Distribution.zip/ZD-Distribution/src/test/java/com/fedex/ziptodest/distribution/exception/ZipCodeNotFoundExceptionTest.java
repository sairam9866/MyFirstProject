package com.fedex.ziptodest.distribution.exception;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class ZipCodeNotFoundExceptionTest {

	@Test
	public void zipCodeNotFoundExceptionConstructorTest() {
		ZipCodeNotFoundException zipCodeNotFoundException = new ZipCodeNotFoundException();
		assertNotNull(zipCodeNotFoundException);

	}

	@Test
	public void zipCodeNotFoundExceptionTest() {
		ZipCodeNotFoundException zipCodeNotFoundException = new ZipCodeNotFoundException("ExceptionCheck");
		assertNotNull(zipCodeNotFoundException);
	}

}
