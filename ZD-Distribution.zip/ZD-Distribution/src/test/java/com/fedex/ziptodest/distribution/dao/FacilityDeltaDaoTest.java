package com.fedex.ziptodest.distribution.dao;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.utils.AppConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.FacilityDelta;

@RunWith(SpringRunner.class)
public class FacilityDeltaDaoTest {

	@InjectMocks
	FacilityDeltaDao facilityDeltaDao;

	@Mock
	private SetOperations<String, String> setOperations;
	
	@Mock
	ZipToDestUtil zipToDestUtil;
	
	@Mock
	private ZSetOperations<String, FacilityDelta> sortedFacilitySetOperations;
	
	@Mock
	HashSetOperations hashSetOperations;

	@Test
	public void findDistinctNetworkTest() {
		Set<String> network = new HashSet();
		network.add("FXG");
		network.add("FXGL");

		when(setOperations.members(zipToDestUtil.getFacilityKey("keyspace",AppConstants.NETWORKS_KEY))).thenReturn(network);
		Set<String> value=facilityDeltaDao.findDistinctNetwork();
		assertNotNull(value);
	}
	
	@Test
	public void toFacilityObjTest(){
		FacilityDelta delta=new FacilityDelta();
		
		Map<String,String> mapInput=new HashMap();
		mapInput.put("network", "FXG");
		mapInput.put("destinationTerminal", "11");
		mapInput.put("state","CA");
		mapInput.put( "effectiveDateAt", "12");
		mapInput.put("transactionType", "A");
		mapInput.put("uuid", "123");
		mapInput.put("zipCode", "121");
		
		delta=facilityDeltaDao.toFacilityObj(mapInput);
		assertNotNull(delta);
		

	}
	@Mock
	Set<FacilityDelta> facilitySet;
	@Test
	public void findFacilityHasDeltaTest(){
		Set<FacilityDelta> hashKey=new HashSet<>();
		hashKey.add(new FacilityDelta());
		when(sortedFacilitySetOperations.rangeByScore(AppConstants.FACILITY_KEY, 0, 0)).thenReturn(hashKey);
		Set<String> ids=new HashSet();
		List<Object> hashes=new ArrayList<>();
		
		when(hashSetOperations.getHashesFromRedis(ids)).thenReturn(hashes);
		
		FacilityDelta local=new FacilityDelta();
		
		when(facilitySet.add(local)).thenReturn(true);
		
		List<FacilityDelta> sentList = new ArrayList<>();
		
		sentList=facilityDeltaDao.findFacilityHasDelta(11, 12L);
		assertNotNull(sentList);
		
	}


}
