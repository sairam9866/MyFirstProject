/*package com.fedex.ziptodest.distribution.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.util.ReflectionTestUtils;

import com.fedex.ziptodest.distribution.repository.redis.ZipToDestRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants.CountryCode;
import com.fedex.ziptodest.model.ZipToDestination;

public class ZipToDestRepositoryTest {

	@InjectMocks
	private ZipToDestRepository zipToDestRepository;

	@Mock
	ZipToDestRedisRepository zipToDestRedisRepository;

	@Mock
	private SetOperations<String, String> normalzipToDestSetOperations;
	
	@Mock
	ZipToDestUtil zipToDestUtil;

	@Mock
	private ZSetOperations<String, ZipToDestination> sortedzipToDestSetOperations;

	List<ZipToDestination> destinations;

	ZipToDestination destination;
	
	String network, network1;
	
	int countryCode;
	
	String epochTime;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		destinations = listOfZipToDestination();
		destination = getDest();
		network = "LPN";
		network1= "FHDL";
		countryCode = (CountryCode.CA.getCode());
		epochTime = "1551863000";
		ReflectionTestUtils.setField(zipToDestRepository, "keyspace", "local");
	}

	@Test
	public void testFindByCountryCodeAndNetwork() {
		
		when(zipToDestRedisRepository.findByCountryCodeAndNetwork(Mockito.anyInt(), Mockito.anyString()))
				.thenReturn(destinations);
		Iterable<ZipToDestination> zipToDest = zipToDestRepository.findByCountryCodeAndNetwork(countryCode, network);
		assertNotNull(zipToDest);
	}

	@Test
	public void testFindByNetwork() {
		Sort sort = Sort.by(Sort.Order.asc("countryCode"), Sort.Order.asc("destination"), Sort.Order.asc("zipCode"));
		when(zipToDestRedisRepository.findByNetwork(Mockito.any(), Mockito.anyString())).thenReturn(destinations);
		Iterable<ZipToDestination> zipToDest = zipToDestRepository.findByNetwork(sort, network);
		assertNotNull(zipToDest);
	}

	@Test
	public void testFindByDestination() {
		when(zipToDestRedisRepository.findByDestination(Mockito.anyString())).thenReturn(destinations);
		Iterable<ZipToDestination> zipToDest = zipToDestRepository.findByDestination("1134");
		assertNotNull(zipToDest);
	}

	@Test
	public void testFindLastUpdatedTimestamp(){
		Set<ZipToDestination> destSet = new HashSet<ZipToDestination>(destinations);
		when(sortedzipToDestSetOperations.rangeByScore(Mockito.anyString(), Mockito.anyDouble(), Mockito.anyDouble())).thenReturn(destSet);
		List<ZipToDestination> zipToDest = zipToDestRepository.findLastUpdatedTimestamp(countryCode, network, Long.parseLong(epochTime));
		assertNotNull(zipToDest);
	}

	@Test
	public void testFindByNetworkAndZipCode() {
		when(zipToDestRedisRepository.findByNetworkAndZipCode(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(destination);
		ZipToDestination zipToDest = zipToDestRepository.findByNetworkAndZipCode(network1, "00123");
		assertNotNull(zipToDest);
	}

	@Test
	public void testFindDistinctNetwork() {
		Set<String> networkSet = new HashSet<>();
		Collections.addAll(networkSet, network, network1, "FXGL");
		when(normalzipToDestSetOperations.members(Mockito.anyString())).thenReturn(networkSet);
		when(zipToDestRedisRepository.findDistinctNetwork()).thenReturn(new ArrayList<String>());		
		List<String> value = zipToDestRepository.findDistinctNetwork();
		assertNotNull(value);
	}

	@Test
	public void testFindFirstByNetwork() {
		when(zipToDestRedisRepository.findFirstByNetwork(Mockito.anyString())).thenReturn(destination);
		ZipToDestination dest = zipToDestRepository.findFirstByNetwork(network1);
		assertNotNull(dest);
	}

	@Test
	public void testSave() {
		when(zipToDestRedisRepository.save(destination)).thenReturn(destination);
		ZipToDestination dest = zipToDestRepository.save(destination);
		assertNotNull(dest);
	}

	@Test
	public void testCount() {
		zipToDestRepository.count();
		assertTrue(1<2);
	}

	@Test
	public void testDelete() {
		zipToDestRepository.delete(destination);
		assertTrue(1<2);
	}

	@Test
	public void testDeleteAllIterable() {
		zipToDestRepository.deleteAll(destinations);
		assertTrue(1<2);
	}

	@Test
	public void testDeleteAll() {
		zipToDestRepository.deleteAll();
		assertTrue(1<2);
	}

	@Test
	public void testFindById() {
		when(zipToDestRedisRepository.findById(Mockito.anyString())).thenReturn(Optional.of(destination));
		Optional<ZipToDestination> optDest = zipToDestRepository.findById("12345");
		assertNotNull(optDest);
	}

	@Test
	public void testExistsById() {
		zipToDestRepository.existsById("LPN84011234");
		assertTrue(1<2);
	}

	@Test
	public void testDeleteById() {
		zipToDestRepository.deleteById("LPN84011234");
		assertTrue(1<2);
	}

	@Test
	public void testFindAll() {
		zipToDestRepository.findAll();
		assertTrue(1<2);
	}

	@Test
	public void testFindAllById(){
		List<String> ids = Arrays.asList("LPN84011234","LPN84011234");
		zipToDestRepository.findAllById(ids);
		assertTrue(1<2);
	}
	@Test
	public void testSaveAll() {
		zipToDestRepository.saveAll(destinations);
		assertTrue(1<2);
	}


	public List<ZipToDestination> listOfZipToDestination() {
		ZipToDestination dest1 = new ZipToDestination("LPN" + 124 + "A0D0B1", "LPN", 124, "A0D0B1", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest2 = new ZipToDestination("LPN" + 124 + "A0C", "LPN", 124, "A0C", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest3 = new ZipToDestination("LPN" + 124 + "A0A", "LPN", 124, "A0A", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest4 = new ZipToDestination("LPN" + 124 + "A0D0A3", "LPN", 124, "A0D0A3", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest5 = new ZipToDestination("LPN" + 124 + "A0D0A4", "LPN", 124, "A0D0A4", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest6 = new ZipToDestination("LPN" + 124 + "A0D0A5", "LPN", 124, "A0D0A5", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest7 = new ZipToDestination("LPN" + 124 + "A0D0A6", "LPN", 124, "A0D0A6", "NF", "6019",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest8 = new ZipToDestination("LPN" + 124 + "A0D0A9", "LPN", 124, "A0D0A9", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest9 = new ZipToDestination("LPN" + 124 + "A0D0B0", "LPN", 124, "A0D0B0", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest10 = new ZipToDestination("LPN" + 124 + "A0D0B1", "LPN", 124, "A0D0B1", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest11 = new ZipToDestination("LPN" + 124 + "A0B", "LPN", 124, "A0B", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest12 = new ZipToDestination("LPN" + 840 + "22401000000", "LPN", 840, "22401000000", "NF",
				"0011", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest13 = new ZipToDestination("LPN" + 840 + "22402000000", "LPN", 840, "22402000000", "NF",
				"0011", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest14 = new ZipToDestination("LPN" + 840 + "22403000000", "LPN", 840, "22403000000", "NF",
				"0011", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest15 = new ZipToDestination("LPN" + 840 + "22405000000", "LPN", 840, "22405000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest16 = new ZipToDestination("LPN" + 840 + "22406000000", "LPN", 840, "22406000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest17 = new ZipToDestination("LPN" + 840 + "22407000000", "LPN", 840, "22407000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest18 = new ZipToDestination("LPN" + 840 + "22408000000", "LPN", 840, "22408000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest19 = new ZipToDestination("LPN" + 124 + "D1A", "LPN", 124, "D1A", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest20 = new ZipToDestination("LPN" + 124 + "D1B", "LPN", 124, "D1B", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest21 = new ZipToDestination("LPN" + 124 + "V0A0A1", "LPN", 124, "V0A0A1", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest22 = new ZipToDestination("LPN" + 124 + "V0A0A2", "LPN", 124, "V0A0A2", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest23 = new ZipToDestination("LPN" + 124 + "V0B0A2", "LPN", 124, "V0B0A2", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		List<ZipToDestination> zipToDest = Arrays.asList(dest1, dest2, dest3, dest4, dest5, dest6, dest7, dest8, dest9,
				dest10, dest11, dest12, dest13, dest14, dest15, dest16, dest17, dest18, dest19, dest20, dest21, dest22,
				dest23);
		return zipToDest;
	}

	public ZipToDestination getDest() {
		ZipToDestination dest = new ZipToDestination("LPN" + 840 + "11355", "LPN", 840, "11355", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		return dest;
	}
}
*/