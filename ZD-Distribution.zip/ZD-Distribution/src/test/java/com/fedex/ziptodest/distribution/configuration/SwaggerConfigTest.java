package com.fedex.ziptodest.distribution.configuration;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.google.common.base.Predicate;

import springfox.documentation.spring.web.plugins.Docket;

@RunWith(SpringRunner.class)
public class SwaggerConfigTest {
	
	@InjectMocks
	SwaggerConfig swaggerConfig;
	
	@Mock
	Docket docket;
	
	@Mock
	Predicate<String> predicate;
	
	@Test
	public void distibutionApiTest(){
		swaggerConfig.distibutionApi();
		assertTrue(1<2);
	}
	/*@Test(expected = java.lang.AssertionError.class)
	public void postPathsTest(){
		final Method[] method=SwaggerConfig.class.getDeclaredMethods();
		for(final  Method m :method){
			assertTrue(Modifier.isPrivate(m.getModifiers()));
		}
		method[0].setAccessible(true);
		method[0].getReturnType();
	}*/

}
