package com.fedex.ziptodest.model;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.HasDeltaByNetwork;
import com.fedex.ziptodest.model.TimestampResponseDelta;

public class TimestampResponseDeltaTest {

	TimestampResponseDelta timeStampResponseDelta = new TimestampResponseDelta();
	Timestamp timeStamp = Timestamp.valueOf(LocalDateTime.now());
	List<HasDeltaByNetwork> list = new ArrayList<HasDeltaByNetwork>();

	@Before
	public void timestampResponseDelta() {

		HasDeltaByNetwork hasDeltaByNetwork = new HasDeltaByNetwork();
		hasDeltaByNetwork.setHasChanged(true);
		hasDeltaByNetwork.setNetwork("LPNN");
		list.add(hasDeltaByNetwork);
		timeStampResponseDelta.setFacilityId(101);
		timeStampResponseDelta.setTimestamp(timeStamp);
		timeStampResponseDelta.setHasDeltaByNetwork(list);

	}

	@Test
	public void timestampResponseDelta_Positive() {

		assertNotNull(timeStampResponseDelta.getHasDeltaByNetwork());
		assertEquals("LPNN", timeStampResponseDelta.getHasDeltaByNetwork().get(0).getNetwork());
		assertEquals(timeStamp, timeStampResponseDelta.getTimestamp());
		assertEquals(101, timeStampResponseDelta.getFacilityId());
		timeStampResponseDelta.toString();
	}

	@Test
	public void timestampResponseDelta_negative() {
		assertNotEquals("LPN", timeStampResponseDelta.getHasDeltaByNetwork().get(0).getNetwork());
		assertNotEquals("USA", timeStampResponseDelta.getTimestamp());
		assertNotEquals(102, timeStampResponseDelta.getFacilityId());

	}

}
