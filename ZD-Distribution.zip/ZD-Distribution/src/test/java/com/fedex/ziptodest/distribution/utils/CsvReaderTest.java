package com.fedex.ziptodest.distribution.utils;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.model.FacilityDelta;

@RunWith(SpringRunner.class)
public class CsvReaderTest {
	
	
	@SuppressWarnings("rawtypes")
	CsvReader csvReader=new CsvReader();
	
	@SuppressWarnings("unchecked")
	@Test
	public void testException(){
		List<FacilityDelta> list=csvReader.beanBuilderExample(FacilityDelta.class, "NoCSV.csv");
		assertTrue(list.isEmpty());
		
	}

}
