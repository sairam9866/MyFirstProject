package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.ZipToDestination;

/**
 * @author 3790999
 *
 */
public class ZipToDestinationTest {

	ZipToDestination zipToDest = new ZipToDestination();
	
	Long timeStamp = ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond();
	ZipToDestination zipToDest1 = new ZipToDestination("FDH"+124+"D0D","FDH", 124, "D0D","Canada","1011",timeStamp,"FedexUser2");
	
	@Before
	public void addRecord() {
		zipToDest.setDestination("6014");
		zipToDest.setLastUpdateBy("FedexUser1");
		zipToDest.setLastUpdateTimestamp(timeStamp);
		zipToDest.setState("NF");
		zipToDest.setNetwork("LPN");
		zipToDest.setCountryCode(124);
		zipToDest.setZipCode("E0E0A0");
		zipToDest.buildKey();
		zipToDest.toString();
	}

	@Test
	public void testZipToDestRecords() {
		assertEquals("6014", zipToDest.getDestination());
		assertEquals("FedexUser1", zipToDest.getLastUpdateBy());
		assertEquals(timeStamp, zipToDest.getLastUpdateTimestamp());
		assertEquals("NF", zipToDest.getState());
		assertEquals("LPN", zipToDest.getNetwork());
		assertEquals(124, zipToDest.getCountryCode());
		assertEquals("E0E0A0", zipToDest.getZipCode());
		assertEquals("FedexUser2", zipToDest1.getLastUpdateBy());
		assertEquals("FDH"+124+"D0D", zipToDest1.getId());
	}

}
