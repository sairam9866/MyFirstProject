/*package com.fedex.ziptodest.distribution.configuration;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.service.EmbeddedRedisPayloadService;

import redis.embedded.RedisServer;
import redis.embedded.RedisServerBuilder;

@RunWith(SpringRunner.class)
@Profile("local")
@ContextConfiguration(classes = RedisServerConfig.class)
public class RedisServerConfigTest {

	@InjectMocks
	RedisServerConfig redisServerConfig;
	
	@Mock
	RedisServer redisServer;

	@Mock
	ZDDistributionKeyspaceConfiguration zDDistributionKeyspaceConfiguration;

	@Mock
	RedisServerBuilder redisServerBuilder;

	@Mock
	EmbeddedRedisPayloadService embeddedRedisPayloadService;
	
	
	@Test
	public void redisTemplateTest(){
		redisServerConfig.redisTemplate();
		assertTrue(1<2);
		
	}

	@Test
	public void closeTest() throws Exception {
		redisServerConfig.close();
		assertTrue(1<2);
	}

	@Test
	public void destroyTest() {
		redisServerConfig.destroy();
		assertTrue(1<2);
	}

	@Test
	public void zDDistributionKeyspaceConfigurationTest(){
		redisServerConfig.zDDistributionKeyspaceConfiguration();
		assertTrue(1<2);
	}
	@Mock
	ZDDistributionKeyspaceConfiguration keyspaceConfiguration;
	@Test
	public void keyValueMappingContextTest(){
		redisServerConfig.keyValueMappingContext(keyspaceConfiguration);
		assertTrue(1<2);
	}

}
*/