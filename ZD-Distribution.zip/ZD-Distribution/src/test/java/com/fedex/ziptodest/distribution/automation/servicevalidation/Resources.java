package com.fedex.ziptodest.distribution.automation.servicevalidation;

public class Resources {
	
	// By zipcode and network
	public static final String byZipcode_network = "/zipToDest/distribution/byNetworkAndZipCode";
	
	// By zipcode and network invalid URL
	public static final String byZipcode_network_invalid = "/zipToDest/distribution/byNetworAnZipCode";
	
	// By network
	public static final String byNetwork = "/zipToDest/distribution/byNetwork";
	
	// By network
	public static final String byNetwork_invalid = "/zipToDest/distribution/byNtwork";
	
	// By facility ID
	public static final String byFacilityID = "/zipToDest/distribution/locationByFacilityID";
	
	// By facility ID - invalid
	public static final String byFacilityIDinvalid = "/zipToDest/distribution/locationByFailityID";
	
	//Delta by Facility Id
	public static final String deltabyFacilityID = "/zipToDest/distribution/deltaByFacilityId";
	
	//Delta by network
	public static final String deltabyNetwork = "/zipToDest/distribution/deltas/byNetwork";
	
	//hasDelta by network
	public static final String hasDeltaByNetwork = "/zipToDest/distribution/hasDelta";
	
	//hasDelta by facility id
	public static final String hasDeltaByFacilityId = "/zipToDest/distribution/hasDeltaByFacilityId";
	
	
}
