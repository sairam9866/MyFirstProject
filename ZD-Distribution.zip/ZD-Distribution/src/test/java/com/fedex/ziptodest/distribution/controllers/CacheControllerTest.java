package com.fedex.ziptodest.distribution.controllers;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.exception.UnauthorizedException;
import com.fedex.ziptodest.distribution.service.CachingService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;

@RunWith(SpringRunner.class)
public class CacheControllerTest {
	
	@InjectMocks
	CacheController cacheController;
	
	@Mock
	CachingService cachingService;
	
	@Mock
	ZipToDestUtil zipToDestUtil;
	
	@Test(expected=UnauthorizedException.class)
	public void clearAllCachesTest(){
		when(!zipToDestUtil.isValidApiKey(ZipToDestConstants.CACHE_SORTX, "someKey")).thenReturn(false);
		cacheController.clearAllCaches("someKey");
			
	}
	@Test
	public void clearAllCachesAllTest(){
		when(!zipToDestUtil.isValidApiKey(ZipToDestConstants.CACHE_SORTX, "someKey")).thenReturn(true);
		cacheController.clearAllCaches("someKey");
		assertTrue(1<2);
		
	}

}
