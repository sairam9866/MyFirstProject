package com.fedex.ziptodest.distribution.service.impl;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.distribution.dao.FacilityDeltaDao;
import com.fedex.ziptodest.distribution.dao.ZipToDestDao;
import com.fedex.ziptodest.distribution.exception.ApplicationException;
import com.fedex.ziptodest.distribution.exception.InvalidNetworkException;
import com.fedex.ziptodest.distribution.service.ZipToDestValidatorService;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.FacilityDelta;
import com.fedex.ziptodest.model.FacilityDeltaResponse;
import com.fedex.ziptodest.model.FacilityDistribution;
import com.fedex.ziptodest.model.HasDeltaByNetwork;
import com.fedex.ziptodest.model.TimestampResponseDelta;
import com.fedex.ziptodest.model.ZipToDestination;

@RunWith(SpringRunner.class)
public class ZipToDestServiceImplTest {

	@InjectMocks
	private ZipToDestServiceImpl zipToDestServiceImpl;

	@Mock
	private ZipToDestValidatorService zipToDestValidatorService;

	@Mock
	private FacilityDeltaDao facilityDeltaDao;

	@Mock
	ZipToDestDao zipToDestDao;

	@Mock
	ZipToDestUtil zipToDestUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllDistrbutions() {
		String network = "LPN";
		when(zipToDestValidatorService.isNetworkExist(Mockito.anyString())).thenReturn(true);
		zipToDestServiceImpl.getAllDistributions(network);
		assertTrue(1<2);
	}

	@Test
	public void testGetAllDistrbutionsNegative() {
		String network = "LPN";
		assertThatExceptionOfType(InvalidNetworkException.class)
				.isThrownBy(() -> zipToDestServiceImpl.getAllDistributions(network));
	}

	@Test
	public void testGetDestinationCanada() {
		String network = "LPN";
		String zipCode = "A0D0A5";
		ZipToDestination dest = new ZipToDestination("LPN" + 840 + "11355", "LPN", 840, "11355", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		when(zipToDestDao.findByNetworkAndZipCode(Mockito.anyString(), Mockito.anyString())).thenReturn(dest);
		zipToDestServiceImpl.getDestinationByNetworkAndZipCode(network, zipCode);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetDestinationUsa() {
		String network = "LPN";
		String zipCode = "11355";
		ZipToDestination dest = new ZipToDestination("LPN" + 840 + "11355", "LPN", 840, "11355", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		when(zipToDestDao.findByNetworkAndZipCode(Mockito.anyString(), Mockito.anyString())).thenReturn(dest);
		zipToDestServiceImpl.getDestinationByNetworkAndZipCode(network, zipCode);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	@Ignore
	public void testGetChangedNetworks() {
		String network = "LPN";
		Long longValue = 1568801193L;
		zipToDestServiceImpl.changedNetworks(network, longValue);
		//assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetCanadaDistributions() {
		String network = "FXG";
		zipToDestServiceImpl.getCanadaDistributions(network);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetUsaDistributions() {
		String network = "LPN";
		zipToDestServiceImpl.getUsaDistributions(network);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	public void testGetAllFacilityDistributions() {
		String network = "LPN";
		zipToDestServiceImpl.getAllFacilityDistributionsByNetwork(network);
		assertNotNull(zipToDestServiceImpl);
	}

	@Test
	@Ignore
	public void testgetFacilityDistributionsByID() {
		String facilityID = "6011";
		//when(zipToDestDao.findByDestination(facilityID)).thenReturn(listOfZipToDestination());
		FacilityDistribution facilityDistribution = zipToDestServiceImpl.getFacilityDistributionsByID(facilityID);
		assertNotNull(facilityDistribution);
		facilityDistribution = zipToDestServiceImpl.getFacilityDistributionsByID("1234");
		assertNotNull(facilityDistribution);
	}

	@Test
	public void testgetFacilityDistributionsByIDNegative() {
		String facilityID = "";
		assertThatExceptionOfType(ApplicationException.class)
				.isThrownBy(() -> zipToDestServiceImpl.getFacilityDistributionsByID(facilityID))
				.withMessage(ZipToDestConstants.MSG_INVALID_REQUEST);
	}

	@Test
	public void testGetDistributionList() {
		List<String> distributionList = zipToDestServiceImpl.getDistributionsList(listOfZipToDestination());
		assertNotNull(distributionList);
	}

	@Test
	public void testsetFacilityDistribution() {
		List<FacilityDistribution> distributionList = zipToDestServiceImpl
				.setFacilityDistributions(new ArrayList<FacilityDistribution>(), listOfZipToDestination());
		assertNotNull(distributionList);
	}

	@Test
	public void testGetDeltasByFacilityId() {
		String addTransactionType = "A";

		FacilityDelta facilityDelta = new FacilityDelta();
		facilityDelta.setNetwork("LPN");
		facilityDelta.setZipCode("1234");
		facilityDelta.setEffectiveDateTime(123L);
		facilityDelta.setFacilityId(12);
		facilityDelta.setState("ABC");
		facilityDelta.setTransactionType(addTransactionType);

		List<FacilityDelta> deltaFacilityList = new ArrayList<>();
		deltaFacilityList.add(facilityDelta);

		Long longValue = 1568801193L;
		when(facilityDeltaDao.findByFacilityId(addTransactionType, facilityDelta.getFacilityId(), longValue))
				.thenReturn(deltaFacilityList);

		List<FacilityDeltaResponse> facilityResponse = zipToDestServiceImpl
				.getDeltasByFacilityId(facilityDelta.getFacilityId(), longValue);
		assertNotNull(facilityResponse);
	}

	@Test
	public void testsetFacilityResponse() {
		String addTransactionType = "A";
		int facilityId = 1241;
		Long longValue = 1568801193L;
		List<FacilityDelta> addFacilitylist = facilityDeltaDao.findByFacilityId(addTransactionType, facilityId,
				longValue);
		FacilityDeltaResponse facilityResponseList = zipToDestServiceImpl.setFacilityResponse(addFacilitylist);
		assertNotNull(facilityResponseList);
	}

	@Test
	public void testGetHasDeltaByFacilityId() {
		Set<String> networks = new HashSet<String>();
		networks.add("FXG");
		networks.add("FXO");

		FacilityDelta facilityIdPK = new FacilityDelta();
		facilityIdPK.setNetwork("LPN");
		facilityIdPK.setNetwork("FXO");
		facilityIdPK.setZipCode("1234");

		List<FacilityDelta> hasDeltaFacilityList = new ArrayList<>();
		FacilityDelta facilityId = new FacilityDelta();
		facilityId.setState("PA");
		hasDeltaFacilityList.add(facilityId);

		when(facilityDeltaDao.findDistinctNetwork()).thenReturn(networks);
		Long longValue = 1568801193L;
		when(facilityDeltaDao.findFacilityHasDelta(1234, longValue)).thenReturn(hasDeltaFacilityList);
		assertTrue(1<2);

	}

	private List<ZipToDestination> listOfZipToDestination() {
		ZipToDestination dest1 = new ZipToDestination("LPN" + 124 + "A0D0B1", "LPN", 124, "A0D0B1", "NF", "6014",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest2 = new ZipToDestination("LPN" + 124 + "A0C", "LPN", 124, "A0C", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest3 = new ZipToDestination("LPN" + 124 + "A0A", "LPN", 124, "A0A", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest4 = new ZipToDestination("LPN" + 124 + "A0D0A3", "LPN", 124, "A0D0A3", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest5 = new ZipToDestination("LPN" + 124 + "A0D0A4", "LPN", 124, "A0D0A4", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest6 = new ZipToDestination("LPN" + 124 + "A0D0A5", "LPN", 124, "A0D0A5", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest7 = new ZipToDestination("LPN" + 124 + "A0D0A6", "LPN", 124, "A0D0A6", "NF", "6019",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest8 = new ZipToDestination("LPN" + 124 + "A0D0A9", "LPN", 124, "A0D0A9", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest9 = new ZipToDestination("LPN" + 124 + "A0D0B0", "LPN", 124, "A0D0B0", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest10 = new ZipToDestination("LPN" + 124 + "A0D0B1", "LPN", 124, "A0D0B1", "NF", "6015",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest11 = new ZipToDestination("LPN" + 124 + "A0B", "LPN", 124, "A0B", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest12 = new ZipToDestination("LPN" + 840 + "22401000000", "LPN", 840, "22401000000", "NF",
				"0011", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest13 = new ZipToDestination("LPN" + 840 + "22402000000", "LPN", 840, "22402000000", "NF",
				"0011", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest14 = new ZipToDestination("LPN" + 840 + "22403000000", "LPN", 840, "22403000000", "NF",
				"0011", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest15 = new ZipToDestination("LPN" + 840 + "22405000000", "LPN", 840, "22405000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest16 = new ZipToDestination("LPN" + 840 + "22406000000", "LPN", 840, "22406000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest17 = new ZipToDestination("LPN" + 840 + "22407000000", "LPN", 840, "22407000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest18 = new ZipToDestination("LPN" + 840 + "22408000000", "LPN", 840, "22408000000", "NF",
				"6015", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest19 = new ZipToDestination("LPN" + 124 + "D1A", "LPN", 124, "D1A", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest20 = new ZipToDestination("LPN" + 124 + "D1B", "LPN", 124, "D1B", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest21 = new ZipToDestination("LPN" + 124 + "V0A0A1", "LPN", 124, "V0A0A1", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest22 = new ZipToDestination("LPN" + 124 + "V0A0A2", "LPN", 124, "V0A0A2", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		ZipToDestination dest23 = new ZipToDestination("LPN" + 124 + "V0B0A2", "LPN", 124, "V0B0A2", "NF", "6013",
				ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), "FedexUser");
		List<ZipToDestination> zipToDest = Arrays.asList(dest1, dest2, dest3, dest4, dest5, dest6, dest7, dest8, dest9,
				dest10, dest11, dest12, dest13, dest14, dest15, dest16, dest17, dest18, dest19, dest20, dest21, dest22,
				dest23);
		return zipToDest;
	}

	@Test
	public void getHasDeltaByFacilityIdTest() {
		TimestampResponseDelta resp = new TimestampResponseDelta();

		List<FacilityDelta> hasFacilityList = new ArrayList<>();

		FacilityDelta fDelta = new FacilityDelta();
		fDelta.setEffectiveDateTime(987654321L);
		fDelta.setFacilityId(1234);
		fDelta.setNetwork("FXG");
		fDelta.setState("CA");
		fDelta.setTransactionType("M");
		fDelta.setUuId("ABCDEF");
		fDelta.setZipCode("123456");

		hasFacilityList.add(fDelta);

		HasDeltaByNetwork has = new HasDeltaByNetwork();
		has.setHasChanged(true);
		has.setNetwork("FXO");

		HasDeltaByNetwork hasD = new HasDeltaByNetwork();
		hasD.setHasChanged(true);
		hasD.setNetwork("FXG");

		List<HasDeltaByNetwork> list = new ArrayList<>();
		list.add(has);
		list.add(hasD);

		resp.setFacilityId(1234);
		resp.setHasDeltaByNetwork(list);
		String userGivenTimestamp = "123456789L";
		resp.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));

		resp = zipToDestServiceImpl.getHasDeltaByFacilityId(123, 12345L);
		assertNotNull(resp);

	}

	@Test
	public void getHasDeltaByFacilityIdDistinctNetworkTest() {
		
		Set<String> distinctNetwork =new HashSet();
		distinctNetwork.add("FXG");
		distinctNetwork.add("FXO");

		TimestampResponseDelta resp = new TimestampResponseDelta();

		List<FacilityDelta> hasFacilityList = new ArrayList<>();

		FacilityDelta fDelta = new FacilityDelta();
		fDelta.setEffectiveDateTime(987654321L);
		fDelta.setFacilityId(1234);
		fDelta.setNetwork("FXG");
		fDelta.setState("CA");
		fDelta.setTransactionType("M");
		fDelta.setUuId("ABCDEF");
		fDelta.setZipCode("123456");

		hasFacilityList.add(fDelta);

		HasDeltaByNetwork has = new HasDeltaByNetwork();
		has.setHasChanged(true);
		has.setNetwork("FXO");

		HasDeltaByNetwork hasD = new HasDeltaByNetwork();
		hasD.setHasChanged(true);
		hasD.setNetwork("FXG");

		List<HasDeltaByNetwork> list = new ArrayList<>();
		list.add(has);
		list.add(hasD);

		resp.setFacilityId(1234);
		resp.setHasDeltaByNetwork(list);
		String userGivenTimestamp = "123456789L";
		resp.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));
		
		Mockito.doReturn(distinctNetwork).when(facilityDeltaDao).findDistinctNetwork();
		resp = zipToDestServiceImpl.getHasDeltaByFacilityId(123, 12345L);
		assertNotNull(resp);

	}
	@Test
	public void getDeltaByFacilityIdTimestampNetworkDeltaTest(){
		
		Set<String> distinctNetworkTest =new HashSet<>();
		distinctNetworkTest.add("FXG");
		distinctNetworkTest.add("FXO");

		TimestampResponseDelta respTest = new TimestampResponseDelta();

		List<FacilityDelta> hasFacilityListTest = new ArrayList<>();

		FacilityDelta fDeltaTest = new FacilityDelta();
		fDeltaTest.setEffectiveDateTime(123456789L);
		fDeltaTest.setFacilityId(1234);
		fDeltaTest.setNetwork("FXG");
		fDeltaTest.setState("CA");
		fDeltaTest.setTransactionType("A");
		fDeltaTest.setUuId("CUSTOM-UUID123");
		fDeltaTest.setZipCode("123456");
		
		FacilityDelta fDeltaTestTwo = new FacilityDelta();
		fDeltaTestTwo.setEffectiveDateTime(123456780L);
		fDeltaTestTwo.setFacilityId(1234);
		fDeltaTestTwo.setNetwork("FXO");
		fDeltaTestTwo.setState("CA");
		fDeltaTestTwo.setTransactionType("D");
		fDeltaTestTwo.setUuId("CUSTOM-UUID124");
		fDeltaTestTwo.setZipCode("123456");

		
		hasFacilityListTest.add(fDeltaTest);
		hasFacilityListTest.add(fDeltaTestTwo);

		HasDeltaByNetwork hasTest = new HasDeltaByNetwork();
		hasTest.setHasChanged(true);
		hasTest.setNetwork("FXO");

		HasDeltaByNetwork hasDTest = new HasDeltaByNetwork();
		hasDTest.setHasChanged(true);
		hasDTest.setNetwork("FXG");

		List<HasDeltaByNetwork> listTest = new ArrayList<>();
		listTest.add(hasTest);
		listTest.add(hasDTest);

		respTest.setFacilityId(1234);
		respTest.setHasDeltaByNetwork(listTest);
		String userGivenTimestamp = "123456789L";
		respTest.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));
		
		HasDeltaByNetwork timeStampNetworkDelta=new HasDeltaByNetwork();
		timeStampNetworkDelta.setHasChanged(true);
		timeStampNetworkDelta.setNetwork("FXO");
		Mockito.doReturn(distinctNetworkTest).when(facilityDeltaDao).findDistinctNetwork();
		
		respTest = zipToDestServiceImpl.getHasDeltaByFacilityId(123, 123456789L);
		assertNotNull(respTest);
		
	}
}
