package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.FacilityDistribution;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

public class FacilityDistributionTest {

	Map<String, Map<String, Collection<String>>> outerMap = new HashMap<>();
	Multimap<String, String> innerMap = ArrayListMultimap.create();
	FacilityDistribution facilityDistribution = new FacilityDistribution();

	@Before
	public void testFacilityDistribution() {
		facilityDistribution.setAssignedPostalCodes(outerMap);
		facilityDistribution.setCountryCD("840");
		facilityDistribution.setLegacyLocationNumber("1234");
		facilityDistribution.setOperationType("FCLTY");
	}

	@Test
	public void testFacilityDistribution_Positive() {
		assertEquals(outerMap, facilityDistribution.getAssignedPostalCodes());
		assertEquals("840", facilityDistribution.getCountryCD());
		assertEquals("1234", facilityDistribution.getLegacyLocationNumber());
		assertEquals("FCLTY", facilityDistribution.getOperationType());

	}

	@Test
	public void testFacilityDistribution_Negative() {
		assertNotEquals("122", facilityDistribution.getAssignedPostalCodes());
		assertNotEquals("240", facilityDistribution.getCountryCD());
		assertNotEquals("1235", facilityDistribution.getLegacyLocationNumber());
		assertNotEquals("FCLT", facilityDistribution.getOperationType());
		facilityDistribution.toString();

	}

	@Test
	public void addRecords() {
		innerMap.put("PA", "12345");
		outerMap.put("FHDL", innerMap.asMap());
		FacilityDistribution facilityDistributionParameters = new FacilityDistribution("FCLTY", "840", "1234",
				outerMap);
		assertEquals("FCLTY", facilityDistributionParameters.getOperationType());
		assertEquals("840", facilityDistributionParameters.getCountryCD());
		assertEquals("1234", facilityDistributionParameters.getLegacyLocationNumber());

	}

}
