package com.fedex.ziptodest.distribution.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import javassist.Modifier;

@RunWith(SpringRunner.class)
public class ZipToDestConstantsTest {
	@Test(expected = java.lang.reflect.InvocationTargetException.class)
	public void privateConstructorTest() throws Exception {
		final Constructor<?>[] constructors = ZipToDestConstants.class.getDeclaredConstructors();
		for (final Constructor<?> constructor : constructors) {
			assertTrue(Modifier.isPrivate(constructor.getModifiers()));
		}
		constructors[0].setAccessible(true);
		constructors[0].newInstance((Object[]) null);
	}

	@Test
	public void enumTest() {
		assertEquals(124, ZipToDestConstants.CountryCode.CA.getCode());
		assertEquals(840, ZipToDestConstants.CountryCode.US.getCode());
		assertEquals(484, ZipToDestConstants.CountryCode.MX.getCode());
	}

}
