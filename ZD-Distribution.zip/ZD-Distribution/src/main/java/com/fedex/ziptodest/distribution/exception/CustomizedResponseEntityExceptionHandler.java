
package com.fedex.ziptodest.distribution.exception;

/*
 *   This is the configuration class for the Exception Handling in Spring Boot
 */
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;

@ControllerAdvice
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	private static final Logger EXCEPTION_LOGGER = LoggerFactory
			.getLogger(CustomizedResponseEntityExceptionHandler.class);

	@ExceptionHandler(ApplicationException.class)
	public final ResponseEntity<ExceptionResponse> handleApplicationExceptions(ApplicationException aex,
			WebRequest request) {
		EXCEPTION_LOGGER.info("Caught ApplicationException Type");
		ExceptionResponse exceptionResponse = new ExceptionResponse(aex.getCode(), aex.getMessage());
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(InvalidNetworkException.class)
	public final ResponseEntity<ExceptionResponse> invalidNetworkException(InvalidNetworkException exception) {		
		EXCEPTION_LOGGER.debug("Invalid Network");
		return exception(ZipToDestConstants.STATUS_CODE_INVALID_NETWORK, exception, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(InvalidZipCodeException.class)
	public final ResponseEntity<ExceptionResponse> invalidZipCodeException(InvalidZipCodeException exception) {		
		EXCEPTION_LOGGER.debug("Invalid Zipcode");
		return exception(ZipToDestConstants.STATUS_CODE_INVALID_ZIPCODE, exception, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ZipCodeNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> zipCodeNotFoundException(ZipCodeNotFoundException exception) {		
		EXCEPTION_LOGGER.debug("Zipcode not found");
		return exception(ZipToDestConstants.STATUS_CODE_INVALID_ZIPCODE, exception, HttpStatus.BAD_REQUEST);
	}	
	
	@ExceptionHandler(InvalidFacilityIdException.class)
	public final ResponseEntity<ExceptionResponse> invalidFacilityIdException(InvalidFacilityIdException exception) {		
		EXCEPTION_LOGGER.debug("Invalid Facility Id");
		return exception(ZipToDestConstants.STATUS_CODE_INVALID_FACILITY_ID, exception, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(EpochTimeFormatException.class)
	public final ResponseEntity<ExceptionResponse> invalidEpochTimeFormatException(EpochTimeFormatException exception) {		
		EXCEPTION_LOGGER.debug("Invalid Epoch value.");
		return exception(ZipToDestConstants.STATUS_CODE_INVALID_EPOCH_TIME, exception, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(UnauthorizedException.class)
	public final ResponseEntity<ExceptionResponse> invalidApiKeyException(UnauthorizedException exception) {		
		EXCEPTION_LOGGER.debug("Invalid Api Key value.");
		return exception(ZipToDestConstants.STATUS_CODE_UNAUTHORIZED, exception, HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(HTTPInternalServerException.class)
	public final ResponseEntity<ExceptionResponse> handleInternalServerExceptions(HTTPInternalServerException exception) {		
		EXCEPTION_LOGGER.debug("Internal Server Error");
		return exception(ZipToDestConstants.STATUS_CODE_INVALID_SERVER_ERROR, exception, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	private final ResponseEntity<ExceptionResponse> exception(String httpStatusMsg, Exception exception, HttpStatus httpStatus){
		return (new ResponseEntity<>(new ExceptionResponse(httpStatusMsg, exception.getMessage()), httpStatus));
	}

}
