package com.fedex.ziptodest.distribution.utils;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.model.ZipToDestHasDelta;

@Component
public class ZipToDestHasDeltaMapper {

	public ZipToDestHasDelta toZipToDestHasDelta(Map<String, String> map) {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork(map.get(AppConstants.NETWORK));

		zipToDestHasDelta.setLastUpdateTimestamp(NumberUtils.isCreatable(map.get(AppConstants.LAST_UPDATED_TIMESTAMP))
				? NumberUtils.toLong(map.get(AppConstants.LAST_UPDATED_TIMESTAMP)) : null);
		return zipToDestHasDelta;
	}

	public Map<String, String> toMap(ZipToDestHasDelta zipToDestHasDelta) {
		Map<String, String> map = new HashMap<>();
		map.put(AppConstants.NETWORK, zipToDestHasDelta.getNetwork());
		map.put(AppConstants.LAST_UPDATED_TIMESTAMP,
				stringValueOf(zipToDestHasDelta.getLastUpdateTimestamp()));
		return map;
	}
	
	public  String stringValueOf(Object object) {
		return (object == null ? "" : object.toString());
	}
}
