package com.fedex.ziptodest.distribution.service;

public interface ZipToDestValidatorService {

	public boolean isNetworkExist(String network);
	
	public boolean isValidFacilityId(int facilityId);
	
	public boolean isValidFacilityId(String facilityId);
	
	public boolean isValidEpochTime(String epochTime);
	
	public boolean isValidApiKey(String key, String value);
}
