package com.fedex.ziptodest.distribution.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.distribution.dao.ZipToDestHasDeltaDao;
import com.fedex.ziptodest.distribution.service.ZipToDestHasDeltaService;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.ZipToDestHasDelta;
import com.fedex.ziptodest.model.ZipToDestHasDeltaResponse;

@Service
public class ZipToDestHasDeltaServiceImpl implements ZipToDestHasDeltaService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestHasDeltaServiceImpl.class);

	
	@Autowired
	ZipToDestHasDeltaDao zipToDestHasDeltaDao;
	
	@Autowired
	ZipToDestUtil zipToDestUtil;

	/**
	 * @return
	 */
	@Override
	public ZipToDestHasDeltaResponse isDeltaExist(String network, Long userGivenTimestamp) {
		LOGGER.info("ZipToDestServiceImpl::isDeltaExist - Network Code : {} ", network);
		LOGGER.info("ZipToDestServiceImpl::isDeltaExist - User Given Timestamp : {} ", userGivenTimestamp);
		ZipToDestHasDeltaResponse timestampResponse = new ZipToDestHasDeltaResponse();

		ZipToDestHasDelta zipToDestHasDelta = zipToDestHasDeltaDao.isDeltaExist(network, userGivenTimestamp);

		timestampResponse.setNetwork(network);
		timestampResponse.setHasChanged(false);
		timestampResponse.setTimestamp(zipToDestUtil.getTimestampFromEpochTime(userGivenTimestamp.toString()));
		if (zipToDestHasDelta != null) {
			timestampResponse.setHasChanged(true);
		}
		LOGGER.debug("ZipToDestServiceImpl::isDeltaExist - TimestampResponse : {} ", timestampResponse);
		return timestampResponse;
	}
}
