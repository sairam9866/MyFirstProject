package com.fedex.ziptodest.distribution.service;

public interface EmbeddedRedisPayloadService {
	
	public void init();
}
