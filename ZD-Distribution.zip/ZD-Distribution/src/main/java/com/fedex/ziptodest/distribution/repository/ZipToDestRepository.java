/*package com.fedex.ziptodest.distribution.repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.distribution.repository.redis.ZipToDestRedisRepository;
import com.fedex.ziptodest.distribution.utils.ZipToDestConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.ZipToDestination;

@Repository("ZipToDestRepository")
public class ZipToDestRepository implements ZipToDestRedisRepository {

	@Value(value = "${keyspace}")
	private String keyspace;

	@Autowired
	ZipToDestRedisRepository zipToDestRedisRepository;

	@Resource(name = "zipToDestRedisTemplate")
	private ZSetOperations<String, ZipToDestination> sortedzipToDestSetOperations;

	@Resource(name = "zipToDestRedisTemplate")
	private SetOperations<String, String> normalzipToDestSetOperations;
	
	@Autowired
	ZipToDestUtil zipToDestUtil;

	public String getKeyspace() {
		return keyspace;
	}	

	@Override
	public Iterable<ZipToDestination> findByCountryCodeAndNetwork(int countryCode, String network) {

		return zipToDestRedisRepository.findByCountryCodeAndNetwork(countryCode, network);
	}

	@Override
	public Iterable<ZipToDestination> findByNetwork(Sort page, String networkID) {
		return zipToDestRedisRepository.findByNetwork(page, networkID);
	}

	@Override
	public List<ZipToDestination> findByDestination(String facilityID) {
		return zipToDestRedisRepository.findByDestination(facilityID);
	}

	@Override
	public List<ZipToDestination> findLastUpdatedTimestamp(int countryCode, String givenNetwork,
			Long userGivenTimestamp) {

		List<ZipToDestination> sentList = new ArrayList<>();
		Set<ZipToDestination> zipToDestSet = sortedzipToDestSetOperations
				.rangeByScore(zipToDestUtil.getRedisKey(keyspace, ZipToDestConstants.ZIP_TO_DEST), userGivenTimestamp, Long.MAX_VALUE);
		for (ZipToDestination sort : zipToDestSet) {

			if (sort.getCountryCode() == countryCode && sort.getNetwork().equalsIgnoreCase(givenNetwork)) {
				ZipToDestination localZipToDestination = new ZipToDestination();
				localZipToDestination.setCountryCode(sort.getCountryCode());
				localZipToDestination.setDestination(sort.getDestination());
				localZipToDestination.setId(sort.getId());
				localZipToDestination.setLastUpdateBy(sort.getLastUpdateBy());
				localZipToDestination.setLastUpdateTimestamp(sort.getLastUpdateTimestamp());
				localZipToDestination.setNetwork(sort.getNetwork());
				localZipToDestination.setState(sort.getState());
				localZipToDestination.setZipCode(sort.getZipCode());
				sentList.add(localZipToDestination);
			}
		}
		return sentList;
	}

	@Override
	public ZipToDestination findByNetworkAndZipCode(String givenNetwork, String userGivenZipCode) {
		return zipToDestRedisRepository.findByNetworkAndZipCode(givenNetwork, userGivenZipCode);
	}

	@Override
	public List<String> findDistinctNetwork() {
		Set<String> checkSet = normalzipToDestSetOperations
				.members(zipToDestUtil.getRedisKey(keyspace, ZipToDestConstants.ZIP_TO_DEST_NETWORKS));
		List<String> distinctNetworks = new ArrayList<>();
		distinctNetworks.addAll(checkSet);
		return distinctNetworks;
	}

	@Override
	public ZipToDestination findFirstByNetwork(String network) {
		return zipToDestRedisRepository.findFirstByNetwork(network);
	}

	//by using spring data redis directly saving
	@SuppressWarnings("unchecked")
	@Override
	public ZipToDestination save(ZipToDestination zipToDest) {
		normalzipToDestSetOperations.add(zipToDestUtil.getRedisKey(keyspace, ZipToDestConstants.ZIP_TO_DEST_NETWORKS),
				zipToDest.getNetwork());
		
		//hasdelta save
		sortedzipToDestSetOperations.add(zipToDestUtil.getRedisKey(keyspace, ZipToDestConstants.ZIP_TO_DEST), zipToDest,
				zipToDest.getLastUpdateTimestamp());
		return zipToDestRedisRepository.save(zipToDest);
	}

	@Override
	public long count() {
		return 0;
	}

	@Override
	public void deleteAll(Iterable<? extends ZipToDestination> entities) {
		*//** Not Used *//*
	}

	@Override
	public void deleteAll() {
		*//** Not Used *//*
	}

	@Override
	public Optional<ZipToDestination> findById(String id) {
		return zipToDestRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(String id) {
		return false;
	}

	@Override
	public void deleteById(String id) {
		*//** Not Used *//*
	}

	@Override
	public List<ZipToDestination> findAll() {
		return Collections.emptyList();
	}

	@Override
	public List<ZipToDestination> findAllById(Iterable<String> ids) {
		return Collections.emptyList();
	}

	@Override
	public <S extends ZipToDestination> List<S> saveAll(Iterable<S> entities) {
		return Collections.emptyList();
	}

	@Override
	public void delete(ZipToDestination entity) {
		*//** Not Used *//*
	}

}
*/