package com.fedex.ziptodest.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.index.Indexed;

import com.opencsv.bean.CsvBindByName;

@RedisHash
public class ZipToDestination implements Serializable {

	private static final long serialVersionUID = -8214873653043928399L;

	@Id
	private String id;

	@Indexed
	@CsvBindByName
	private String network;

	@Indexed
	@CsvBindByName
	private int countryCode;

	@Indexed
	@CsvBindByName
	private String zipCode;

	@CsvBindByName
	private String state;

	@CsvBindByName
	@Indexed
	private String destination;

	@CsvBindByName
	private Long lastUpdateTimestamp;

	@CsvBindByName
	private String lastUpdateBy;

	public ZipToDestination() {
	}

	public ZipToDestination(String id, String network, int countryCode, String zipCode, String state,
			String destination, Long lastUpdateTimestamp, String lastUpdateBy) {
		this.id = id;
		this.network = network;
		this.countryCode = countryCode;
		this.zipCode = zipCode;
		this.state = state;
		this.destination = destination;
		this.lastUpdateTimestamp = lastUpdateTimestamp;
		this.lastUpdateBy = lastUpdateBy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Long getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Long lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	public String getLastUpdateBy() {
		return lastUpdateBy;
	}

	public void setLastUpdateBy(String lastUpdateBy) {
		this.lastUpdateBy = lastUpdateBy;
	}

	@Override
	public String toString() {
		return "ZipToDestination [id=" + id + ", network=" + network + ", countryCode=" + countryCode + ", zipCode="
				+ zipCode + ", state=" + state + ", destination=" + destination + ", lastUpdateTimestamp="
				+ lastUpdateTimestamp + ", lastUpdateBy=" + lastUpdateBy + "]";
	}

	public void buildKey() {
		setId(this.network + this.countryCode + this.zipCode);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass()) {
			return false;
		}
		ZipToDestination other = (ZipToDestination) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}

		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

}
