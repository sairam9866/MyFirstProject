package com.fedex.ziptodest.distribution.configuration;

import java.io.Closeable;
import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.MappingConfiguration;
import org.springframework.data.redis.core.index.IndexConfiguration;
import org.springframework.data.redis.core.mapping.RedisMappingContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.fedex.ziptodest.distribution.service.EmbeddedRedisPayloadService;

import redis.embedded.RedisServer;
import redis.embedded.RedisServerBuilder;


@Configuration
@Profile("local")
public class RedisServerConfig implements Closeable{

	
	private static final Logger LOGGER = LoggerFactory.getLogger(RedisServerConfig.class);

	private RedisServer redisServer;
	@Autowired
	EmbeddedRedisPayloadService embeddedRedisPayloadService;
	@Value(value = "${keyspace}")
	private String keyspace;
	
	@Value(value = "${spring.redis.host}")
	private String redishost;
	@Value(value = "${spring.redis.port}")
	private String redisport;
	
	//@Bean
	JedisConnectionFactory jedisConnectionFactory() {
		return new JedisConnectionFactory();
	}

	/*@Bean("zipToDestRedisTemplate")
	RedisTemplate<?, ?> redisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
    	redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
    	redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}*/
	
	@Bean(name = "strRedisTemplate")
	RedisTemplate<?, ?> strRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());		
		redisTemplate.setHashValueSerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}
	
	
	@PostConstruct
	public void init() {
		redisServer = new RedisServerBuilder().port(Integer.parseInt(redisport)).setting("maxmemory 256M").build();
		redisServer.start();
		 if(redisServer.isActive()) embeddedRedisPayloadService.init();
	}

	@PreDestroy
	public void destroy() {
		redisServer.stop();
	}
	
	@Override
	public void close() throws IOException {
		LOGGER.info("Redis server Shutdown initiated close: {}", "...");
		redisServer.stop();
		
	}
	
	@Bean
	ZDDistributionKeyspaceConfiguration zDDistributionKeyspaceConfiguration(){
		LOGGER.info("Setting keyspace to zDDistributionKeyspaceConfiguration : {}", keyspace);
		return new ZDDistributionKeyspaceConfiguration(keyspace);
	}
	

	@Bean
	public RedisMappingContext keyValueMappingContext(ZDDistributionKeyspaceConfiguration keyspaceConfiguration){
		
		return new RedisMappingContext(
				new MappingConfiguration(new IndexConfiguration(), keyspaceConfiguration));
	}
}
