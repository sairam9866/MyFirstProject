package com.fedex.ziptodest.distribution.utils;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.model.ZipToDestination;

@Component
public class ZipToDestUtil {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestUtil.class);

	@Autowired
	Environment environment;
	
	@Value(value = "${keyspace}")
	private String keyspace;

	/**
	 * Method will return a boolean value. It checks the given zip code is a USA
	 * zip code or not. USA zipcode are numeric value and must be a five digit value.
	 * 
	 * @param zipCode Zipcode for validate.
	 * @return Returns true if zipCode is a valid USA Zipcode.
	 */
	public boolean isValidUsaZipCode(String zipCode) {
		LOGGER.debug("ZipToDestUtil::isValidUsaZipCode - Zip Code : {} ", zipCode);
		return (ZipToDestConstants.PATTERN_US_ZIP_CODE.matcher(zipCode).matches());
	}

	/**
	 * Method will return a boolean value. It checks the given zipcode is in
	 * Canadian zipcode format or not. The Canadian zip code are alpha-numeric
	 * value and five character long.
	 * 
	 * @param zipCode Zipcode for validate.
	 * @return Returns true if zipcode is a valid Canadian zipcode.
	 */
	public boolean isValidCanadaZipCode(String zipCode) {
		boolean output = false;
		LOGGER.debug("ZipToDestUtil::isValidCanadaZipCode - Zip Code : {} ", zipCode);
		output = (ZipToDestConstants.PATTERN_CANADA_ZIP_CODE.matcher(zipCode).matches());
		LOGGER.debug("ZipToDestUtil::isValidCanadaZipCode - Returning : {}", output);
		return output;
	}

	/**
	 * Return a boolean value. 
	 * Method validates the given zipcode is a USA or Canadian zipcode format. 
	 * 
	 * @param zipcode Zipcode for validate.
	 * @return Returns true if zipcode is a valid USA or Canadian zipcode.
	 */
	public boolean isValidUsCanadaZipCode(String zipCode) {
		boolean output = false;
		LOGGER.debug("ZipToDestUtil::isValidUsCanadaZipCode - Zip Code : {} ", zipCode);
		output = (isValidCanadaZipCode(zipCode) || isValidUsaZipCode(zipCode));
		LOGGER.debug("ZipToDestUtil::isValidUsCanadaZipCode - Returning : {}", output);
		return output;
	}

	/**
	 * Return a boolean value. 
	 * Method validates the given facilityId against following criteria :
	 * 1. facilityId not empty and not a null value.
	 * 2. The length of facilityId must be less than or equal to 4.
	 * 3. The facilitId must be an Integer value and minimum and maximum value should be 1 and 9999 respectively.
	 * 
	 *  
	 * @param facilityId facilityId for validate.
	 * @exception NumberFormatException if the string does not contain a parsable integer. 
	 * @return Returns true if facilityId is valid.
	 */
	public boolean isValidFacilityId(String facilityId) {
		LOGGER.debug("ZipToDestUtil::isValidFacilityId - facilityId : {} ", facilityId);
		boolean output = false;
		if (StringUtils.isNoneBlank(facilityId) && facilityId.length() <= 4) {
			try {
				int facId = Integer.parseInt(facilityId);
				if (facId > 0) {
					output = true;
				}
			} catch (Exception exception) {
				LOGGER.debug("Invalid Facility Id recieved - {} : {}", facilityId, exception.getMessage());
			}
		}
		LOGGER.debug("ZipToDestUtil::isValidFacilityId - Returning - {}", output);
		return output;
	}

	/**
	 * Validates the given facilityId is a valid FacitlityId or not.
	 * The facilityId must be a Integer value, and greater than 0 and less than or equal to 9999.
	 * 
	 * <p>Examples:
     * <blockquote><pre>
     * isValidFacilityId(1250) returns true
     * isValidFacilityId(12345) returns false
     * isValidFacilityId(0011) returns true
     * isValidFacilityId(-10) returns false
     * isValidFacilityId(0000) returns false
     * isValidFacilityId(+1234) returns true
     * </pre></blockquote>
     * </p>
	 * @param facilityId facilityId for validate.
	 * @return Returns true if facilityId is valid.
	 */
	public boolean isValidFacilityId(int facilityId) {
		boolean output = false;
		LOGGER.debug("ZipToDestUtil::isValidFacilityId - facilityId : {} ", facilityId);
		output = (facilityId > 0 && facilityId <= 9999);
		LOGGER.debug("ZipToDestUtil::isValidFacilityId - Returning : {}", output);
		return output;
	}

	/**
	 * Validates the given {@code String} argument epochTime is a valid epoch time value or not. 
	 * 
	 * @param epochTime Epoch Time value for validate.
	 * @exception  NumberFormatException  if the string does not contain a parsable {@code long}.
	 * @return Returns true if epochTime is a valid epoch time value.
	 */
	public boolean isValidEpochTime(String epochTime) {
		LOGGER.debug("ZipToDestUtil::isValidEpochTime - Ecpoch Time : {} ", epochTime);
		boolean output = false;
		try {
			if (StringUtils.isNoneBlank(epochTime)) {
				long longTime = Long.parseLong(epochTime);

				if (longTime > 0) {
					Instant instant = Instant.ofEpochSecond(longTime);
					Timestamp timestamp = Timestamp.from(instant);
					LOGGER.debug("ZipToDestUtil::isValidEpochTime - Timestamp : {}", timestamp);					
					ZonedDateTime utcZonedDateTime = ZonedDateTime.now(ZoneOffset.UTC);
					output = (instant.compareTo(utcZonedDateTime.toInstant()) <= 0);
				}
			}
		} catch (Exception exception) {
			LOGGER.debug("Invalid Epoch time format - {}", exception.getMessage());
			output = false;
		}
		LOGGER.debug("ZipToDestUtil::isValidEpochTime - Returning - {}", output);
		return output;
	}

	/**
	 * Validates the API Key. The key value pair is stored in a properties file.
	 * Spring Environment api is used to read the properties. 
	 * Method validates the given value is available in properties file using its key. 
	 * If any value found the method will return true otherwise false.
	 * A key can have multiple values separated by comma.
	 *    
	 * @param key API Key
	 * @param value User input for validate.
	 * @return Returns true if {@code value} is exists in properties file against the value of {@code key}.
	 */
	public boolean isValidApiKey(String key, String value) {
		LOGGER.debug("ZipToDestUtil::isValidApiKey - Key - {} ", key);
		LOGGER.debug("ZipToDestUtil::isValidApiKey - value - {} ", value);
		boolean output = false;
		if (isApiKeyExist(key) && StringUtils.isNoneBlank(value)) {
			for (String apiValue : environment.getProperty(key).split(",")) {
				LOGGER.debug("ZipToDestUtil::isValidApiKey - API KEY - {} ", apiValue);
				if (!output) {
					output = apiValue.equals(value);
				}else{
					break;
				}
			}
		}
		LOGGER.debug("ZipToDestUtil::isValidApiKey - Returning - {}", output);
		return output;
	}
	
	public Timestamp getTimestampFromEpochTime(String epochTime){	
		return Timestamp.valueOf(LocalDateTime.ofInstant(Instant.ofEpochSecond(Long.parseLong(epochTime)), ZoneOffset.UTC));		
	}

	/**
	 * Method validates the given key is available in properties file with value(s).
	 * 
	 * @param key API Key.
	 * @return Returns true if the {@code key} is exist in properties file with a value. 
	 */
	private boolean isApiKeyExist(String key) {
		LOGGER.debug("::isApiKeyExist - KEY : {} ", key);
		boolean output = false;
		LOGGER.debug("Checking the given key is exists in properties file with atleast a value.");
		output = (StringUtils.isNoneBlank(key) && environment.containsProperty(key)
				&& StringUtils.isNoneBlank(environment.getProperty(key)));
		LOGGER.debug("ZipToDestUtil::isApiKeyExist - Returning - {}", output);
		return output;
	}
	
	
	public String getRedisKey(String prefix, String key) {
        return (prefix + ":" + key).toUpperCase();
    }
	
	public String getFacilityKey(String keySpace, String key){
        return (keySpace + ":" + "FACILITYDELTA" + ":" + key).toUpperCase();
    }
	
	public String getFacilityHasDeltaKey(String keySpace, String key){
		return (keySpace + ":" + "FACILITYHASDELTA:" + key).toUpperCase();
    }
	
	public String zipToDestHashKey(ZipToDestination zipToDest) {
		String key = keyspace.toUpperCase() + ":" + zipToDest.getNetwork() + ":" + zipToDest.getCountryCode() + ":" + zipToDest.getDestination() + ":" + zipToDest.getZipCode() + ":" + zipToDest.getLastUpdateTimestamp();
		return key.toUpperCase();
	}
	
	public String getHasDeltaLastProcessed(String keyspace,String network, String processedat){
		return(keyspace+":FACILITYHASDELTA:"+network+":"+processedat).toUpperCase();
	}
	
	public String getCurrentByProcessedDate(String keyspace,String network, int countryCode, String processedat){
		return(keyspace+":CURRENT_RECORDS:"+network+":"+countryCode+":"+processedat).toUpperCase();
	}

}
