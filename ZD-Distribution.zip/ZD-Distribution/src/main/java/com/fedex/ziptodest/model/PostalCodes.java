package com.fedex.ziptodest.model;

import java.time.LocalDateTime;

/**
 * @author 3790999
 *
 */
public class PostalCodes {

	private LocalDateTime  effectiveTmstp;	
	private String expirationTmstp;
	private String countryCd;
	private String postalCd;
	
	public PostalCodes(){
		
	}
	
	public PostalCodes(String countryCd, LocalDateTime effectiveTmstp, String expirationTmstp, String postalCd){
		this();
		this.countryCd = countryCd;
		this.effectiveTmstp = effectiveTmstp;
		this.expirationTmstp = expirationTmstp;
		this.postalCd = postalCd;
	}
	
	public LocalDateTime getEffectiveTmstp() {
		return effectiveTmstp;
	}
	
	public String getExpirationTmstp() {
		return expirationTmstp;
	}
	
	public String getCountryCd() {
		return countryCd;
	}
	
	public String getPostalCd() {
		return postalCd;
	}
	
	public void setEffectiveTmstp(LocalDateTime effectiveTmstp) {
		this.effectiveTmstp = effectiveTmstp;
	}

	public void setExpirationTmstp(String expirationTmstp) {
		this.expirationTmstp = expirationTmstp;
	}
	
	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}
	
	public void setPostalCd(String postalCd) {
		this.postalCd = postalCd;
	}
	
}
