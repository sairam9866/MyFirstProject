package com.fedex.ziptodest.distribution.utils;

import org.apache.commons.lang3.StringUtils;

public final class ZipToDest {
	private ZipToDest() {
	}

	public static String getZipCode(int countryCode, String zipCode) {
		String output;
		if (ZipToDestConstants.CountryCode.CA.getCode() == countryCode) {
			output = zipCode;
		} else if (ZipToDestConstants.CountryCode.US.getCode() == countryCode) {
			output = StringUtils.truncate(zipCode, 5);
		} else {
			output = zipCode;
		}
		return output;
	}
}
