
package com.fedex.ziptodest.model;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ZipToDestHasDeltaResponse {
	private String network;
	private boolean hasChanged;
	
	@JsonFormat( pattern = "yyyy-MM-dd.HH:mm:ss")
	private Timestamp timestamp;

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public boolean isHasChanged() {
		return hasChanged;
	}

	public void setHasChanged(boolean hasChanged) {
		this.hasChanged = hasChanged;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "TimestampResponse [network=" + network + ", hasChanged=" + hasChanged + ", timestamp=" + timestamp
				+ "]";
	}
}
