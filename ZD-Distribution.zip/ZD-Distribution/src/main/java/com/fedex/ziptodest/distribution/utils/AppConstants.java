package com.fedex.ziptodest.distribution.utils;

public class AppConstants {
	public static final String FACILITY_KEY = "MASTERFACILITYDELTA";
	public static final String NETWORKS_KEY="NETWORK";
	
	public static final String HAS_DELTA_KEY="MASTERZIPTODESTHASDELTA";
	
	public static final String HAS_DELTA="FACILITYHASDELTA";
								
		
	public static final String NETWORK = "network";
	public static final String COUNTRY_CODE = "countryCode";	
	public static final String ZIP_CODE = "zipCode";
	public static final String STATE = "state";	
	public static final String LAST_UPDATE_BY = "creationUser";	
	public static final String LAST_UPDATE_TIME = "processedDateTime";
	public static final String DESTINATION = "destinationTerminal";
	
	public static final String EFFECTIVE_DATE_AT="effectiveDateAt";
	public static final String TRANSACTION_TYPE="transactionType";
	public static final String UUID="uuid";
	
	public static final String LAST_UPDATED_TIMESTAMP="lastUpdateTimestamp";
	
	public static final transient String PROCESSED_DT = "processedAt";
	

}
