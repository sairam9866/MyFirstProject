package com.fedex.ziptodest.distribution.utils;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.model.ZipToDestination;

@Component
public class ZipToDestMapper {

	/**
	 * @param map
	 * @return
	 */
	public ZipToDestination tozipToDestObj(Map<String, String> map) {
		ZipToDestination ziptoDest = new ZipToDestination();
		ziptoDest.setNetwork(map.get(AppConstants.NETWORK));
		ziptoDest.setCountryCode(Integer.parseInt(
				StringUtils.isEmpty(map.get(AppConstants.COUNTRY_CODE)) ? "0" : map.get(AppConstants.COUNTRY_CODE)));
		ziptoDest.setZipCode(map.get(AppConstants.ZIP_CODE));
		ziptoDest.setDestination(map.get(AppConstants.DESTINATION));
		ziptoDest.setState(map.get(AppConstants.STATE));
		ziptoDest.setLastUpdateBy(map.get(AppConstants.LAST_UPDATE_BY));
		ziptoDest.setLastUpdateTimestamp(StringUtils.isBlank(map.get(AppConstants.EFFECTIVE_DATE_AT)) ? 1L : Long.valueOf(map.get(AppConstants.EFFECTIVE_DATE_AT)));
		return ziptoDest;

	}

	public Map<String, String> toMap(ZipToDestination ziptodest) {
		Map<String, String> map = new HashMap<>();
		map.put(AppConstants.NETWORK, ziptodest.getNetwork() == null ? "NA" : ziptodest.getNetwork());
		map.put(AppConstants.COUNTRY_CODE,
				String.valueOf((ziptodest.getCountryCode() == 0 ? "NA" : ziptodest.getCountryCode())));
		map.put(AppConstants.ZIP_CODE, ziptodest.getZipCode() == null ? "NA" : ziptodest.getZipCode());
		map.put(AppConstants.DESTINATION, ziptodest.getDestination() == null ? "NA"
				: String.valueOf(Integer.parseInt(ziptodest.getDestination())));
		map.put(AppConstants.STATE, ziptodest.getState() == null ? "NA" : ziptodest.getState());
		map.put(AppConstants.LAST_UPDATE_BY, ziptodest.getLastUpdateBy() == null ? "" : ziptodest.getLastUpdateBy());
		map.put(AppConstants.EFFECTIVE_DATE_AT,
				String.valueOf(ziptodest.getLastUpdateTimestamp() == null ? "" : ziptodest.getLastUpdateTimestamp()));
		return map;

	}

}
