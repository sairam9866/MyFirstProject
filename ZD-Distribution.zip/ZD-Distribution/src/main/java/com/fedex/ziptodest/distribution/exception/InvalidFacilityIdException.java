package com.fedex.ziptodest.distribution.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidFacilityIdException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;	

	public InvalidFacilityIdException() {
		super();
	}

	public InvalidFacilityIdException(String message) {
		super(message);		
	}
}
