package com.fedex.ziptodest.model;

import java.util.Collection;
import java.util.Map;

/**
 * @author 3790999
 *
 */
public class FacilityDistribution {

	private String operationType;
	private String legacyLocationNumber;
	private String countryCD;
	private Map<String, Map<String, Collection<String>>> assignedPostalCodes;

	public FacilityDistribution() {

	}

	public FacilityDistribution(String operationType, String countryCD, String legacyLocationNumber,
			Map<String, Map<String, Collection<String>>> assignedPostalCodes) {
		this();
		this.operationType = operationType;
		this.legacyLocationNumber = legacyLocationNumber;
		this.assignedPostalCodes = assignedPostalCodes;
		this.countryCD = countryCD;
	}

	public String getOperationType() {
		return operationType;
	}

	public String getLegacyLocationNumber() {
		return legacyLocationNumber;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public void setLegacyLocationNumber(String legacyLocationNumber) {
		this.legacyLocationNumber = legacyLocationNumber;
	}

	public String getCountryCD() {
		return countryCD;
	}

	public void setCountryCD(String countryCD) {
		this.countryCD = countryCD;
	}

	public Map<String, Map<String, Collection<String>>> getAssignedPostalCodes() {
		return assignedPostalCodes;
	}

	public void setAssignedPostalCodes(Map<String, Map<String, Collection<String>>> assignedPostalCodes) {
		this.assignedPostalCodes = assignedPostalCodes;
	}

	@Override
	public String toString() {
		return "FacilityDistribution [operationType=" + operationType + ", legacyLocationNumber=" + legacyLocationNumber
				+ ", countryCD=" + countryCD + "]";
	}

}
