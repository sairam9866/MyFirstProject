package com.fedex.ziptodest.distribution.configuration;

	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.convert.KeyspaceConfiguration;

	public class ZDDistributionKeyspaceConfiguration extends KeyspaceConfiguration {

		public static final Logger LOGGER = LoggerFactory.getLogger(ZDDistributionKeyspaceConfiguration.class);
		
		@Value(value = "${keyspace}")
		private String keyspace;

		public ZDDistributionKeyspaceConfiguration(String keyspace) {
			LOGGER.info("ZDDistributionKeyspaceConfiguration Construnctor - keyspace : {}", keyspace);
			this.keyspace = keyspace;
		}

		public String getKeyspace() {
			return keyspace;
		}

		public void setKeyspace(String keyspace) {
			this.keyspace = keyspace;
		}

		@Override
		public boolean hasSettingsFor(Class<?> type) {
			return true;
		}

		@Override
		public KeyspaceSettings getKeyspaceSettings(Class<?> type) {
			LOGGER.info("getKeyspaceSettings : Keyspace : {}", getKeyspace());
			String typeName = type.getSimpleName().toUpperCase();
			return new KeyspaceSettings(type, "{"+ getKeyspace().toUpperCase() +"-"+ typeName +"}");
		}

}
