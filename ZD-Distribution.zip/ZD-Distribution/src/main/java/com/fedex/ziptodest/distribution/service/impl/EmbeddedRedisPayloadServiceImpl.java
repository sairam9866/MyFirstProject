package com.fedex.ziptodest.distribution.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.distribution.dao.ZipToDestDao;
import com.fedex.ziptodest.distribution.service.EmbeddedRedisPayloadService;
import com.fedex.ziptodest.distribution.utils.CsvReader;
import com.fedex.ziptodest.model.ZipToDestination;

@Service
@Profile("local")
public class EmbeddedRedisPayloadServiceImpl implements EmbeddedRedisPayloadService {

	public static final Logger LOGGER = LoggerFactory.getLogger(EmbeddedRedisPayloadServiceImpl.class);
	
	@Autowired
	ZipToDestDao zipToDestDao;


	@Override
	public void init() {
		saveDestinations();
	}

	public void saveDestinations() {
		LOGGER.debug("EmbeddedRedisPayloadServiceImpl::Entering saveDestinations method");
		CsvReader<ZipToDestination> csvReader = new CsvReader<>();
		List<ZipToDestination> destinations;
		try {
			destinations = csvReader.beanBuilderExample(ZipToDestination.class, "zipToDest.csv");
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::ZipToDest records fetched from CSV file");
			zipToDestDao.saveAll(destinations);
			/*for (ZipToDestination zipToDest : destinations) {
				zipToDest.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDest.buildKey();
				zipToDestRepository.save(zipToDest);
			}*/
			LOGGER.debug("EmbeddedRedisPayloadServiceImpl::ZipToDest records saved in Redis repository");
		} catch (Exception e) {
			 LOGGER.error("EmbeddedRedisPayloadServiceImpl::saveDestinations - Exception {}", e.getMessage());
		}
	}

	

}
