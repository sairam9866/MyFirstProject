package com.fedex.ziptodest.model;

import java.sql.Timestamp;
import java.util.List;

public class TimestampResponseDelta {

	private int facilityId;
	private Timestamp timestamp;
	private List<HasDeltaByNetwork> hasDeltaByNetwork;

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public List<HasDeltaByNetwork> getHasDeltaByNetwork() {
		return hasDeltaByNetwork;
	}

	public void setHasDeltaByNetwork(List<HasDeltaByNetwork> hasDeltaByNetwork) {
		this.hasDeltaByNetwork = hasDeltaByNetwork;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "TimestampResponseDelta [facilityId=" + facilityId 
				+ " timestamp= "+timestamp
				+ " hasDeltaByNetwork="+(hasDeltaByNetwork != null ? hasDeltaByNetwork.size() : null)
				+"]";
	}

	
}
