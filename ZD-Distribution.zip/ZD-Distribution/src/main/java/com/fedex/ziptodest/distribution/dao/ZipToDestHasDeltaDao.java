package com.fedex.ziptodest.distribution.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.distribution.utils.AppConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.ZipToDestHasDelta;
import com.fedex.ziptodest.model.ZipToDestination;

@Component
public class ZipToDestHasDeltaDao {
	@Value(value = "${keyspace}")
	private String keyspace;

	@Resource(name = "strRedisTemplate")
	private ZSetOperations<String, String> sortedzipToDestSetOperations;

	@Resource(name = "strRedisTemplate")
	private SetOperations<String, String> setOperations;

	@Autowired
	ZipToDestUtil zipToDestUtil;

	@Autowired
	@Qualifier("strRedisTemplate")
	public RedisTemplate<String, String> strRedisTemplate;

	@Autowired
	HashSetOperations hashSetOperations;

	@Resource(name = "strRedisTemplate")
	SetOperations<String, String> zdSetOperations;

	@SuppressWarnings("unchecked")
	public List<ZipToDestination> findLastUpdatedTimestamp(int countryCode, String givenNetwork,
			Long userGivenTimestamp) {

		List<ZipToDestination> sentList = new ArrayList<>();
		// List<ZipToDestination> zipToDestSet = new HashSet<>();
		Set<String> hashKeyIds = sortedzipToDestSetOperations.rangeByScore(
				getCurrentByProcessedDate(keyspace, givenNetwork, countryCode, AppConstants.PROCESSED_DT),
				userGivenTimestamp, Long.MAX_VALUE);// current_records

		List<Object> hashes = hashSetOperations.getHashesFromRedis(hashKeyIds);

		hashes.forEach(m -> {

			ZipToDestination local = toZipToDestHasDeltaObj((Map<String, String>) m);
			sentList.add(local);

		});

		return sentList;
	}

	public ZipToDestination toZipToDestHasDeltaObj(Map<String, String> map) {
		ZipToDestination zipToDestionation = new ZipToDestination();
		zipToDestionation.setNetwork(map.get(AppConstants.NETWORK));
		zipToDestionation.setCountryCode(Integer.parseInt(map.get(AppConstants.COUNTRY_CODE)));
		zipToDestionation.setZipCode(map.get(AppConstants.ZIP_CODE));
		zipToDestionation.setState(map.get(AppConstants.STATE));
		zipToDestionation.setDestination(map.get(AppConstants.DESTINATION));// destinationTerminal
		zipToDestionation.setLastUpdateTimestamp(Long.parseLong(map.get(AppConstants.EFFECTIVE_DATE_AT)));
		zipToDestionation.setLastUpdateBy(map.get(AppConstants.LAST_UPDATE_BY));

		return zipToDestionation;

	}

	@SuppressWarnings("unchecked")
	public ZipToDestHasDelta isDeltaExist(String network, Long userGivenTimestamp) {

		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		Set<ZipToDestHasDelta> setZipToDestHasDelta = new HashSet<>();
		Set<String> hashKeyIds = sortedzipToDestSetOperations.rangeByScore(
				getHasDeltaLastProcessed(keyspace, network, AppConstants.PROCESSED_DT), userGivenTimestamp,
				Long.MAX_VALUE);

		List<Object> hashes = hashSetOperations.getHashesFromRedis(hashKeyIds);

		if (hashes != null && !hashes.isEmpty()) {
			for (Object m : hashes) {

				ZipToDestHasDelta local = toObj((Map<String, String>) m);
				if (local.getNetwork() != null) {
					return local;
				}

			}
		}

		return zipToDestHasDelta;

	}

	public ZipToDestHasDelta toObj(Map<String, String> map) {
		ZipToDestHasDelta delta = new ZipToDestHasDelta();
		delta.setNetwork((map.get(AppConstants.NETWORK)));
		delta.setLastUpdateTimestamp(Long.parseLong(map.get(AppConstants.LAST_UPDATED_TIMESTAMP)));

		return delta;

	}


	public String getCurrentByProcessedDate(String keyspace, String network, int countryCode, String processedat) {
		return (keyspace + ":CURRENT_RECORDS:" + network + ":" + countryCode + ":" + processedat).toUpperCase();
	}

	public String getHasDeltaLastProcessed(String keyspace, String network, String processedat) {
		return (keyspace + ":FACILITYHASDELTA:" + network + ":" + processedat).toUpperCase();
	}

	
}
