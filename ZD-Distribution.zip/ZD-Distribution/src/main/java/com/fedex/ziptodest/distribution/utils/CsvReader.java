package com.fedex.ziptodest.distribution.utils;

import java.io.File;
import java.io.Reader;
import java.nio.file.Files;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.opencsv.bean.CsvToBeanBuilder;

public class CsvReader<T> {
	public static final Logger LOGGER = LoggerFactory.getLogger(CsvReader.class);

	public List<T> beanBuilderExample(Class<T> entity, String fileName) {
		try {
			File csvFile = new ClassPathResource(fileName).getFile();
			Reader reader = Files.newBufferedReader(csvFile.toPath());
			List<T> list = new CsvToBeanBuilder<T>(reader).withType(entity).build().parse();
			reader.close();
			return list;
		} catch (Exception e) {
			 LOGGER.error("CsvReader::beanBuilderExample - Exception {}", e.getMessage());
			return Collections.emptyList();
		} 
	}
}
