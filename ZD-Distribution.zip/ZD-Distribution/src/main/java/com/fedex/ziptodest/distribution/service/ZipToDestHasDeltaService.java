package com.fedex.ziptodest.distribution.service;

import com.fedex.ziptodest.model.ZipToDestHasDeltaResponse;

/**
 * 
 * @author 3818669
 *
 */
public interface ZipToDestHasDeltaService {

	public ZipToDestHasDeltaResponse isDeltaExist(String network, Long userGivenTimestamp);
}
