package com.fedex.ziptodest.model;

import java.io.Serializable;

public class FacilityDelta implements Serializable {

	private static final long serialVersionUID = 4352582551713412303L;

	private String network;
	private Integer facilityId;
	private String zipCode;
	private Long effectiveDateTime;
	private String transactionType;
	private String uuId;
	private String state;


	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public Integer getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(Integer facilityId) {
		this.facilityId = facilityId;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Long getEffectiveDateTime() {
		return effectiveDateTime;
	}

	public void setEffectiveDateTime(Long effectiveDateTime) {
		this.effectiveDateTime = effectiveDateTime;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getUuId() {
		return uuId;
	}

	public void setUuId(String uuId) {
		this.uuId = uuId;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((effectiveDateTime == null) ? 0 : effectiveDateTime.hashCode());
		result = prime * result + ((facilityId == null) ? 0 : facilityId.hashCode());
		result = prime * result + ((network == null) ? 0 : network.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((transactionType == null) ? 0 : transactionType.hashCode());
		result = prime * result + ((uuId == null) ? 0 : uuId.hashCode());
		result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FacilityDelta other = (FacilityDelta) obj;
		if (effectiveDateTime == null) {
			if (other.effectiveDateTime != null)
				return false;
		} else if (!effectiveDateTime.equals(other.effectiveDateTime))
		{
			return false;
		}
		if (facilityId == null) {
			if (other.facilityId != null)
				return false;
		} else if (!facilityId.equals(other.facilityId))
		{
			return false;
		}
		if (network == null) {
			if (other.network != null)
				return false;
		} else if (!network.equals(other.network))
		{
			return false;
		}
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
		{
			return false;
		}
		if (transactionType == null) {
			if (other.transactionType != null)
				return false;
		} else if (!transactionType.equals(other.transactionType))
		{
			return false;
		}
		if (uuId == null) {
			if (other.uuId != null)
				return false;
		} else if (!uuId.equals(other.uuId))
		{
			return false;
		}
		if (zipCode == null) {
			if (other.zipCode != null)
				return false;
		} else if (!zipCode.equals(other.zipCode))
		{
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "FacilityDelta [network=" + network + ", facilityId=" + facilityId + ", zipCode=" + zipCode
				+ ", effectiveDateTime=" + effectiveDateTime + ", transactionType=" + transactionType + ", uuId=" + uuId
				+ ", state=" + state + "]";
	}

	
}
