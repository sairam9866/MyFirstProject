package com.fedex.ziptodest.distribution.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.distribution.utils.AppConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestHasDeltaMapper;
import com.fedex.ziptodest.distribution.utils.ZipToDestMapper;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.ZipToDestHasDelta;
import com.fedex.ziptodest.model.ZipToDestination;

@Component
public class ZipToDestDao {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestDao.class);

	@Value(value = "${keyspace}")
	private String keyspace;

	@Resource(name = "strRedisTemplate")
	SetOperations<String, String> zdSetOperations;
	
	@Resource(name = "strRedisTemplate")
	public RedisTemplate<String, String> redisTemplate;

	@Autowired
	public ZipToDestUtil zipToDestUtil;

	@Autowired
	HashSetOperations hashSetOperations;

	@Autowired
	ZipToDestMapper mapper;
	
	@Autowired
	ZipToDestHasDeltaMapper zipToDestHasDeltaMapper;

	/**
	 * @param network
	 * @param countryCode
	 * @return
	 */
	public List<ZipToDestination> findByNetworkAndCountryCode(String network, int countryCode) {

		Set<String> ids = zdSetOperations.members(getNetworkCountryCodeKey(network, countryCode).toUpperCase());
		List<ZipToDestination> output = new ArrayList<>();

		List<Object> hashes = hashSetOperations.getHashesFromRedis(ids);

		// call mapper to convert result to List<ZipToDest>
		hashes.forEach(m -> {
			ZipToDestination ziptodest = mapper.tozipToDestObj((Map<String, String>) m);
			output.add(ziptodest);

		});

		return output;
	}

	/**
	 * @param network
	 * @param zipCode
	 * @return
	 */
	public ZipToDestination findByNetworkAndZipCode(String network, String zipCode) {

		Set<String> ids = zdSetOperations.members(getNetworkZipCodeKey(network, zipCode).toUpperCase());
		
		if (!ids.isEmpty()) {
			List<Object> hashes = hashSetOperations.getHashesFromRedis(ids);
			return mapper.tozipToDestObj((Map<String, String>) hashes.get(0));
		} else
			return null;

	}

	/**
	 * @param facilityId
	 * @return
	 */
	public List<ZipToDestination> findByFacilityId(String facilityId) {

		Set<String> ids = zdSetOperations.members(getFacilityIdKey(facilityId).toUpperCase());
		List<ZipToDestination> output = new ArrayList<>();

		List<Object> hashes = hashSetOperations.getHashesFromRedis(ids);

		// call mapper to convert result to List<ZipToDest>
		hashes.forEach(m -> {
			ZipToDestination ziptodest = mapper.tozipToDestObj((Map<String, String>) m);
			output.add(ziptodest);

		});

		return output;
	}

	public List<ZipToDestination> findByNetwork(String network) {

		Set<String> ids = zdSetOperations.members(getNetworkKey(network).toUpperCase());
		List<ZipToDestination> output = new ArrayList<>();

		List<Object> hashes = hashSetOperations.getHashesFromRedis(ids);

		// call mapper to convert result to List<ZipToDest>
		hashes.forEach(m -> {
			ZipToDestination ziptodest = mapper.tozipToDestObj((Map<String, String>) m);
			output.add(ziptodest);

		});

		return output;
	}

	public String getNetworkCountryCodeKey(String network, int countryCode) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network + ":" + countryCode);
	}

	public String getNetworkZipCodeKey(String network, String zipCode) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network + ":" + zipCode);
	}

	public String getFacilityIdKey(String facilityId) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + Integer.parseInt(facilityId));
	}

	public String getNetworkKey(String network) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network);
	}

	public Set<String> getZipToDestNetworks() {
		//APP_ZIPTODEST_NETWORK_KEY
		return zdSetOperations.members(zipToDestUtil.getRedisKey(keyspace, AppConstants.NETWORKS_KEY));//checked key name in zd-cache 
	}
	
	public String getFacilityHasDeltaKey(String keySpace, String key) {
		return (keySpace + ":" + "FACILITYHASDELTA:" + key).toUpperCase();
	}
	
	public boolean saveAll(List<ZipToDestination> zipToDests) {

		 redisTemplate.executePipelined(new SessionCallback<List<String>>() {
			@Override
			public List<String> execute(RedisOperations operations) throws DataAccessException {
				String zipToDestHasDeltaHash = "";
				for (ZipToDestination zipToDest : zipToDests) {

					String hashKey = zipToDestUtil.zipToDestHashKey(zipToDest);
					operations.opsForHash().putAll(hashKey, mapper.toMap(zipToDest));

					operations.opsForSet().add(getNetworkKey(zipToDest.getNetwork()).toUpperCase(), hashKey);

					operations.opsForSet().add(getNetworkZipCodeKey(zipToDest.getNetwork(), zipToDest.getZipCode()).toUpperCase(), hashKey);

					operations.opsForSet().add(getNetworkCountryCodeKey(zipToDest.getNetwork(), zipToDest.getCountryCode()).toUpperCase(), hashKey);
					
					operations.opsForSet().add(getFacilityIdKey(zipToDest.getDestination()).toUpperCase(), hashKey);
					
					operations.opsForSet().add(zipToDestUtil.getRedisKey(keyspace, AppConstants.NETWORKS_KEY).toUpperCase(), zipToDest.getNetwork());
			
					ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
					zipToDestHasDelta.setLastUpdateTimestamp(zipToDest.getLastUpdateTimestamp());
					zipToDestHasDelta.setNetwork(zipToDest.getNetwork());
					
					zipToDestHasDeltaHash = getFacilityHasDeltaKey(keyspace, zipToDest.getNetwork());
					
					operations.opsForHash().putAll(zipToDestHasDeltaHash, zipToDestHasDeltaMapper.toMap(zipToDestHasDelta));
					
					operations.opsForZSet().add(zipToDestUtil.getHasDeltaLastProcessed(keyspace,
							zipToDest.getNetwork(), AppConstants.PROCESSED_DT), zipToDestHasDeltaHash,
							zipToDest.getLastUpdateTimestamp());
					
					operations.opsForZSet()
					.add(zipToDestUtil.getCurrentByProcessedDate(keyspace, zipToDest.getNetwork(),
							zipToDest.getCountryCode(), AppConstants.PROCESSED_DT), hashKey,
							zipToDest.getLastUpdateTimestamp());
				}
				return null;
			}
		});
	return true;
}

}

