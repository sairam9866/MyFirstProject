package com.fedex.ziptodest.distribution.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.distribution.utils.AppConstants;
import com.fedex.ziptodest.distribution.utils.ZipToDestUtil;
import com.fedex.ziptodest.model.FacilityDelta;

@Component
public class FacilityDeltaDao {
	public static final Logger LOGGER = LoggerFactory.getLogger(FacilityDeltaDao.class);

	@Value(value = "${keyspace}")
	private String keyspace;

	@Resource(name = "strRedisTemplate")
	private ZSetOperations<String, String> sortedFacilitySetOperations;
	
	@Resource(name = "strRedisTemplate")
	private SetOperations<String, String> setOperations;

	@Autowired
	ZipToDestUtil zipToDestUtil;

	@Autowired
	@Qualifier("strRedisTemplate")
	public RedisTemplate<String, String> strRedisTemplate;
	
	@Autowired
	HashSetOperations hashSetOperations;

	@SuppressWarnings("unchecked")
	public List<FacilityDelta> findByFacilityId(String givenTransactionType, int givenfacilityId,
			Long userGivenTimestamp) {
		

		List<FacilityDelta> sentList = new ArrayList<>();
		Set<FacilityDelta> facilitySet = new HashSet<>();

		Set<String> hashKeyIds = sortedFacilitySetOperations.rangeByScore(
				zipToDestUtil.getRedisKey(keyspace, AppConstants.FACILITY_KEY), userGivenTimestamp, Long.MAX_VALUE);

		List<Object> hashes = hashSetOperations.getHashesFromRedis(hashKeyIds);

		hashes.forEach(m -> {

			FacilityDelta local = toFacilityObj((Map<String, String>) m);
			facilitySet.add(local);

		});

		for (FacilityDelta delta : facilitySet) { // transaction type sorting
			if (delta.getTransactionType().equalsIgnoreCase(givenTransactionType)
					&& delta.getFacilityId() == givenfacilityId) {
				FacilityDelta facilityDelta = new FacilityDelta();
				facilityDelta.setNetwork(delta.getNetwork());
				facilityDelta.setFacilityId(delta.getFacilityId());
				facilityDelta.setZipCode(delta.getZipCode());
				facilityDelta.setEffectiveDateTime(delta.getEffectiveDateTime());
				facilityDelta.setState(delta.getState());
				facilityDelta.setTransactionType(delta.getTransactionType());
				facilityDelta.setUuId(delta.getUuId());
				sentList.add(facilityDelta);
			}
		}
		return sentList;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<FacilityDelta> findFacilityHasDelta(int givenfacilityId, Long userGivenTimestamp) {
		
		List<FacilityDelta> sentList = new ArrayList<>();
		Set<FacilityDelta> facilitySet = new HashSet<>(); 
		
		Set<String> hashKeyIds= sortedFacilitySetOperations.rangeByScore(
				zipToDestUtil.getRedisKey(keyspace, AppConstants.FACILITY_KEY), userGivenTimestamp, Long.MAX_VALUE);
		
		
		List<Object> hashes = hashSetOperations.getHashesFromRedis(hashKeyIds);
		
		hashes.forEach(m -> {

			FacilityDelta local = toFacilityObj((Map<String, String>) m);
			facilitySet.add(local);

		});

		for (FacilityDelta delta : facilitySet) {
			if (delta.getFacilityId() == givenfacilityId) {
				FacilityDelta facilityDelta = new FacilityDelta();
				facilityDelta.setNetwork(delta.getNetwork());
				facilityDelta.setFacilityId(delta.getFacilityId());
				facilityDelta.setZipCode(delta.getZipCode());
				facilityDelta.setEffectiveDateTime(delta.getEffectiveDateTime());
				facilityDelta.setState(delta.getState());
				facilityDelta.setTransactionType(delta.getTransactionType());
				facilityDelta.setUuId(delta.getUuId());
				sentList.add(facilityDelta);
			}
		}
		return sentList;
	}

	

	public FacilityDelta toFacilityObj(Map<String, String> map) {
		FacilityDelta facilityDelta = new FacilityDelta();

		facilityDelta.setNetwork(map.get(AppConstants.NETWORK));
		facilityDelta.setFacilityId(Integer.parseInt(map.get(AppConstants.DESTINATION)));
		facilityDelta.setState(map.get(AppConstants.STATE));
		facilityDelta.setEffectiveDateTime(Long.parseLong(map.get(AppConstants.EFFECTIVE_DATE_AT)));
		facilityDelta.setTransactionType(map.get(AppConstants.TRANSACTION_TYPE));
		facilityDelta.setUuId(map.get(AppConstants.UUID));
		facilityDelta.setZipCode(map.get(AppConstants.ZIP_CODE));
		return facilityDelta;

	}
	
	public Set<String> findDistinctNetwork() {
		
	
		Set<String> networkSet=setOperations.members(zipToDestUtil.getFacilityKey(keyspace,AppConstants.NETWORKS_KEY));
		return networkSet;
	}
	
	
	
	
	
	
}
