package com.fedex.ziptodest.distribution.service;

import java.util.List;

import com.fedex.ziptodest.model.DestinationResponse;
import com.fedex.ziptodest.model.FacilityDeltaResponse;
import com.fedex.ziptodest.model.FacilityDistribution;
import com.fedex.ziptodest.model.TimestampResponseDelta;

/**
 * @author 3790999
 *
 */
public interface ZipToDestService {

	public List<String> getAllDistributions(String network);

	public List<FacilityDistribution> getAllFacilityDistributionsByNetwork(String networkID);

	public FacilityDistribution getFacilityDistributionsByID( String facilityID);

	public List<String> changedNetworks(String network, Long userGivenTimestamp);

	public DestinationResponse getDestinationByNetworkAndZipCode(String network, String zipCode);

	public List<FacilityDeltaResponse> getDeltasByFacilityId(int facilityId, Long userGivenTimestamp);
	
	public TimestampResponseDelta getHasDeltaByFacilityId(int facilityId, Long userGivenTimestamp);

}
