package com.fedex.ziptodest.distribution.repository.redis;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.model.ZipToDestination;

@Repository("ZipToDestRedisRepository")
public interface ZipToDestRedisRepository
		extends CrudRepository<ZipToDestination, String> {

	public Iterable<ZipToDestination> findByCountryCodeAndNetwork(int countryCode, String network);

	public Iterable<ZipToDestination> findByNetwork(Sort page, String networkID);

	public List<ZipToDestination> findByDestination(String facilityID);

	public List<ZipToDestination> findLastUpdatedTimestamp(int countryCode, String givenNetwork,
			Long userGivenTimestamp);

	public ZipToDestination findByNetworkAndZipCode(String givenNetwork, String userGivenZipCode);

	public List<String> findDistinctNetwork();

	public ZipToDestination findFirstByNetwork(String network);

}
