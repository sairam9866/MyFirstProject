package com.fedex.ziptodest.batch.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.batch.dao.ZipToDestTransactionDao;
import com.fedex.ziptodest.batch.service.ZipToDestTransactionService;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;

/**
 * The implementation class for ZipToDestTransactionService.
 * 
 * @author 3818669
 *
 */
@Service
public class ZipToDestTransactionServiceImpl implements ZipToDestTransactionService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestTransactionServiceImpl.class);

	@Autowired
	ZipToDestTransactionDao zipToDestTransactionDao;

	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;
	/**
	 * 	
	 */
	public List<ZipToDest> findUnProcessedTransactions(Long utcTime){
		return zipToDestTransactionDao.findUnProcessedTransactions(utcTime);
	}

	/**
	 * The ZipToDestTransactionService::findOlderTransactions implementation
	 * will return a list of older transactions.
	 * 
	 * @param network
	 *            - network code of transaction.
	 * @param zipCode
	 *            - zipcode of transaction.
	 * 
	 * @return List of ZipToDest.
	 */
	@Override
	public List<ZipToDest> findOlderTransactions(String network, String zipCode) {
		return zipToDestTransactionDao.findOlderTransactions(network, zipCode, zipToDestBatchUtil.getCurrentUtcEpochTime());
	}	

	/**
	 * The ZipToDestTransactionService::updateOlderTransactions implementation
	 * updates the current flag of older transactions to 'N'.
	 * 
	 * @param zipToDests
	 *            list of transaction.
	 */
	@Override
	public void updateOlderTransactions(List<ZipToDest> zipToDests, Long processedAt) {
		LOGGER.info("Updating older transactions current flag...");		
		for (ZipToDest oldZipToDest : zipToDests) {
			
			LOGGER.info("Updating Old Current transaction -> {}", oldZipToDest);	
			
			oldZipToDest.setProcessed(AppConstants.FLAG_YES);
			oldZipToDest.setCurrent(AppConstants.FLAG_NO);
			oldZipToDest.setProcessedDateTime(processedAt);		
			
			zipToDestTransactionDao.saveCurrentTransaction(oldZipToDest);
			
			zipToDestTransactionDao.removeOldProcessedKey(oldZipToDest);
		}
		LOGGER.info("Older transactions current flag  updated to 'N'.");

	}
	
	@Override
	public void deleteFutureTransactions(List<ZipToDest> zipToDestList){
		for(ZipToDest zipToDest : zipToDestList){
			zipToDestTransactionDao.deleteFutureTransaction(zipToDest);
		}
	}	
	
	public void deleteCurrentTransactions(List<ZipToDest> zipToDestList){
		for(ZipToDest zipToDest : zipToDestList){
			zipToDestTransactionDao.deleteCurrentTransaction(zipToDest);
		}
	}

	@Override
	public void saveCurrentTransaction(List<ZipToDest> zipToDests, Long processedAt) {		
		for(ZipToDest zipToDest : zipToDests){
			ZipToDest transaction = getCurrentTransaction(zipToDest, processedAt);			
			zipToDestTransactionDao.saveCurrentTransaction(transaction);
		}
	}
	
	private ZipToDest getCurrentTransaction(ZipToDest zipToDest, Long processedAt){
		ZipToDest transaction = zipToDestBatchUtil.instanceOfZipToDest(zipToDest);
		transaction.setProcessed(AppConstants.FLAG_YES);
		transaction.setCurrent(AppConstants.FLAG_YES);
		transaction.setCancelledFlag(AppConstants.FLAG_NO);
		transaction.setProcessedDateTime(processedAt);
		return transaction;
	}

	@Override
	public void deleteTransactions(List<ZipToDest> zipToDests, Long processedDateTime) {
		for(ZipToDest zipToDest : zipToDests){
			ZipToDest transaction = zipToDestBatchUtil.instanceOfZipToDest(zipToDest);
			transaction.setProcessed("Y");
			transaction.setCurrent("N");
			transaction.setCancelledFlag("N");
			transaction.setProcessedDateTime(processedDateTime);
			
			zipToDestTransactionDao.saveCurrentTransaction(transaction);
		}
	}

	@Override
	public Long deleteLastProcessedHashKeys() {		
		return zipToDestTransactionDao.deleteLastProcessedHashKeys();
	}
}
