package com.fedex.ziptodest.batch.redis.dao;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;

public abstract class KeyExpirationConfig {
	private static final Logger LOGGER = LoggerFactory.getLogger(KeyExpirationConfig.class);

	@Autowired
	@Qualifier("redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;

	@Autowired
	private Environment evironment;

	private boolean isKeyExpireEnabled;

	private long expirationInDays;

	private long expirationInHours;

	public void setTimeToLive(String key) {
		afterPropertySet();

		if (isKeyExpireEnabled && redisTemplate.getExpire(key) < 0) {
			LOGGER.info("key : {}", key);
			
			if (expirationInDays != 0) {
				LOGGER.info("expirationInDays : {}", expirationInDays);
				redisTemplate.expire(key, expirationInDays, TimeUnit.DAYS);
			} else if (expirationInHours != 0) {
				LOGGER.info("expirationInHours : {}", expirationInHours);
				redisTemplate.expire(key, expirationInHours, TimeUnit.HOURS);
			}
			
		}
	}

	private void afterPropertySet() {
		isKeyExpireEnabled = evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false);
		expirationInDays = evironment.getProperty("redis.keys.expire.days", Long.class, 0L);
		expirationInHours = evironment.getProperty("redis.keys.expire.hours", Long.class, 0L);
	}
}
