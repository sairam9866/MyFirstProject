package com.fedex.ziptodest.batch.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.fedex.ziptodest.batch.service.TransactionPayloadService;
import com.fedex.ziptodest.batch.util.AppConstants;

import redis.embedded.RedisServer;
import redis.embedded.RedisServerBuilder;

/**
 * 
 * @author 3818669
 *
 */
@Configuration
@Profile("local")
public class ZdBatchRedisConfig {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZdBatchRedisConfig.class);	
	
	@Value("${spring.profiles.active:local}")
	private String activeProfile;

	@Value("${spring.redis.port:6378}")
	private Integer redisPort;

	@Value("${spring.redis.host:localhost}")
	private String redisHostName;	

	private RedisServer redisServer;	

	@Autowired
	TransactionPayloadService transactionPayloadService;
	
	@PostConstruct
	public void init() {
		LOGGER.info("Current Active Profile : {}", activeProfile);
		LOGGER.info("Redis Host : {}", redisHostName);
		LOGGER.info("Redis Port : {}", redisPort);

		if (AppConstants.APP_PROFILE_LOCAL.equals(activeProfile)) {
			redisServer = new RedisServerBuilder().port(redisPort).setting("maxmemory 256M").build();
			redisServer.start();
			transactionPayloadService.init();
			LOGGER.info("Embedded Redis Started....");
		}
	}	
	
	@PreDestroy
	public void destroy() {
		if (AppConstants.APP_PROFILE_LOCAL.equals(activeProfile)) {
			redisServer.stop();
			LOGGER.info("Embedded Redis Stopped.");
		}
	}
}
