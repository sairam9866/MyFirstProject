package com.fedex.ziptodest.batch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.batch.dao.CountryCodeDao;
import com.fedex.ziptodest.batch.dao.DestinationDao;
import com.fedex.ziptodest.batch.dao.NetworkDao;
import com.fedex.ziptodest.batch.dao.StateProvinceDao;
import com.fedex.ziptodest.batch.service.IseriesDataService;

@Service
public class IseriesDataServiceImpl implements IseriesDataService {

	@Autowired
	NetworkDao networkDao;
	
	@Autowired
	CountryCodeDao countryCodeDao;
	
	@Autowired
	DestinationDao destinationDao;
	
	@Autowired
	StateProvinceDao stateProvinceDao;
	
	
	@Override
	public List<String> selectAllCountryCode() {		
		return countryCodeDao.findAll();
	}

	@Override
	public List<String> selectAllDestination() {
		return destinationDao.findAll();
	}

	@Override
	public List<String> selectAllNetworks() {
		return networkDao.findAll();
	}

	@Override
	public List<String> selectAllStateProvince() {
		return stateProvinceDao.findAll();
	}

}
