package com.fedex.ziptodest.batch.tasklet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.service.WriteProcess;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

/**
 * The Tasklet implementation class for inserting not processed transactions
 * which are modified into Facility and ZipToDest master table.
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestModifyWriteTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestModifyWriteTasklet.class);
	
	@Autowired
	WriteProcess writeProcess;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * The Tasklet::execute method implementation contains the business logic
	 * for inserting the not processed transactions which are modified into
	 * Facility and ZiptoDest master table.
	 * 
	 * <pre>
	 * Modify Batch Process Flow:
	 * 1. Getting not processed transaction with transaction type as 'M' from ExecutionContext.
	 * 2. Getting Zip code range association from Facility table and need to update each facility's transaction type as 'D'(Deleted).
	 * 3. Adding the modified transactions into Facility master table with transaction type as 'A' and updating its effective time stamp to current UTC time..
	 * 4. Physically deleting zip code association from zip to destination master table.
	 * 5. Inserting the modified transactions in zip to destination master table.
	 * 6. Getting older transactions from transaction table and updating the current flag of each transaction to 'N'.
	 * 7. Updating the modified transactions current flag to 'Y'.
	 * </pre>
	 * 
	 * <p>
	 * Implementations return {@link RepeatStatus#FINISHED} if finished. If not
	 * they return {@link RepeatStatus#CONTINUABLE}. On failure throws an
	 * exception.
	 * </p>
	 * 
	 * @param contribution
	 *            mutable state to be passed back to update the current step
	 *            execution
	 * @param chunkContext
	 *            attributes shared between invocations but not between restarts
	 * @return an {@link RepeatStatus} indicating whether processing is
	 *         continuable. Returning {@code null} is interpreted as
	 *         {@link RepeatStatus#FINISHED}
	 *
	 * @throws Exception
	 *             thrown if error occurs during execution.
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("Starting Modify Batch Process... ");
		
		writeProcess.executeWriteProcess(zipToDestBatchUtil.getCurrentExecutionContext(chunkContext),
				AppConstants.TRANSACTION_TYPE_MODIFY, AppConstants.KEY_UNPROCESSED_MODIFIED);		
		
		LOGGER.info("Finishing Modifying Batch Process... ");
		return RepeatStatus.FINISHED;
	}
}
