package com.fedex.ziptodest.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fedex.ziptodest.batch.tasklet.IseriesDataReaderTasklet;
import com.fedex.ziptodest.batch.tasklet.IseriesDataWriterTasklet;
import com.fedex.ziptodest.batch.tasklet.ZipToDestAddReadTasklet;
import com.fedex.ziptodest.batch.tasklet.ZipToDestAddWriteTasklet;
import com.fedex.ziptodest.batch.tasklet.ZipToDestCacheManagerTasklet;
import com.fedex.ziptodest.batch.tasklet.ZipToDestDeleteWriteTasklet;
import com.fedex.ziptodest.batch.tasklet.ZipToDestHasDeltaTasklet;
import com.fedex.ziptodest.batch.tasklet.ZipToDestModifyWriteTasklet;

/**
 * Spring configuration class, which uses <code>@EnableBatchProcessing</code> to enable batch processing features.
 * <p>This class contains bean configurations for <code>Step</code>, <code>Job</code> and <code>Tasklet</code>.</p>
 * <p>For creating <code>Step</code> instance it using <code>StepBuilderFactory</code>.</p>
 * <p>For creating <code>Job</code> instance it using <code>JobBuilderFactory</code>.</p>
 * 
 * @author 3818669
 *
 */
@Configuration
@EnableBatchProcessing
public class ZipToDestBatchConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	ZipToDestAddReadTasklet zipToDestAddReadTasklet;
	
	@Autowired
	ZipToDestAddWriteTasklet zipToDestAddWriteTasklet;
	
	@Autowired
	ZipToDestModifyWriteTasklet zipToDestModifyWriteTasklet;
	
	@Autowired
	ZipToDestDeleteWriteTasklet zipToDestDeleteWriteTasklet;
	
	@Autowired
	ZipToDestCacheManagerTasklet zipToDestCacheManagerTasklet;	
	
	@Autowired
	ZipToDestHasDeltaTasklet zipToDestHasDeltaTasklet;
	
	@Autowired
	IseriesDataReaderTasklet iseriesDataReaderTasklet;
	
	@Autowired
	IseriesDataWriterTasklet iseriesDataWriterTasklet;
	
	/**
	 * 
	 * @return
	 */
	@Bean(name = "importTransactionToMaster")
	public Job importTransactionToMaster(){
		return (jobBuilderFactory.get("importTransactionToMaster")
				.start(zipToDestAddReadStep())		
				.next(zipToDestAddWriteStep())			
				.next(zipToDestModifyWriteStep())				
				.next(zipToDestDeleteWriteStep())
				.next(zipToDestHasDeltaStep())
				.next(zipToDestCacheManagerStep())
				.build());
	}	
	
	@Bean(name = "iseriesDataMigrator")
	public Job iseriesDataMigrator(){
		return (jobBuilderFactory.get("iseriesDataMigrator")				
				.start(iseriesDataReaderStep())
				.next(iseriesDataWriterStep())
				.build());
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestAddReadStep(){
		return stepBuilderFactory.get("zipToDestAddReadStep")				
				.tasklet(zipToDestAddReadTasklet)
				.build();
	}	
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestAddWriteStep(){
		return stepBuilderFactory.get("zipToDestAddWriteStep")
				.tasklet(zipToDestAddWriteTasklet)
				.build();
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestModifyWriteStep(){
		return stepBuilderFactory.get("zipToDestModifyWriteStep")
				.tasklet(zipToDestModifyWriteTasklet)
				.build();
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestDeleteWriteStep(){
		return stepBuilderFactory.get("zipToDestDeleteWriteStep")
				.tasklet(zipToDestDeleteWriteTasklet)
				.build();
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestHasDeltaStep(){
		return stepBuilderFactory.get("zipToDestHasDeltaStep")
				.tasklet(zipToDestHasDeltaTasklet)
				.build();
	}
	
	/**
	 * 
	 * @return
	 */
	@Bean
	public Step zipToDestCacheManagerStep(){
		return stepBuilderFactory.get("zipToDestCacheManagerStep")
				.tasklet(zipToDestCacheManagerTasklet)
				.build();
	}	
	
	
	/**
	 * 
	 * @return
	 */
	public Step iseriesDataReaderStep(){
		return stepBuilderFactory.get("iseriesDataReaderStep")
				.tasklet(iseriesDataReaderTasklet).build();
	}
	
	/**
	 * 
	 * @return
	 */
	public Step iseriesDataWriterStep(){
		return stepBuilderFactory.get("iseriesDataWriterStep")
				.tasklet(iseriesDataWriterTasklet).build();
	}
	
}

