package com.fedex.ziptodest.batch.model.mappers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.util.Fields;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.StateProvince;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class StateProvinceMapper {
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * 
	 * @param map
	 * @return
	 */
	public StateProvince toStateProvince(Map<String, String> map){
		StateProvince stateProvince = new StateProvince();
		stateProvince.setCntryc(map.get(Fields.CNTRYC));
		stateProvince.setSpName(map.get(Fields.SP_NAME));
		stateProvince.setStaPro(map.get(Fields.STA_PRO));
		return stateProvince;
	}
	
	public String toJson(Map<String, String> map){
		StringBuilder builder = new StringBuilder();
		builder.append("{");
		builder.append(Fields.CNTRYC).append(":").append(map.get(Fields.CNTRYC)).append(",");
		builder.append(Fields.SP_NAME).append(":").append(map.get(Fields.SP_NAME)).append(",");		
		builder.append(Fields.STA_PRO).append(":").append(map.get(Fields.STA_PRO));
		builder.append("}");
		return builder.toString();
	}
	
	/**
	 * 
	 * @param stateProvince
	 * @return
	 */
	public Map<String, String> toMap(StateProvince stateProvince){
		Map<String, String> map = new HashMap<>();
		map.put(Fields.CNTRYC, zipToDestBatchUtil.stringValueOf(stateProvince.getCntryc()));
		map.put(Fields.SP_NAME, zipToDestBatchUtil.stringValueOf(stateProvince.getSpName()));
		map.put(Fields.STA_PRO, zipToDestBatchUtil.stringValueOf(stateProvince.getStaPro()));		
		return map;
	}
}
