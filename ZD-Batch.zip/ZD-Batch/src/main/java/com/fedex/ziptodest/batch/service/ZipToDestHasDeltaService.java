package com.fedex.ziptodest.batch.service;

import java.util.Set;

/**
 * 
 * @author 3818669
 *
 */
public interface ZipToDestHasDeltaService {

	public int insertOrUpdateZipToDestHasDelta(Set<String> networks, Long effectiveDate);
}
