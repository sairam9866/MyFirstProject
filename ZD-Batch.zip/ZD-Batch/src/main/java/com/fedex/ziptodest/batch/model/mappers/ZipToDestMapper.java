package com.fedex.ziptodest.batch.model.mappers;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.util.Fields;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;

@Component
public class ZipToDestMapper {
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	// while returning back to front end
	public ZipToDest toZipToDest(Map<String, String> map) {
		ZipToDest ziptodest = new ZipToDest();
		ziptodest.setCancelledFlag(zipToDestBatchUtil.stringValueOf(map.get(Fields.CANCELLED_FLAG)));
		ziptodest.setCancelledTimestamp(NumberUtils.isCreatable(map.get(Fields.CANCELLED_TIMESTAMP))
				? NumberUtils.toLong(map.get(Fields.CANCELLED_TIMESTAMP)) : null);
		ziptodest.setCancelledUser(map.get(Fields.CANCELLED_USER));
		ziptodest.setCountryCode(NumberUtils.isCreatable(map.get(Fields.COUNTRY_CODE))
				? NumberUtils.toInt(map.get(Fields.COUNTRY_CODE)) : 0);

		ziptodest.setCreatedDateAt(NumberUtils.isCreatable(map.get(Fields.CREATED_DATE_AT))
				? NumberUtils.toLong(map.get(Fields.CREATED_DATE_AT)) : null);
		ziptodest.setCreationUser(map.get(Fields.CREATION_USER));
		ziptodest.setCurrent((map.get(Fields.CURRENT)));
		ziptodest.setDestinationTerminal(map.get(Fields.DESTINATION_TERMINAL));
		ziptodest.setEffectiveDateAt(NumberUtils.isCreatable(map.get(Fields.EFFECTIVE_DATE_AT))
				? NumberUtils.toLong(map.get(Fields.EFFECTIVE_DATE_AT)) : null);
		ziptodest.setNetwork(map.get(Fields.NETWORK));
		ziptodest.setProcessed((map.get(Fields.PROCESSED)));
		ziptodest.setProcessedDateTime(NumberUtils.isCreatable(map.get(Fields.PROCESSED_DATE_TIME))
				? NumberUtils.toLong(map.get(Fields.PROCESSED_DATE_TIME)) : null);

		ziptodest.setState(map.get(Fields.STATE));
		ziptodest.setTransactionType(map.get(Fields.TRANSACTION_TYPE));
		ziptodest.setUuid(map.get(Fields.UUID));
		ziptodest.setZipCode(map.get(Fields.ZIP_CODE));
		ziptodest.setTimeZone(map.get(Fields.TIME_ZONE));
		ziptodest.setId(map.get(Fields.ID));
		return ziptodest;

	}

	// before saving to DB
	public Map<String, String> toMap(ZipToDest ziptodest) {
		Map<String, String> map = new HashMap<>();
		map.put(Fields.ID, zipToDestID(ziptodest));
		map.put(Fields.CANCELLED_DT_AT, zipToDestBatchUtil.stringValueOf(ziptodest.getCancelledAt()));
		map.put(Fields.CANCELLED_TIMESTAMP, zipToDestBatchUtil.stringValueOf(ziptodest.getCancelledTimestamp()));
		map.put(Fields.CANCELLED_FLAG, ziptodest.getCancelledFlag() == null ? "N" : ziptodest.getCancelledFlag());

		map.put(Fields.CANCELLED_USER, ziptodest.getCancelledUser() == null ? "" : ziptodest.getCancelledUser());

		map.put(Fields.COUNTRY_CODE, zipToDestBatchUtil.stringValueOf((ziptodest.getCountryCode())));
		map.put(Fields.CREATION_DT, zipToDestBatchUtil.stringValueOf(ziptodest.getcreationDate()));
		map.put(Fields.CREATED_DATE_AT, zipToDestBatchUtil.stringValueOf(ziptodest.getCreatedDateAt()));
		map.put(Fields.CREATION_USER, zipToDestBatchUtil.stringValueOf(ziptodest.getCreationUser()));
		map.put(Fields.CURRENT, zipToDestBatchUtil.stringValueOf(ziptodest.getCurrent()));
		map.put(Fields.DESTINATION_TERMINAL, zipToDestBatchUtil.stringValueOf(Integer.parseInt(ziptodest.getDestinationTerminal().trim())));

		map.put(Fields.EFFECTIVE_DATE_AT, zipToDestBatchUtil.stringValueOf(ziptodest.getEffectiveDateAt()));
		map.put(Fields.EFFECTIVE_DT, zipToDestBatchUtil.stringValueOf(ziptodest.getEffectiveDate()));

		map.put(Fields.NETWORK, zipToDestBatchUtil.stringValueOf(ziptodest.getNetwork()));

		map.put(Fields.PROCESSED_DATE_TIME, zipToDestBatchUtil.stringValueOf(ziptodest.getProcessedDateTime()));
		map.put(Fields.PROCESSED, zipToDestBatchUtil.stringValueOf(ziptodest.getProcessed()));
		map.put(Fields.STATE, zipToDestBatchUtil.stringValueOf(ziptodest.getState()));
		map.put(Fields.TIME_ZONE, zipToDestBatchUtil.stringValueOf(ziptodest.getTimeZone()));
		map.put(Fields.TRANSACTION_TYPE, zipToDestBatchUtil.stringValueOf(ziptodest.getTransactionType()));
		map.put(Fields.UUID, zipToDestBatchUtil.stringValueOf(ziptodest.getUuid()));
		map.put(Fields.ZIP_CODE, zipToDestBatchUtil.stringValueOf(ziptodest.getZipCode()));
		return map;
	}	

	public String zipToDestID(ZipToDest zipToDest) {
		String key = zipToDest.getNetwork() + ":" + zipToDest.getCountryCode() + ":"
				+ zipToDest.getDestinationTerminal() + ":" + zipToDest.getZipCode() + ":"
				+ zipToDest.getCreatedDateAt();
		return key;
	}
}
