package com.fedex.ziptodest.batch.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.batch.dao.ZipToDestHasDeltaDao;
import com.fedex.ziptodest.batch.dao.ZipToDestTransactionDao;
import com.fedex.ziptodest.batch.service.DataLoaderService;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

@Service
public class DataLoaderServiceImpl implements DataLoaderService {

	@Autowired
	ZipToDestTransactionDao zipToDestTransactionDao;

	@Autowired
	private ZipToDestHasDeltaDao zipToDestHasDeltaDao;	

	@Override
	public List<ZipToDestHasDelta> findAllFacilityHasDelta() {
		return zipToDestHasDeltaDao.findAll();
	}
	
	@Override
	public List<ZipToDest> findAllCurrentTransaction(){
		return zipToDestTransactionDao.findByProcessedAndCurrentAndCancelledFlag(AppConstants.CURRENT_RECORDS);
	}
	
	@Override
	public List<ZipToDest> findAllFutureTransaction(){
		return zipToDestTransactionDao.findByProcessedAndCurrentAndCancelledFlag(AppConstants.FUTURE_RECORDS);
	}

	@Override
	public List<ZipToDest> findAllHistoryTransaction() {
		return zipToDestTransactionDao.findByProcessedAndCurrentAndCancelledFlag(AppConstants.HISTORICAL_RECORDS);
	}

}
