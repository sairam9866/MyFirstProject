package com.fedex.ziptodest.batch.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.convert.KeyspaceConfiguration;

/**
 * 
 * @author 3818669
 *
 */
public class ZdBatchKeyspaceConfiguration extends KeyspaceConfiguration {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZdBatchKeyspaceConfiguration.class);
	
	private String keyspace;

	public ZdBatchKeyspaceConfiguration(String keyspace) {
		LOGGER.info("ZdBatchKeyspaceConfiguration - keyspace : {}", keyspace);
		this.keyspace = keyspace;
	}

	public String getKeyspace() {
		return keyspace;
	}

	public void setKeyspace(String keyspace) {
		this.keyspace = keyspace;
	}

	@Override
	public boolean hasSettingsFor(Class<?> type) {
		return true;
	}

	@Override
	public KeyspaceSettings getKeyspaceSettings(Class<?> type) {
		LOGGER.info("ZdBatchKeyspaceConfiguration::getKeyspaceSettings - Keyspace : {}", getKeyspace());
		String key = ("{" + getKeyspace() + "-" + type.getSimpleName() + "}").toUpperCase() ;
		LOGGER.info("ZdBatchKeyspaceConfiguration::getKeyspaceSettings - Key : {}", key);
		return (new KeyspaceSettings(type, key));		
	}

}
