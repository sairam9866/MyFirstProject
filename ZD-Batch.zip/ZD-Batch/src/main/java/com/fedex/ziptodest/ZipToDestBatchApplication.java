package com.fedex.ziptodest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.MappingConfiguration;
import org.springframework.data.redis.core.index.IndexConfiguration;
import org.springframework.data.redis.core.mapping.RedisMappingContext;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.web.client.RestTemplate;

import com.fedex.ziptodest.batch.config.ZdBatchKeyspaceConfiguration;

import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@EnableRedisRepositories
public class ZipToDestBatchApplication {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestBatchApplication.class);

	@Value("${spring.redis.port:6378}")
	private Integer redisPort;

	@Value("${spring.redis.host:localhost}")
	private String redisHostName;

	@Value("${spring.redis.password}")
	private String password;

	@Value(value = "${keyspace}")
	private String keyspace;
	
	public static void main(String[] args) {
		SpringApplication.run(ZipToDestBatchApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

	@Bean
	RedisConnectionFactory connectionFactory() {
		RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration(redisHostName,
				redisPort);
		if (StringUtils.isNotBlank(password)) {
			redisStandaloneConfiguration.setPassword(password);
		}
		return new JedisConnectionFactory(redisStandaloneConfiguration);
	}

	@Bean(name = "redisTemplate")
	RedisTemplate<?, ?> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		redisTemplate.setKeySerializer(new StringRedisSerializer());

		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}
	
	@Bean(name = "strRedisTemplate")
	RedisTemplate<?, ?> strRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		redisTemplate.setKeySerializer(new StringRedisSerializer());

		redisTemplate.setHashKeySerializer(new StringRedisSerializer());		
		redisTemplate.setHashValueSerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		//redisTemplate.setEnableTransactionSupport(true);
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}

	@Bean
	ZdBatchKeyspaceConfiguration zdBatchKeyspaceConfiguration() {
		return new ZdBatchKeyspaceConfiguration(keyspace);
	}

	@Bean
	public RedisMappingContext keyValueMappingContext(ZdBatchKeyspaceConfiguration keyspaceConfiguration) {
		return new RedisMappingContext(new MappingConfiguration(new IndexConfiguration(), keyspaceConfiguration));
	}
}
