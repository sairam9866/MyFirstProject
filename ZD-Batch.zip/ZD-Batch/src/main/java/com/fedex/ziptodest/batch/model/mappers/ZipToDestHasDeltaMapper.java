package com.fedex.ziptodest.batch.model.mappers;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.util.Fields;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

@Component
public class ZipToDestHasDeltaMapper {
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	public ZipToDestHasDelta toZipToDestHasDelta(Map<String, String> map) {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork(map.get(Fields.NETWORK));

		zipToDestHasDelta.setLastUpdateTimestamp(NumberUtils.isCreatable(map.get(Fields.LAST_UPDATE_TIMESTAMP))
				? NumberUtils.toLong(map.get(Fields.LAST_UPDATE_TIMESTAMP)) : null);
		return zipToDestHasDelta;
	}

	public Map<String, String> toMap(ZipToDestHasDelta zipToDestHasDelta) {
		Map<String, String> map = new HashMap<>();
		map.put(Fields.NETWORK, zipToDestHasDelta.getNetwork());
		map.put(Fields.LAST_UPDATE_TIMESTAMP,
				zipToDestBatchUtil.stringValueOf(zipToDestHasDelta.getLastUpdateTimestamp()));
		return map;
	}
}
