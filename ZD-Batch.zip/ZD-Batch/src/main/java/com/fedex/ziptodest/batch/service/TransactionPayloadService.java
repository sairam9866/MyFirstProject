package com.fedex.ziptodest.batch.service;

public interface TransactionPayloadService {
	public void init();
}
