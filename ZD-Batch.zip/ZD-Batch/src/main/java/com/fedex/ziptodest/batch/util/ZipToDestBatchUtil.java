package com.fedex.ziptodest.batch.util;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.model.JobAuditResponse;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

/**
 * A Utility class for ZD-Batch application.
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestBatchUtil {

	public final Logger LOGGER = LoggerFactory.getLogger(ZipToDestBatchUtil.class);

	private final Pattern PATTERN_US_ZIP_CODE = Pattern.compile("[0-9]{5,5}");
	private final Pattern PATTERN_CANADA_ZIP_CODE3 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z]$");
	private final Pattern PATTERN_CANADA_ZIP_CODE6 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z][\\d][a-zA-Z][\\d]$");

	/**
	 * Method to get the current ExecutionContext of spring batch Job.
	 * 
	 * ExecutionContext acts as Map, it internally using ConcurrentHashMap. With
	 * ExecutionContext we can store data as key:value pair. And this data will
	 * be available in whole Job execution life cycle.
	 * 
	 * Note that putting <code>null</code> value is equivalent to removing the
	 * entry for the given key.
	 * 
	 * @param chunkContext
	 *            contains information about Step and Job execution.
	 * @return current job's execution context.
	 */
	public ExecutionContext getCurrentExecutionContext(ChunkContext chunkContext) {
		return (chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext());
	}

	public ZipToDest instanceOfZipToDest(ZipToDest zipToDest) {
		ZipToDest transaction = new ZipToDest();
		transaction.setCancelledFlag(zipToDest.getCancelledFlag());
		transaction.setCancelledTimestamp(zipToDest.getCancelledTimestamp());
		transaction.setCancelledUser(zipToDest.getCancelledUser());
		transaction.setCountryCode(zipToDest.getCountryCode());
		transaction.setCreatedDateAt(zipToDest.getCreatedDateAt());
		transaction.setCreationUser(zipToDest.getCreationUser());
		transaction.setCurrent(zipToDest.getCurrent());
		transaction.setDestinationTerminal(zipToDest.getDestinationTerminal());
		transaction.setEffectiveDateAt(zipToDest.getEffectiveDateAt());
		transaction.setId(zipToDest.getId());
		transaction.setNetwork(zipToDest.getNetwork());
		transaction.setProcessed(zipToDest.getProcessed());
		transaction.setProcessedDateTime(zipToDest.getProcessedDateTime());
		transaction.setState(zipToDest.getState());
		transaction.setUuid(zipToDest.getUuid());
		transaction.setZipCode(zipToDest.getZipCode());
		transaction.setZipFrom(zipToDest.getZipFrom());
		transaction.setZipTo(zipToDest.getZipTo());
		transaction.setTransactionType(zipToDest.getTransactionType());
		return transaction;
	}

	/**
	 * 
	 * @param jobExecution
	 * @return
	 */
	public JobAuditResponse instanceOfJobAuditResponse(JobExecution jobExecution) {
		JobAuditResponse jobAuditResponse = new JobAuditResponse();
		jobAuditResponse.setCreateTime(jobExecution.getCreateTime());
		jobAuditResponse.setEndTime(jobExecution.getEndTime());
		jobAuditResponse.setExitMessage(jobExecution.getExitStatus().getExitCode());
		jobAuditResponse.setLastUpdated(jobExecution.getLastUpdated());
		jobAuditResponse.setStartTime(jobExecution.getStartTime());
		jobAuditResponse.setStatus(jobExecution.getStatus().name());
		if (!jobExecution.getFailureExceptions().isEmpty()) {
			jobAuditResponse.setStackTrace(jobExecution.getFailureExceptions().get(0).getMessage());
		}
		return jobAuditResponse;
	}

	/**
	 * 
	 * @param zipToDestination
	 * @return
	 */
	public ZipToDestHasDelta instanceOfZipToDestHasDelta(String network, Long effectiveDate) {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork(network);
		zipToDestHasDelta.setLastUpdateTimestamp(effectiveDate);
		return zipToDestHasDelta;
	}

	/**
	 * Method to get the current UTC time.
	 * 
	 * @return - <code>Timestamp</code> which holds the current UTC time.
	 */
	public Timestamp getCurrentUtcTimestamp() {
		return Timestamp.valueOf(Instant.now().atZone(ZoneOffset.UTC).toLocalDateTime());
	}

	public Long getCurrentUtcEpochTime() {
		return ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond();
	}

	/**
	 * Method to validate the given zipcode is a valid US zipcode or not.
	 * 
	 * @param zipCode
	 *            - zipcode value.
	 * 
	 * @return - true if the zipCode is a valid US zipcode otherwise return
	 *         false.
	 */
	public boolean isValidUsaZipCode(String zipCode) {
		LOGGER.debug("Zip Code -> {}", zipCode);
		boolean output = false;
		output = (PATTERN_US_ZIP_CODE.matcher(zipCode).matches());
		LOGGER.debug("Is valid Us zipcode {} -> {}", zipCode, output);
		return output;
	}

	/**
	 * Method to validate the given zipcode is a valid Canadian zipcode or not.
	 * 
	 * @param zipCode
	 *            - zipcode value.
	 * 
	 * @return - true if the zipCode is a valid Canadian zipcode otherwise
	 *         return false.
	 */
	public boolean isValidCanadaZipCode(String zipCode) {
		LOGGER.debug("Zip Code -> {}", zipCode);
		boolean output = false;
		output = (PATTERN_CANADA_ZIP_CODE3.matcher(zipCode).matches()
				|| PATTERN_CANADA_ZIP_CODE6.matcher(zipCode).matches());
		LOGGER.debug("Is valid Canadian zipcode {} -> {}", zipCode, output);
		return output;
	}

	public String getActualZipcode(String zipCode) {
		return (zipCode.length() == 11 ? zipCode.substring(0, 5) : zipCode);
	}

	public boolean isCurrent(ZipToDest zipToDest) {
		return (AppConstants.FLAG_YES.equals(zipToDest.getProcessed())
				&& AppConstants.FLAG_YES.equals(zipToDest.getCurrent()));
	}

	public String zipToDestHashKey(String keyspace, ZipToDest zipToDest) {
		String key = keyspace + AppConstants.SEPARATOR_COLON + zipToDest.getNetwork() + AppConstants.SEPARATOR_COLON
				+ zipToDest.getCountryCode() + AppConstants.SEPARATOR_COLON + zipToDest.getDestinationTerminal()
				+ AppConstants.SEPARATOR_COLON + zipToDest.getZipCode() + AppConstants.SEPARATOR_COLON
				+ zipToDest.getCreatedDateAt();
		return key.toUpperCase();
	}

	public String getRedisKey(String prefix, String key) {
		return (prefix + AppConstants.SEPARATOR_COLON + key).toUpperCase();
	}

	public String getFacilityHasDeltaKey(String keySpace, String key) {
		return (keySpace + AppConstants.SEPARATOR_COLON + AppConstants.FACILITYHASDELTA + AppConstants.SEPARATOR_COLON
				+ key).toUpperCase();
	}

	public String getHasDeltaLastProcessed(String keyspace, String network, String processedat) {
		return (keyspace + AppConstants.SEPARATOR_COLON + AppConstants.FACILITYHASDELTA + AppConstants.SEPARATOR_COLON
				+ network + AppConstants.SEPARATOR_COLON + processedat).toUpperCase();
	}

	public String getJSONCurrentRecordsKey(String keyspace) {
		return (keyspace + AppConstants.SEPARATOR_COLON + AppConstants.CURRENT_RECORDS_JSON).toUpperCase();
	}

	public String getCurrentKey(String keyspace) {
		return (keyspace + AppConstants.SEPARATOR_COLON + AppConstants.CURRENT_RECORDS).toUpperCase();
	}

	public String getCurrentByProcessedDate(String keyspace, String network, int countryCode, String processedat) {
		return (getCurrentKey(keyspace) + AppConstants.SEPARATOR_COLON + network + AppConstants.SEPARATOR_COLON
				+ countryCode + AppConstants.SEPARATOR_COLON + processedat).toUpperCase();
	}

	public String getNetworkCountryCodeKey(String keyspace, String network, Integer countryCode) {
		return (getCurrentKey(keyspace) + AppConstants.SEPARATOR_COLON + network + AppConstants.SEPARATOR_COLON
				+ countryCode).toUpperCase();
	}

	public String getNetworkZipCodeKey(String keyspace, String network, String zipCode) {
		return (getCurrentKey(keyspace) + AppConstants.SEPARATOR_COLON + network + AppConstants.SEPARATOR_COLON
				+ zipCode).toUpperCase();
	}

	public String getFacilityIdKey(String keyspace, String facilityId) {
		return (getCurrentKey(keyspace) + AppConstants.SEPARATOR_COLON + Integer.parseInt(facilityId)).toUpperCase();
	}

	public String getNetworkKey(String keyspace, String network) {
		return (getCurrentKey(keyspace) + AppConstants.SEPARATOR_COLON + network).toUpperCase();
	}

	public String getFutureKey(String keySpace) {
		return (keySpace + AppConstants.SEPARATOR_COLON + AppConstants.FUTURE_RECORDS).toUpperCase();
	}

	public String getFutureNetworkKey(String keyspace, String network) {
		return (getFutureKey(keyspace) + AppConstants.SEPARATOR_COLON + network).toUpperCase();
	}

	public String getFutureNetworkZipCodeKey(String keyspace, String network, String zipCode) {
		return (getFutureKey(keyspace) + AppConstants.SEPARATOR_COLON + network + AppConstants.SEPARATOR_COLON
				+ zipCode).toUpperCase();
	}

	public String getHistoryTransactionKey(String keyspace) {
		return (keyspace + AppConstants.SEPARATOR_COLON + AppConstants.HISTORICAL_RECORDS).toUpperCase();
	}

	public String getProcessedKey(String keySpace) {
		return (keySpace + AppConstants.SEPARATOR_COLON + AppConstants.PROCESSED_RECORDS).toUpperCase();
	}

	public String getIseriesCountryCodeKey(String keySpace, String countryCode) {
		return (getIseriesKey(keySpace, AppConstants.COUNTRY_CODE + AppConstants.SEPARATOR_COLON + countryCode))
				.toUpperCase();
	}

	public String getIseriesDestinationKey(String keySpace, String destination) {
		return (getIseriesKey(keySpace, AppConstants.DESTINATION + AppConstants.SEPARATOR_COLON + destination))
				.toUpperCase();
	}

	public String getIseriesNetworkKey(String keySpace, String network) {
		return (getIseriesKey(keySpace, AppConstants.NETWORK + AppConstants.SEPARATOR_COLON + network)).toUpperCase();
	}

	public String getIseriesStateProvinceKey(String keySpace, String staPro) {
		return (getIseriesKey(keySpace, AppConstants.STATEPROVINCE + AppConstants.SEPARATOR_COLON + staPro))
				.toUpperCase();
	}

	public String getIseriesStateProCountryKey(String keySpace, String countryCode) {
		return (getIseriesKey(keySpace,
				AppConstants.STATEPROVINCE_COUNTRY + AppConstants.SEPARATOR_COLON + countryCode)).toUpperCase();
	}

	public String getIseriesKey(String keySpace, String key) {
		return (keySpace + AppConstants.SEPARATOR_COLON + AppConstants.ISERIES + AppConstants.SEPARATOR_COLON + key)
				.toUpperCase();
	}

	public String getProcessedByNetworkAndZipCodeKey(String keyspace, String network, String zipCode) {
		return (getProcessedKey(keyspace) + AppConstants.SEPARATOR_COLON + network + AppConstants.SEPARATOR_COLON
				+ zipCode).toUpperCase();
	}

	public String stringValueOf(Object object) {
		return (object == null ? AppConstants.EMPTY : object.toString());
	}
}
