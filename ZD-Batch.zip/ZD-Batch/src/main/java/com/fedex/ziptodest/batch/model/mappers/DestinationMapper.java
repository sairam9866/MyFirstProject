package com.fedex.ziptodest.batch.model.mappers;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.util.Fields;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.Destination;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class DestinationMapper {
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * 
	 * @param map
	 * @return
	 */
	public Destination toDestination(Map<String, String> map) {
		Destination destination = new Destination();

		destination.setTerminalAbbreviation(map.get(Fields.TERMINAL_ABBREVIATION));
		destination.setTerminalNumber(
				StringUtils.isBlank(map.get(Fields.TERMINAL_NUMBER)) ? null : Integer.parseInt(map.get(Fields.TERMINAL_NUMBER)));
		destination.setTerminalStatus(map.get(Fields.TERMINAL_STATUS));

		return destination;
	}
	/**
	 * 
	 * @param map
	 * @return
	 */
	public String toJson(Map<String, String> map){
		StringBuilder builder = new StringBuilder();
		builder.append("{");
		builder.append(Fields.TERMINAL_ABBREVIATION).append(":").append(map.get(Fields.TERMINAL_ABBREVIATION)).append(",");
		builder.append(Fields.TERMINAL_NUMBER).append(":").append(map.get(Fields.TERMINAL_NUMBER)).append(",");
		builder.append(Fields.TERMINAL_STATUS).append(":").append(map.get(Fields.TERMINAL_STATUS));		
		builder.append("}");
		return builder.toString();
	}

	/**
	 * 
	 * @param destination
	 * @return
	 */
	public Map<String, String> toMap(Destination destination) {
		Map<String, String> map = new HashMap<>();

		map.put(Fields.TERMINAL_ABBREVIATION, zipToDestBatchUtil.stringValueOf(destination.getTerminalAbbreviation()));
		map.put(Fields.TERMINAL_STATUS, zipToDestBatchUtil.stringValueOf(destination.getTerminalStatus()));
		map.put(Fields.TERMINAL_NUMBER, zipToDestBatchUtil.stringValueOf(destination.getTerminalNumber()));

		return map;
	}
}
