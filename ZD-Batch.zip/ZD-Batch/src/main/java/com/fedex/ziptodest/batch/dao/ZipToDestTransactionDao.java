package com.fedex.ziptodest.batch.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.exception.BatchProcessInterruptedException;
import com.fedex.ziptodest.batch.model.mappers.ZipToDestMapper;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.commons.HashSetOperations;
import com.fedex.ziptodest.model.ZipToDest;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestTransactionDao {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestTransactionDao.class);

	@Value(value = "${keyspace}")
	private String keyspace;

	@Value(value = "${zd.history.record.expire.days}")
	private Long historyRecordsTtl;

	@Resource(name = "strRedisTemplate")
	private ZSetOperations<String, String> strSortedSetOperations;

	@Resource(name = "strRedisTemplate")
	private SetOperations<String, String> strSetOperations;

	@Autowired
	@Qualifier("strRedisTemplate")
	private RedisTemplate<String, String> strRedisTemplate;

	@Autowired
	HashSetOperations hashSetOperations;

	@Autowired
	ZipToDestMapper zipToDestMapper;

	@Resource(name = "strRedisTemplate")
	private HashOperations<String, String, String> strHashOperations;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * 
	 * @return
	 */
	public String getKeySpace() {
		return this.keyspace;
	}
 
	public Long getHistoryRecordsTtl() {
		return historyRecordsTtl;
	}

	public void saveCurrentTransaction(ZipToDest zipToDest) {

		String hashKey = zipToDestBatchUtil.zipToDestHashKey(getKeySpace(), zipToDest);

		strHashOperations.putAll(hashKey, zipToDestMapper.toMap(zipToDest));

		if (zipToDestBatchUtil.isCurrent(zipToDest)) {
			LOGGER.info("Saving Current Records with HashKey : {}", hashKey);
			// zD-sERVER QUERIES

			strSetOperations.add(zipToDestBatchUtil.getCurrentKey(getKeySpace()), hashKey);

			LOGGER.info("Saving Current Records Json with HashKey : {}", hashKey);
			strHashOperations.put(zipToDestBatchUtil.getJSONCurrentRecordsKey(getKeySpace()), hashKey, zipToDest.toJson(hashKey));

			strSortedSetOperations.add(
					zipToDestBatchUtil.getRedisKey(getKeySpace(),
							AppConstants.APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY),
					hashKey, zipToDest.getProcessedDateTime());

			LOGGER.info("Removing newly processed transction from created timestamp data structure.");

			strSortedSetOperations.removeRangeByScore(
					zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.APP_TRANSACTION_SAVE_CREATION_TMSTAMP_KEY),
					zipToDest.getCreatedDateAt(), zipToDest.getCreatedDateAt());

			// dISTRIBUTION QUERY
			strSetOperations.add(zipToDestBatchUtil.getNetworkKey(getKeySpace(), zipToDest.getNetwork()), hashKey);

			strSetOperations.add(zipToDestBatchUtil.getNetworkZipCodeKey(getKeySpace(), zipToDest.getNetwork(),
					zipToDest.getZipCode()), hashKey);

			strSetOperations.add(zipToDestBatchUtil.getFacilityIdKey(getKeySpace(), zipToDest.getDestinationTerminal()),
					hashKey);

			strSetOperations.add(zipToDestBatchUtil.getNetworkCountryCodeKey(getKeySpace(), zipToDest.getNetwork(),
					zipToDest.getCountryCode()), hashKey);

			strSetOperations.add(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.APP_ZIPTODEST_NETWORK_KEY),
					zipToDest.getNetwork());
			
			strSortedSetOperations.add(zipToDestBatchUtil.getCurrentByProcessedDate(getKeySpace(), zipToDest.getNetwork(),
					zipToDest.getCountryCode(), AppConstants.PROCESSED_DT), hashKey,
					zipToDest.getProcessedDateTime());

			//Batch Query
			strSetOperations.add(zipToDestBatchUtil.getProcessedByNetworkAndZipCodeKey(getKeySpace(), zipToDest.getNetwork(),
					zipToDest.getZipCode()), hashKey);

		} else {
			
			LOGGER.info("Saving History Records with HashKey : {}", hashKey);			
			if (!AppConstants.TRANSACTION_TYPE_DELETE.equals(zipToDest.getTransactionType())) {
				LOGGER.info("Deletng HashKey : {}, from Current Records", hashKey);
				deleteCurrentTransaction(zipToDest);
			}

			strSortedSetOperations.removeRangeByScore(
					zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.APP_TRANSACTION_SAVE_CREATION_TMSTAMP_KEY),
					zipToDest.getCreatedDateAt(), zipToDest.getCreatedDateAt());
			
			strSortedSetOperations.add(
					zipToDestBatchUtil.getRedisKey(getKeySpace(),
							AppConstants.APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY),
					hashKey, zipToDest.getProcessedDateTime());
			
			strSortedSetOperations.removeRangeByScore(zipToDestBatchUtil.getCurrentByProcessedDate(getKeySpace(), zipToDest.getNetwork(),
					zipToDest.getCountryCode(), AppConstants.PROCESSED_DT), zipToDest.getProcessedDateTime(), zipToDest.getProcessedDateTime());

			strSetOperations.add(zipToDestBatchUtil.getHistoryTransactionKey(getKeySpace()), hashKey);
			
			strRedisTemplate.expire(hashKey, getHistoryRecordsTtl(), TimeUnit.DAYS);

		}

	}

	public void removeOldProcessedKey(ZipToDest zipToDest) {
		String hashKey = zipToDestBatchUtil.zipToDestHashKey(getKeySpace(), zipToDest);
		
		Long count = strSetOperations.remove(zipToDestBatchUtil.getProcessedByNetworkAndZipCodeKey(getKeySpace(), zipToDest.getNetwork(),
				zipToDest.getZipCode()), hashKey);
		LOGGER.info("Removing old hashkey from processed_recordsNetworkZipcode set : {}, remove count : {}", hashKey, count);

	}	

	public void saveFutureTransaction(ZipToDest zipToDest) {
		String hashKey = zipToDestBatchUtil.zipToDestHashKey(getKeySpace(), zipToDest);
		strHashOperations.putAll(hashKey, zipToDestMapper.toMap(zipToDest));
		strSetOperations.add(zipToDestBatchUtil.getFutureKey(getKeySpace()), hashKey);
	}	

	/**
	 * 
	 * 
	 * @param utcTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ZipToDest> findUnProcessedTransactions(Long utcTime) {
		List<ZipToDest> result = Collections.emptyList();
		try {
			Set<String> primaryKeys = hashSetOperations.findPrimaryKeys(zipToDestBatchUtil.getFutureKey(getKeySpace()));

			LOGGER.info("ids : {}", primaryKeys);

			if (primaryKeys != null && !primaryKeys.isEmpty()) {
				List<Object> resultSet = hashSetOperations.getHashesFromRedis(primaryKeys);

				LOGGER.info("resultSet : {}", resultSet);

				if (resultSet != null && !resultSet.isEmpty()) {
					result = new ArrayList<>();
					for (Object obj : resultSet) {

						ZipToDest zipToDest = zipToDestMapper.toZipToDest((Map<String, String>) obj);
						LOGGER.info("zipToDest : {}", zipToDest);
						LOGGER.info("utcTime : {}", utcTime);
						if (zipToDest.getEffectiveDateAt() <= utcTime) {
							result.add(zipToDest);
						}
					}
				}

			}

		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}

		return result;
	}

	public List<ZipToDest> findOlderTransactions(String network, String zipCode, Long currentUtcTime) {
		List<ZipToDest> output = Collections.emptyList();
		List<ZipToDest> olderTransactions = findByNetworkAndZipCodeAndProcessed(network, zipCode);
		if (!olderTransactions.isEmpty()) {
			output = olderTransactions.stream().filter(trans -> trans.getEffectiveDateAt() <= currentUtcTime)
					.collect(Collectors.toList());
		}
		return output;
	}

	/**
	 * 
	 * @param network
	 * @param zipCode
	 * @param processed
	 * @return
	 */
	public List<ZipToDest> findByNetworkAndZipCodeAndProcessed(String network, String zipCode) {
		List<ZipToDest> result = new ArrayList<>();
		String key = zipToDestBatchUtil.getProcessedByNetworkAndZipCodeKey(getKeySpace(), network, zipCode);
		
		LOGGER.info("Getting keys from Key : {}",key);
		
		Set<String> primaryKeys = hashSetOperations.findPrimaryKeys(key);
		
		ZipToDest trasaction = null;
		LOGGER.info("Getting Older Transactions fro following keys : ",key);
		List<Object> resultSet = hashSetOperations.getHashesFromRedis(primaryKeys);

		if (resultSet != null && !resultSet.isEmpty()) {
			for (Object map : resultSet) {
				trasaction = zipToDestMapper.toZipToDest((Map<String, String>) map);
				LOGGER.info("Old Currently Active Transaction : {}", trasaction);
				result.add(trasaction);
			}
		}
		return result;
	}

	/**
	 * 
	 * @param processed
	 * @param current
	 * @param cancelledFlag
	 * @return
	 */
	public List<ZipToDest> findByProcessedAndCurrentAndCancelledFlag(String recordType) {
		List<ZipToDest> result = new ArrayList<>();
		String key = "";
		if (AppConstants.CURRENT_RECORDS.equalsIgnoreCase(recordType)) {
			key = zipToDestBatchUtil.getCurrentKey(getKeySpace());
		} else if (AppConstants.FUTURE_RECORDS.equalsIgnoreCase(recordType)) {
			key = zipToDestBatchUtil.getFutureKey(getKeySpace());
		} else {
			key = zipToDestBatchUtil.getHistoryTransactionKey(getKeySpace());
		}

		Set<String> primaryKeys = hashSetOperations.findPrimaryKeys(key);

		List<Object> resultSet = hashSetOperations.getHashesFromRedis(primaryKeys);

		if (resultSet != null && !resultSet.isEmpty()) {
			for (Object map : resultSet) {
				ZipToDest zipToDest = zipToDestMapper.toZipToDest((Map<String, String>) map);
				if (zipToDest.getId() != null) {
					result.add(zipToDest);
				}
			}
		}
		return result;
	}

	public void deleteFutureTransaction(ZipToDest zipToDest) {
		String hashKey = zipToDestBatchUtil.zipToDestHashKey(getKeySpace(), zipToDest);

		LOGGER.info("Removing hashk key {} from FUTURE RECORDS", hashKey);
		hashSetOperations.deletePrimaryKey(zipToDestBatchUtil.getFutureKey(getKeySpace()), hashKey);

		strSetOperations.remove(zipToDestBatchUtil.getFutureNetworkKey(getKeySpace(), zipToDest.getNetwork()), hashKey);

		strSetOperations.remove(zipToDestBatchUtil.getFutureNetworkZipCodeKey(getKeySpace(), zipToDest.getNetwork(), zipToDest.getZipCode()), hashKey);
	}

	public void deleteCurrentTransaction(ZipToDest zipToDest) {

		String hashKey = zipToDestBatchUtil.zipToDestHashKey(getKeySpace(), zipToDest);
		
		hashSetOperations.deletePrimaryKey(zipToDestBatchUtil.getCurrentKey(getKeySpace()), hashKey);

		strHashOperations.delete(zipToDestBatchUtil.getJSONCurrentRecordsKey(getKeySpace()), hashKey);

		strSetOperations.remove(zipToDestBatchUtil.getNetworkKey(getKeySpace(), zipToDest.getNetwork()), hashKey);

		strSetOperations.remove(
				zipToDestBatchUtil.getNetworkZipCodeKey(getKeySpace(), zipToDest.getNetwork(), zipToDest.getZipCode()),
				hashKey);

		strSetOperations.remove(zipToDestBatchUtil.getFacilityIdKey(getKeySpace(), zipToDest.getDestinationTerminal()),
				hashKey);

		strSetOperations.remove(zipToDestBatchUtil.getNetworkCountryCodeKey(getKeySpace(), zipToDest.getNetwork(),
				zipToDest.getCountryCode()), hashKey);
	}

	public void saveHistoryTransaction(ZipToDest zipToDest) {
		String hashKey = zipToDestBatchUtil.zipToDestHashKey(getKeySpace(), zipToDest);
		strHashOperations.putAll(hashKey, zipToDestMapper.toMap(zipToDest));
		strSetOperations.add(zipToDestBatchUtil.getHistoryTransactionKey(getKeySpace()), hashKey);
	}

	public Long deleteLastProcessedHashKeys() {		
		Long count = strSortedSetOperations.removeRangeByScore(
				zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY),
				0, Long.MAX_VALUE);
		
		LOGGER.info("Removing last processed hashkeys from {} sorted set", AppConstants.APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY,  count);
		
		return count;
	}
}
