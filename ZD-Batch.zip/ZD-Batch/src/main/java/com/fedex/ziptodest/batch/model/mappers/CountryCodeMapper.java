package com.fedex.ziptodest.batch.model.mappers;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.util.Fields;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.CountryCode;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class CountryCodeMapper {
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * 
	 * @param map
	 * @return
	 */
	public CountryCode toCountryCode(Map<String, String> map) {

		CountryCode countryCode = new CountryCode();

		countryCode.setCyclcu(StringUtils.isBlank(map.get(Fields.CY_CLCU)) ? null : Integer.parseInt(map.get(Fields.CY_CLCU)));
		countryCode.setCycode(map.get(Fields.CY_CODE));


		return countryCode;
	}
	
	/**
	 * 
	 * @param map
	 * @return
	 */
	public String toJson(Map<String, String> map){
		StringBuilder builder = new StringBuilder();
		builder.append("{");
		builder.append(Fields.CY_CLCU).append(":").append(map.get(Fields.CY_CLCU)).append(",");
		builder.append(Fields.CY_CODE).append(":").append(map.get(Fields.CY_CODE));		
		builder.append("}");
		return builder.toString();
	}

	/**
	 * 
	 * @param countryCode
	 * @return
	 */
	public Map<String, String> toMap(CountryCode countryCode) {
		Map<String, String> map = new HashMap<>();

		map.put(Fields.CY_CLCU, zipToDestBatchUtil.stringValueOf(countryCode.getCyclcu()));
		map.put(Fields.CY_CODE, zipToDestBatchUtil.stringValueOf(countryCode.getCycode()));
		
		return map;
	}
}
