package com.fedex.ziptodest.batch.config;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Component;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class IseriesJdbcTemplate {

	@Autowired
	Environment environment;
	
	private JdbcTemplate jdbcTemplate;

	@PostConstruct
	public void init() {
		jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(getIseriesDataSource());
	}

	private DataSource getIseriesDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getProperty("iseries.datasource.driver-class-name"));
		dataSource.setPassword(environment.getProperty("iseries.datasource.password"));
		dataSource.setUsername(environment.getProperty("iseries.datasource.username"));
		dataSource.setUrl(environment.getProperty("iseries.datasource.jdbc-url"));
		return dataSource;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
}
