package com.fedex.ziptodest.batch.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.exception.BatchProcessInterruptedException;
import com.fedex.ziptodest.batch.model.mappers.StateProvinceMapper;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.commons.HashSetOperations;
import com.fedex.ziptodest.model.StateProvince;

@Component
public class StateProvinceDao {

	public static final Logger LOGGER = LoggerFactory.getLogger(StateProvinceDao.class);

	@Autowired
	@Qualifier("strRedisTemplate")
	RedisTemplate<String, String> strRedisTemplate;

	@Resource(name = "strRedisTemplate")
	HashOperations<String, String, String> strHashOperations;

	@Resource(name = "strRedisTemplate")
	SetOperations<String, String> strSetOperations;

	@Autowired
	StateProvinceMapper stateProvinceMapper;

	@Autowired
	HashSetOperations hashSetOperations;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	@Value(value = "${keyspace}")
	private String keyspace;

	/**
	 * 
	 * @param stateProvince
	 * @return
	 */
	public StateProvince save(StateProvince stateProvince) {
		StateProvince result = null;
		try {

			String hashKey = zipToDestBatchUtil.getIseriesStateProvinceKey(keyspace, stateProvince.getStaPro());

			strHashOperations.putAll(hashKey, stateProvinceMapper.toMap(stateProvince));

			strSetOperations.add(
					zipToDestBatchUtil.getIseriesKey(keyspace, AppConstants.ISERIES_STATE_PROVINCE_SET_KEY), hashKey);

			if (stateProvince.getCntryc() != null) {
				 strSetOperations.add(zipToDestBatchUtil.getIseriesStateProCountryKey(keyspace, stateProvince.getCntryc()),
						 hashKey);
			}

			result = stateProvince;
		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}
		return result;
	}

	/**
	 * 
	 * @param stateProvinces
	 */
	@SuppressWarnings("unchecked")
	public void saveAll(List<StateProvince> stateProvinces) {

		try {
			strRedisTemplate.executePipelined(new SessionCallback<List<Object>>() {

				@Override
				public List<Object> execute(RedisOperations redisOperations) throws DataAccessException {
					String hashKey = "";
					for (StateProvince stateProvince : stateProvinces) {
						hashKey = zipToDestBatchUtil.getIseriesStateProvinceKey(keyspace, stateProvince.getStaPro());

						redisOperations.opsForHash().putAll(hashKey, stateProvinceMapper.toMap(stateProvince));

						redisOperations.opsForSet().add(
								zipToDestBatchUtil.getIseriesKey(keyspace, AppConstants.ISERIES_STATE_PROVINCE_SET_KEY),
								hashKey);

						if (stateProvince.getCntryc() != null) {
							 strSetOperations.add(zipToDestBatchUtil.getIseriesStateProCountryKey(keyspace, stateProvince.getCntryc()),
									 hashKey);
						}
					}
					return null;
				}

			});
		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> findAll() {

		List<String> result = Collections.emptyList();
		try {
			Set<String> primaryKeys = hashSetOperations.findPrimaryKeys(
					zipToDestBatchUtil.getIseriesKey(keyspace, AppConstants.ISERIES_STATE_PROVINCE_SET_KEY));

			if (primaryKeys != null && !primaryKeys.isEmpty()) {
				List<Object> resultSet = hashSetOperations.getHashesFromRedis(primaryKeys);

				if (resultSet != null && !resultSet.isEmpty()) {
					result = new ArrayList<>();
					for (Object obj : resultSet) {
						result.add(stateProvinceMapper.toJson((Map<String, String>) obj));
					}
				}

			}

		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}

		return result;
	}
}
