package com.fedex.ziptodest.batch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.batch.service.DataLoaderService;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

@RestController
@RequestMapping("/batchrepo")
public class TransactionController {

	@Autowired
	DataLoaderService dataLoaderService;

	@GetMapping("/allCurrentTransactions")
	public List<ZipToDest> findAllCurrentTransaction() {
		return dataLoaderService.findAllCurrentTransaction();
	}

	@GetMapping("/allFutureTransactions")
	public List<ZipToDest> findAllFutureTransaction() {
		return dataLoaderService.findAllFutureTransaction();
	}
	
	@GetMapping("/allHistoryTransactions")
	public List<ZipToDest> findAllHistoryTransaction() {
		return dataLoaderService.findAllHistoryTransaction();
	}
	
	@GetMapping("/allFacilityHasDelta")
	public List<ZipToDestHasDelta> findAllFacilityHasDelta() {
		return dataLoaderService.findAllFacilityHasDelta();
	}
}
