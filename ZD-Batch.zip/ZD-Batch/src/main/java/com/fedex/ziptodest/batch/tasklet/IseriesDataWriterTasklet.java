package com.fedex.ziptodest.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.dao.CountryCodeDao;
import com.fedex.ziptodest.batch.dao.DestinationDao;
import com.fedex.ziptodest.batch.dao.NetworkDao;
import com.fedex.ziptodest.batch.dao.StateProvinceDao;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.CountryCode;
import com.fedex.ziptodest.model.Destination;
import com.fedex.ziptodest.model.Network;
import com.fedex.ziptodest.model.StateProvince;

@Component
public class IseriesDataWriterTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(IseriesDataWriterTasklet.class);

	@Autowired
	CountryCodeDao countryCodeDao;

	@Autowired
	NetworkDao networkDao;

	@Autowired
	DestinationDao destinationDao;

	@Autowired
	StateProvinceDao stateProvinceDao;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

		ExecutionContext context = zipToDestBatchUtil.getCurrentExecutionContext(chunkContext);

		@SuppressWarnings("unchecked")
		List<CountryCode> countryCodes = (List<CountryCode>) context.get(AppConstants.ISERIES_COUNTRY_CODE_SET_KEY);

		@SuppressWarnings("unchecked")
		List<Network> networks = (List<Network>) context.get(AppConstants.ISERIES_NETWORK_SET_KEY);

		@SuppressWarnings("unchecked")
		List<Destination> destinations = (List<Destination>) context.get(AppConstants.ISERIES_DESTINATION_SET_KEY);

		@SuppressWarnings("unchecked")
		List<StateProvince> stateProvinces = (List<StateProvince>) context.get(AppConstants.ISERIES_STATE_PROVINCE_SET_KEY);

		LOGGER.info("Writing Country Codes count : {}", countryCodes.size());
		LOGGER.info("Writing Network count : {}", networks.size());
		LOGGER.info("Writing Destination count : {}", destinations.size());
		LOGGER.info("Writing State Province count : {}", stateProvinces.size());

		if (!countryCodes.isEmpty()) {
			saveCountryCode(countryCodes);
		}

		if (!networks.isEmpty()) {
			saveNetwork(networks);
		}

		if (!destinations.isEmpty()) {
			saveDestination(destinations);
		}

		if (!stateProvinces.isEmpty()) {
			saveStateProvince(stateProvinces);
		}

		return RepeatStatus.FINISHED;
	}

	private void saveCountryCode(List<CountryCode> countryCodes) {
		LOGGER.info("Writing Country Code to Redis");
		countryCodeDao.saveAll(countryCodes);
		LOGGER.info("Writing Country Code to Redis Finished");
	}

	private void saveNetwork(List<Network> networks) {
		LOGGER.info("Writing Networks to Redis");
		networkDao.saveAll(networks);
		LOGGER.info("Writing Networks to Redis Finished.");
	}

	private void saveDestination(List<Destination> destinations) {
		LOGGER.info("Writing Destinations to Redis...");
		destinationDao.saveAll(destinations);
		LOGGER.info("Writing  Destinations Finished.");
	}

	private void saveStateProvince(List<StateProvince> stateProvinces) {
		LOGGER.info("Writing StateProvinces to Redis");
		stateProvinceDao.saveAll(stateProvinces);
		LOGGER.info("Writing StateProvinces to Redis Finished.");
	}

}
