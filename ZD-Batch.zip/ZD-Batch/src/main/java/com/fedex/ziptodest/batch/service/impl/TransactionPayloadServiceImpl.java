package com.fedex.ziptodest.batch.service.impl;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.batch.dao.ZipToDestTransactionDao;
import com.fedex.ziptodest.batch.service.TransactionPayloadService;
import com.fedex.ziptodest.batch.util.CsvReader;
import com.fedex.ziptodest.model.ZipToDest;

@Service
public class TransactionPayloadServiceImpl implements TransactionPayloadService {

	public static final Logger LOGGER = LoggerFactory.getLogger(TransactionPayloadServiceImpl.class);

	@Autowired
	ZipToDestTransactionDao zipToDestTransactionDao;	

	@Override
	public void init() {
		saveZipToDest();
	}
	
	public boolean isCurrent(ZipToDest zipToDest) {
		return ("Y".equals(zipToDest.getProcessed()) && "Y".equals(zipToDest.getCurrent()));
	}
	
	public boolean isFuture(ZipToDest zipToDest) {
		return ("N".equals(zipToDest.getCancelledFlag()) && "N".equals(zipToDest.getProcessed()) && "N".equals(zipToDest.getCurrent()));
	}

	private void saveZipToDest() {
		CsvReader<ZipToDest> reader1 = new CsvReader<>();		
		List<ZipToDest> records1 = reader1.read(ZipToDest.class, "transactions.csv");		

		if (!records1.isEmpty()) {
			for (ZipToDest zipToDest : records1) {
				zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDest.setUuid(String.valueOf(System.currentTimeMillis()));
				zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
				zipToDest.buildKey();
				LOGGER.info("Transaction : {} ", zipToDest);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
				if (isCurrent(zipToDest)) {
					zipToDest.setProcessedDateTime(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
					zipToDestTransactionDao.saveCurrentTransaction(zipToDest);
				} else if(isFuture(zipToDest)) {
					zipToDestTransactionDao.saveFutureTransaction(zipToDest);
				}else{
					zipToDestTransactionDao.saveHistoryTransaction(zipToDest);
				}
			}
		}		

	}

}
