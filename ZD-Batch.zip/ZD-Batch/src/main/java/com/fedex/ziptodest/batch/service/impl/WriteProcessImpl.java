package com.fedex.ziptodest.batch.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.batch.service.WriteProcess;
import com.fedex.ziptodest.batch.service.ZipToDestTransactionService;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;

@Service
public class WriteProcessImpl implements WriteProcess{
	
	public static final Logger LOGGER = LoggerFactory.getLogger(WriteProcessImpl.class);
	
	@Autowired
	private ZipToDestTransactionService zipToDestTransactionService;

	@Override
	public int executeWriteProcess(ExecutionContext context, String transactionType, String keyUnprocessedType) {
		List<ZipToDest> olderTransactions;		
		int commitCount = 0;

		@SuppressWarnings("unchecked")
		List<ZipToDest> zipToDestList = (List<ZipToDest>) context.get(keyUnprocessedType);
		
		int executionCount = 0;
		if (!context.containsKey(AppConstants.KEY_EXECUTION_COUNT)) {
			context.putInt(AppConstants.KEY_EXECUTION_COUNT, executionCount);
		}
		
		if (!zipToDestList.isEmpty()) {
			
			Long jobDateTime = (Long) context.get(AppConstants.KEY_JOB_START_TIME);

			context.putInt(AppConstants.KEY_EXECUTION_COUNT, zipToDestList.size() + context.getInt(AppConstants.KEY_EXECUTION_COUNT));

			LOGGER.debug("{} Not processed {} transactions found for batch processing.",
					zipToDestList.size(), transactionType);			
			
			LOGGER.info("Getting older transactions from Transaction table and updating its current flag to 'N'...");
			for (ZipToDest zipToDest : zipToDestList) {
				LOGGER.info("Not Processed Transaction : {}", zipToDest);
				
				olderTransactions = zipToDestTransactionService.findOlderTransactions(zipToDest.getNetwork(),
						zipToDest.getZipCode());

				LOGGER.info(
						"{} Older Zip code association found for netweork - {} and Zipcode - {} in Transaction table.",
						olderTransactions.size(), zipToDest.getNetwork(), zipToDest.getZipCode());
				zipToDestTransactionService.updateOlderTransactions(olderTransactions, jobDateTime);
				commitCount++;
			}
			
			if(AppConstants.TRANSACTION_TYPE_MODIFY.equals(transactionType)){				
				zipToDestTransactionService.saveCurrentTransaction(zipToDestList, jobDateTime);
			}else{
				zipToDestTransactionService.deleteTransactions(zipToDestList, jobDateTime);				
			}
			
			zipToDestTransactionService.deleteFutureTransactions(zipToDestList);
			
		}else{
			LOGGER.info("Not Processed transactiona not availabel for processing.");
		}
		return commitCount;
	}

}
