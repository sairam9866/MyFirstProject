package com.fedex.ziptodest.batch.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.exception.BatchProcessInterruptedException;
import com.fedex.ziptodest.batch.model.mappers.NetworkMapper;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.commons.HashSetOperations;
import com.fedex.ziptodest.model.Network;

@Component
public class NetworkDao {

	public static final Logger LOGGER = LoggerFactory.getLogger(NetworkDao.class);

	@Value(value = "${keyspace}")
	private String keyspace;

	@Resource(name = "strRedisTemplate")
	private HashOperations<String, String, String> strHashOperations;

	@Resource(name = "strRedisTemplate")
	private SetOperations<String, String> strSetOperations;

	@Autowired
	@Qualifier("strRedisTemplate")
	RedisTemplate<String, String> strRedisTemplate;

	@Autowired
	NetworkMapper networkMapper;

	@Autowired
	HashSetOperations hashSetOperations;

	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * 
	 * @return
	 */
	public String getKeySpace() {
		return this.keyspace;
	}

	/**
	 * 
	 * @param network
	 * @return
	 */
	public Network save(Network network) {
		Network result = null;
		try {

			String hashKey = zipToDestBatchUtil.getIseriesNetworkKey(keyspace, network.getNetworkId());

			strHashOperations.putAll(hashKey, networkMapper.toMap(network));

			strSetOperations.add(zipToDestBatchUtil.getIseriesKey(keyspace, AppConstants.ISERIES_NETWORK_SET_KEY),
					hashKey);

			strSetOperations.add(zipToDestBatchUtil.getIseriesKey(getKeySpace(), AppConstants.HASH_KEY_NETWORK),
					network.getNetworkId());

			result = network;
		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}
		return result;
	}

	/**
	 * 
	 * @param networks
	 */
	@SuppressWarnings("unchecked")
	public void saveAll(List<Network> networks) {
		try {
			List<Object> result = strRedisTemplate.executePipelined(new SessionCallback<List<Map<String, String>>>() {

				@Override
				public List<Map<String, String>> execute(RedisOperations redisOperations) throws DataAccessException {

					String hashKey = "";
					for (Network network : networks) {
						hashKey = zipToDestBatchUtil.getIseriesNetworkKey(keyspace, network.getNetworkId());

						redisOperations.opsForHash().putAll(hashKey, networkMapper.toMap(network));

						redisOperations.opsForSet().add(
								zipToDestBatchUtil.getIseriesKey(keyspace, AppConstants.ISERIES_NETWORK_SET_KEY),
								hashKey);

						redisOperations.opsForSet().add(
								zipToDestBatchUtil.getIseriesKey(getKeySpace(), AppConstants.HASH_KEY_NETWORK),
								network.getNetworkId());
					}

					return null;
				}

			});
		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}

	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<String> findAll() {
		List<String> result = Collections.emptyList();
		try {
			String setKey = zipToDestBatchUtil.getIseriesKey(keyspace, AppConstants.ISERIES_NETWORK_SET_KEY);
			Set<String> primaryKeys = hashSetOperations.findPrimaryKeys(setKey);

			if (primaryKeys != null && !primaryKeys.isEmpty()) {
				List<Object> resultSet = hashSetOperations.getHashesFromRedis(primaryKeys);

				if (resultSet != null && !resultSet.isEmpty()) {
					result = new ArrayList<>();
					for (Object obj : resultSet) {
						result.add(networkMapper.toJson((Map<String, String>) obj));
					}
				}
			}

		} catch (Exception e) {
			throw new BatchProcessInterruptedException(e);
		}

		return result;
	}

}
