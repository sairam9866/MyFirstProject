package com.fedex.ziptodest.batch.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.model.mappers.ZipToDestHasDeltaMapper;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.commons.HashSetOperations;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

/**
 * 
 * @author 3818669
 *
 */
@Component
public class ZipToDestHasDeltaDao {

	@Value(value = "${keyspace}")
	private String keyspace;

	@Resource(name = "strRedisTemplate")
	private ZSetOperations<String, String> sortedSetOperations;

	@Resource(name = "strRedisTemplate")
	private HashOperations<String, String, String> strHashOperations;
	
	@Autowired
	HashSetOperations hashSetOperations;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	@Autowired
	ZipToDestHasDeltaMapper zipToDestHasDeltaMapper;

	/**
	 * 
	 * @return
	 */
	public String getKeySpace() {
		return this.keyspace;
	}

	public ZipToDestHasDelta save(ZipToDestHasDelta zipToDestHasDelta) {
		String hashKey = zipToDestBatchUtil.getFacilityHasDeltaKey(keyspace, zipToDestHasDelta.getNetwork());

		strHashOperations.putAll(hashKey, zipToDestHasDeltaMapper.toMap(zipToDestHasDelta));
		
		sortedSetOperations.add(zipToDestBatchUtil.getHasDeltaLastProcessed(keyspace,
				zipToDestHasDelta.getNetwork(), AppConstants.PROCESSED_DT), hashKey,
				zipToDestHasDelta.getLastUpdateTimestamp());

		sortedSetOperations.add(
				zipToDestBatchUtil.getFacilityHasDeltaKey(getKeySpace(), AppConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY),
				hashKey, zipToDestHasDelta.getLastUpdateTimestamp());
		return zipToDestHasDelta;
	}

	/**
	 * 
	 * @return
	 */
	public List<ZipToDestHasDelta> findAll() {
		List<ZipToDestHasDelta> result = new ArrayList<>();
		Set<String> primaryKeys = sortedSetOperations.range(
				zipToDestBatchUtil.getFacilityHasDeltaKey(getKeySpace(), AppConstants.ZIP_TO_DEST_HAS_DELTA_HASH_KEY),
				0, -1);
		
		List<Object> resultSet = hashSetOperations.getHashesFromRedis(primaryKeys);
		
		if(resultSet != null && !resultSet.isEmpty()){
			for(Object obj : resultSet){
				result.add(zipToDestHasDeltaMapper.toZipToDestHasDelta((Map<String, String>) obj));
			}
		}
		
		return result;
	}
}
