package com.fedex.ziptodest.batch.service;

import java.util.List;

import com.fedex.ziptodest.model.ZipToDest;

/**
 * 
 * @author 3818669
 *
 */
public interface ZipToDestTransactionService {	

	public List<ZipToDest> findOlderTransactions(String netwrok, String zipCode);	

	public void updateOlderTransactions(List<ZipToDest> zipToDests, Long processedAt);	
	
	public List<ZipToDest> findUnProcessedTransactions(Long utcTime);
	
	public void saveCurrentTransaction(List<ZipToDest> zipToDests, Long processedAt);

	public void deleteFutureTransactions(List<ZipToDest> zipToDestList);

	public void deleteCurrentTransactions(List<ZipToDest> zipToDestList);
	
	public void deleteTransactions(List<ZipToDest> zipToDests, Long processedDateTime);	
	
	public Long deleteLastProcessedHashKeys();
}
