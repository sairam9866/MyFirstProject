package com.fedex.ziptodest.commons;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

@Component
public class HashSetOperations {

	public static final Logger LOGGER = LoggerFactory.getLogger(HashSetOperations.class);

	@Autowired
	@Qualifier("strRedisTemplate")
	RedisTemplate<String, String> strRedisTemplate;

	@Resource(name = "strRedisTemplate")
	private SetOperations<String, String> strSetOperations;

	@Resource(name = "strRedisTemplate")
	private ZSetOperations<String, String> strSortedSetOperations;

	/**
	 * 
	 * @param setKey
	 * @return
	 */
	public Set<String> findPrimaryKeys(String setKey) {
		return strSetOperations.members(setKey);
	}

	public Set<String> findPrimaryKeysByScore(String key, long start, long end) {
		return strSortedSetOperations.rangeByScore(key, start, end);
	}
	
	public Long deletePrimaryKey(String key, String value){
		return strSetOperations.remove(key, value);
	}

	public List<Object> getHashesFromRedis(Set<String> ids) {
		List<Object> result = strRedisTemplate.executePipelined(new SessionCallback<List<Map<String, String>>>() {

			@Override
			public List<Map<String, String>> execute(RedisOperations operations) throws DataAccessException {				

				for (String id : ids) {
					LOGGER.info("hashKey : {}",id);
					Map<String, String> map = operations.opsForHash().entries(id);

				}

				return null;
			}

		});
		return result;
	}

}
