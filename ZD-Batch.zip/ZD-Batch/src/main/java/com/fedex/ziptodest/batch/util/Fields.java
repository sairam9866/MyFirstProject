package com.fedex.ziptodest.batch.util;

public class Fields {

	// iSeries Country Code fields
	public static final String CY_CODE = "cycode";

	public static final String CY_CLCU = "cyclcu";

	// iSeries Network Fields
	public static final String CREATED_BY = "created_by";

	public static final String MODEL_TYPE = "model_type";

	public static final String NETWORK_ID = "network_id";

	public static final String UPDATED_BY = "updated_by";

	public static final String COLOC_NUM = "coloc_num";

	public static final String CREATED_DATE = "created_date";

	public static final String ROW_ID = "row_id";

	public static final String TERM_NUM = "term_num";

	public static final String UPDATED_DATE = "updated_date";

	// iSeries Destination Fields
	public static final String TERMINAL_ABBREVIATION = "terminal_abbreviation";
	
	public static final String TERMINAL_NUMBER = "terminal_number";
	
	public static final String TERMINAL_STATUS = "terminal_status";

	// iSeries State Province Fields
	public static final String CNTRYC = "cntryc";

	public static final String SP_NAME = "sp_name";

	public static final String STA_PRO = "sta_pro";

	//ZipToDest Fields
	public static final String ID = "id";

	public static final String NETWORK = "network";

	public static final String STATE = "state";

	public static final String TRANSACTION_TYPE = "transactionType";

	public static final String UUID = "uuid";

	public static final String ZIP_CODE = "zipCode";
	
	public static final String LAST_UPDATE_TIMESTAMP = "lastUpdateTimestamp";

	public static final String COUNTRY_CODE = "countryCode";

	public static final String LAST_UPDATE_BY = "lastUpdateBy";

	public static final String CANCELLED_FLAG = "cancelledFlag";
	
	public static final String CURRENT = "current";
	
	public static final String PROCESSED = "processed";
	
	public static final String ZIP_FROM = "zipFrom";
	
	public static final String ZIP_TO = "zipTo";
	
	public static final String DESTINATION_TERMINAL = "destinationTerminal";
	
	public static final String CREATION_USER = "creationUser";
	
	public static final String CANCELLED_USER = "cancelledUser";
	
	public static final String CREATED_DATE_AT = "createdDateAt";
	
	public static final String TIME_ZONE = "timeZone";
	
	public static final String PROCESSED_DATE_TIME = "processedDateTime";
	
	public static final String CANCELLED_TIMESTAMP = "cancelledTimestamp";
	
	public static final String EFFECTIVE_DATE_AT = "effectiveDateAt";
	
	//public static final String EFFECTIVE_DATE = "effectiveDate";	

	public static final transient String EFFECTIVE_DT = "effectiveDate";

	public static final transient String CREATION_DT = "creationDate";

	//public static final String PROCESSED_DT = "processedAt";

	public static final transient String CANCELLED_DT_AT = "cancelledAt";
	
	
	
	
	
	
	
}
