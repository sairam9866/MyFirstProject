package com.fedex.ziptodest.model;

import java.io.Serializable;

/**
 * 
 * @author 3818669
 *
 */

public class ZipToDestHasDelta implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6059972343845683398L;

	private String network;

	private Long lastUpdateTimestamp;

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public Long getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(Long lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((network == null) ? 0 : network.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ZipToDestHasDelta other = (ZipToDestHasDelta) obj;
		if (network == null) {
			if (other.network != null)
				return false;
		} else if (!network.equals(other.network)){
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "ZipToDestHasDelta [network=" + network + ", lastUpdateTimestamp=" + lastUpdateTimestamp + "]";
	}
}
