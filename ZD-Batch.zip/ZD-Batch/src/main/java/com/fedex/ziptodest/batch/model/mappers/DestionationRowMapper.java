package com.fedex.ziptodest.batch.model.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.ziptodest.model.Destination;

public class DestionationRowMapper  implements RowMapper<Destination>{

	@Override
	public Destination mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Destination destination = new Destination();
		destination.setTerminalAbbreviation(StringUtils.trim(rs.getString("TRMABR")));
		destination.setTerminalNumber(rs.getInt("TRMNUM"));
		destination.setTerminalStatus(StringUtils.trim(rs.getString("TRMSTS")));
		
		
		return destination;
	}

}
