package com.fedex.ziptodest.batch.exception;

public class BatchProcessInterruptedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6212870036635627314L;

	public BatchProcessInterruptedException(String message) {
		super(message);
	}

	public BatchProcessInterruptedException(String message, Throwable cause) {
		super(message, cause);
	}

	public BatchProcessInterruptedException(Throwable cause) {
		super(cause);
	}

}
