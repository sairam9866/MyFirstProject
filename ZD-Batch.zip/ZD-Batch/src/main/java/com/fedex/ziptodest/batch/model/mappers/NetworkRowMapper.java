package com.fedex.ziptodest.batch.model.mappers;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.ziptodest.model.Network;

public class NetworkRowMapper implements RowMapper<Network> {

	@Override
	public Network mapRow(ResultSet rs, int rowNum) throws SQLException {
		Network network = new Network();

		Date createdAt = rs.getDate("CREATED_DT");
		Date updatedAt = rs.getDate("UPDATED_DT");

		network.setColocNum(rs.getInt("COLOC_NUM"));
		network.setCreatedBy(StringUtils.trim(rs.getString("CREATED_BY")));
		network.setModelType(StringUtils.trim(rs.getString("MODEL_TYPE")));
		network.setNetworkId(StringUtils.trim(rs.getString("NETWORK_ID")));
		network.setRowId(rs.getInt("ROW_ID"));
		network.setTermNum(rs.getLong("TERM_NUM"));
		network.setUpdatedBy(StringUtils.trim(rs.getString("UPDATED_BY")));
		
		if (createdAt != null) {
			network.setCreatedDate(createdAt.toLocalDate());
		}
		if (updatedAt != null) {
			network.setUpdateDate(updatedAt.toLocalDate());
		}

		return network;
	}

}
