package com.fedex.ziptodest.batch.tasklet;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.config.IseriesJdbcTemplate;
import com.fedex.ziptodest.batch.model.mappers.CountryCodeRowMapper;
import com.fedex.ziptodest.batch.model.mappers.DestionationRowMapper;
import com.fedex.ziptodest.batch.model.mappers.NetworkRowMapper;
import com.fedex.ziptodest.batch.model.mappers.StateProvinceRowMapper;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.CountryCode;
import com.fedex.ziptodest.model.Destination;
import com.fedex.ziptodest.model.Network;
import com.fedex.ziptodest.model.StateProvince;

@Component
public class IseriesDataReaderTasklet implements Tasklet {

	public static final Logger LOGGER = LoggerFactory.getLogger(IseriesDataReaderTasklet.class);

	@Autowired
	IseriesJdbcTemplate iseriesJdbcTemplate;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {

		JdbcTemplate jdbcTemplate = iseriesJdbcTemplate.getJdbcTemplate();
		
		List<CountryCode> countryCodes = jdbcTemplate.query(AppConstants.SQL_ALL_COUNTRY_CODE,
				new CountryCodeRowMapper());
		
		List<Network> networks = jdbcTemplate.query(AppConstants.SQL_ALL_NETWORKS, new NetworkRowMapper());

		List<Destination> destinations = jdbcTemplate.query(AppConstants.SQL_ALL_DESTINATIONS,
				new DestionationRowMapper());

		List<StateProvince> stateProvinces = jdbcTemplate.query(AppConstants.SQL_ALL_STATE_PROVINCES,
				new StateProvinceRowMapper());

		LOGGER.info("Country Codes count : {}", countryCodes.size());
		LOGGER.info("Network count : {}", networks.size());
		LOGGER.info("Destination count : {}", destinations.size());
		LOGGER.info("State Province count : {}", stateProvinces.size());

		ExecutionContext context = zipToDestBatchUtil.getCurrentExecutionContext(chunkContext);

		context.put(AppConstants.ISERIES_COUNTRY_CODE_SET_KEY, countryCodes);
		context.put(AppConstants.ISERIES_NETWORK_SET_KEY, networks);
		context.put(AppConstants.ISERIES_DESTINATION_SET_KEY, destinations);
		context.put(AppConstants.ISERIES_STATE_PROVINCE_SET_KEY, stateProvinces);

		return RepeatStatus.FINISHED;
	}

}
