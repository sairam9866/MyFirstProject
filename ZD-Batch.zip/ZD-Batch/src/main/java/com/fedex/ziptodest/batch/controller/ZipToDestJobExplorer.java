package com.fedex.ziptodest.batch.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.JobAuditResponse;

/**
 * 
 * @author 3818669
 *
 */

@RestController
@RequestMapping("/batch")
public class ZipToDestJobExplorer {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestJobExplorer.class);

	@Autowired
	private JobExplorer jobExplorer;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	/**
	 * Method to get the all scheduled job names from job repository.
	 * 
	 * @return - A List of job names.
	 */
	@GetMapping("/alljobs")
	public ResponseEntity<List<String>> getAllJobNames() {
		return new ResponseEntity<>(jobExplorer.getJobNames(), HttpStatus.OK);
	}

	/**
	 * Method to get the job audit information like job start time, finished
	 * time and job status etc..
	 * 
	 * @param jobName
	 *            - job name.
	 * 
	 * @return - Job audit details.
	 */
	@GetMapping("/job/{jobName}")
	public ResponseEntity<List<JobAuditResponse>> getJobExecution(@PathVariable("jobName") String jobName) {
		int counter = 0;
		int size = 10;
		List<JobAuditResponse> auditResponse = new ArrayList<>();
		List<JobInstance> jobInstances = jobExplorer.findJobInstancesByJobName(jobName, 0, Integer.MAX_VALUE);
		if (!jobInstances.isEmpty()) {
			LOGGER.info("There are {} job instances for the job {}", jobInstances.size(), jobName);
			for (JobInstance instance : jobInstances) {
				List<JobExecution> jobExecutions = jobExplorer.getJobExecutions(instance);

				LOGGER.info("Instance {} had {} executions", instance.getInstanceId(), jobExecutions.size());

				for (JobExecution jobExecution : jobExecutions) {
					auditResponse.add(zipToDestBatchUtil.instanceOfJobAuditResponse(jobExecution));
					LOGGER.info("\tExecution {} resulted in Exit Status {}", jobExecution.getId(),
							jobExecution.getExitStatus());
					counter++;					
				}
				if (counter == size) {
					break;
				}
			}
		}
		return new ResponseEntity<>(auditResponse, HttpStatus.OK);
	}

}
