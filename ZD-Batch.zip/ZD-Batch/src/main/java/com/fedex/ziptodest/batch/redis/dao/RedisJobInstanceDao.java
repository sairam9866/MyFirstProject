package com.fedex.ziptodest.batch.redis.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.DefaultJobKeyGenerator;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobKeyGenerator;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.repository.dao.JobInstanceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.fedex.ziptodest.batch.redis.dao.model.RedisJobExecution;
import com.fedex.ziptodest.batch.redis.dao.model.RedisJobInstance;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

@Repository
public class RedisJobInstanceDao extends KeyExpirationConfig implements JobInstanceDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(RedisJobInstanceDao.class);

	@Value(value = "${keyspace}")
	private String keyspace;

	@Resource(name = "redisTemplate")
	ZSetOperations<String, RedisJobInstance> opsJobInstanceSortedSet;

	@Resource(name = "redisTemplate")
	ZSetOperations<String, String> opsJobInstanceString;

	@Resource(name = "redisTemplate")
	ZSetOperations<String, RedisJobExecution> opsJobExecutionSortedSet;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	private JobKeyGenerator<JobParameters> jobKeyGenerator = new DefaultJobKeyGenerator();

	@Override
	public JobInstance createJobInstance(String jobName, JobParameters jobParameters) {
		Assert.notNull(jobName, "Job name must not be null.");
		Assert.notNull(jobParameters, "JobParameters must not be null.");

		Assert.state(getJobInstance(jobName, jobParameters) == null, "JobInstance must not already exist");

		Long jobId = System.currentTimeMillis();

		RedisJobInstance redisJobInstance = new RedisJobInstance(jobId, jobName);
		redisJobInstance.setJobKey(jobKeyGenerator.generateKey(jobParameters));
		redisJobInstance.incrementVersion();

		JobInstance jobInstance = new JobInstance(jobId, jobName);
		jobInstance.incrementVersion();

		opsJobInstanceSortedSet.add(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY),
				redisJobInstance, redisJobInstance.getJobInstanceId());

		opsJobInstanceString.add(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_STRING_KEY),
				redisJobInstance.getJobName(), redisJobInstance.getJobInstanceId());

		setTimeToLive(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY));
		setTimeToLive(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_STRING_KEY));

		return jobInstance;
	}

	@Override
	public JobInstance getJobInstance(String jobName, JobParameters jobParameters) {
		Assert.notNull(jobName, "Job name must not be null.");
		Assert.notNull(jobParameters, "JobParameters must not be null.");

		String jobKey = jobKeyGenerator.generateKey(jobParameters);

		JobInstance output = null;

		Set<RedisJobInstance> redisJobInstances = opsJobInstanceSortedSet
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0, -1);

		List<JobInstance> result = mapToJobInstances(jobName, jobKey, redisJobInstances);

		if (!result.isEmpty()) {
			Assert.state(result.size() == 1, "instance count must be 1 but was " + result.size());
			output = result.get(0);
		}
		return output;
	}

	@Override
	public JobInstance getJobInstance(Long instanceId) {
		
		JobInstance jobInstance = null;

		Set<RedisJobInstance> setjobInstances = opsJobInstanceSortedSet.rangeByScore(
				zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), instanceId,
				instanceId);
		if (!setjobInstances.isEmpty()) {
			RedisJobInstance instance = setjobInstances.iterator().next();
			jobInstance = new JobInstance(instance.getJobInstanceId(), instance.getJobName());
			jobInstance.incrementVersion();
		}

		return jobInstance;
	}

	@Override
	public JobInstance getJobInstance(JobExecution jobExecution) {
		
		Set<RedisJobInstance> redisJobInstances = opsJobInstanceSortedSet
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0, -1);
		Set<RedisJobExecution> redisJobExecutions = opsJobExecutionSortedSet
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY), 0, -1);
		if (!redisJobInstances.isEmpty() && !redisJobExecutions.isEmpty()) {
			for (RedisJobInstance ji : redisJobInstances) {
				for (RedisJobExecution je : redisJobExecutions) {
					if (je.getJobExecutionId().equals(jobExecution.getId())
							&& ji.getJobInstanceId().equals(je.getJobInstanceId())) {
						JobInstance jobInstance = new JobInstance(ji.getJobInstanceId(), ji.getJobName());
						// should always be at version=0 because they never get
						// updated
						jobInstance.incrementVersion();
						return jobInstance;
					}
				}
			}
		}
		return null;
	}

	@Override
	public List<JobInstance> getJobInstances(String jobName, int start, int count) {
		
		List<JobInstance> result = new ArrayList<>();
		JobInstance jobInstance = null;
		Set<RedisJobInstance> redisJobInstances = opsJobInstanceSortedSet
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0, -1);
		if (!redisJobInstances.isEmpty()) {
			for (RedisJobInstance redisJobInstance : redisJobInstances) {
				if (redisJobInstance.getJobName().equals(jobName)) {
					jobInstance = new JobInstance(redisJobInstance.getJobInstanceId(), redisJobInstance.getJobName());
					result.add(jobInstance);
				}
			}
		}

		result = sortDescending(result);

		return subset(result, start, count);

	}

	@Override
	public List<String> getJobNames() {
		
		List<String> result = new ArrayList<>();
		Set<String> setJobNames = opsJobInstanceString
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_STRING_KEY), 0, -1);
		
		if (!setJobNames.isEmpty()) {
			result = setJobNames.stream().collect(Collectors.toList());			
		}
		Collections.sort(result);
		return result;
	}

	@Override
	public List<JobInstance> findJobInstancesByName(String jobName, int start, int count) {
		
		LOGGER.info("jobName : {}", jobName);
		String convertedJobName = jobName.replaceAll(AppConstants.STAR_WILDCARD, AppConstants.STAR_WILDCARD_PATTERN);

		List<JobInstance> result = new ArrayList<>();
		JobInstance jobInstance = null;
		Set<RedisJobInstance> redisJobInstances = opsJobInstanceSortedSet
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0, -1);
		if (!redisJobInstances.isEmpty()) {
			for (RedisJobInstance redisJobInstance : redisJobInstances) {
				if (redisJobInstance.getJobName().matches(convertedJobName)) {
					jobInstance = new JobInstance(redisJobInstance.getJobInstanceId(), redisJobInstance.getJobName());
					result.add(jobInstance);
				}
			}
		}

		result = sortDescending(result);

		return subset(result, start, count);
	}

	@Override
	public int getJobInstanceCount(String jobName) throws NoSuchJobException {
		
		List<JobInstance> result = new ArrayList<>();
		JobInstance jobInstance = null;
		Set<RedisJobInstance> redisJobInstances = opsJobInstanceSortedSet
				.range(zipToDestBatchUtil.getRedisKey(getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0, -1);
		if (!redisJobInstances.isEmpty()) {
			for (RedisJobInstance redisJobInstance : redisJobInstances) {
				if (redisJobInstance.getJobName().equals(jobName)) {
					jobInstance = new JobInstance(redisJobInstance.getJobInstanceId(), redisJobInstance.getJobName());
					result.add(jobInstance);
				}
			}
		}
		return result.size();
	}

	public String getKeySpace() {
		return this.keyspace;
	}

	private List<JobInstance> mapToJobInstances(String jobName, String jobKey,
			Set<RedisJobInstance> redisJobInstances) {
		List<JobInstance> result = new ArrayList<>();

		if (StringUtils.hasLength(jobKey)) {
			for (RedisJobInstance redisJobInstance : redisJobInstances) {
				if (redisJobInstance.getJobName().equals(jobName) && redisJobInstance.getJobKey().equals(jobKey)) {
					result.add(new JobInstance(redisJobInstance.getJobInstanceId(), redisJobInstance.getJobName()));
				}
			}
		} else {
			
			for (RedisJobInstance redisJobInstance : redisJobInstances) {
				if ((redisJobInstance.getJobName().equals(jobName))
						&& (redisJobInstance.getJobKey() == null || redisJobInstance.getJobKey().equals(jobKey))) {

					result.add(new JobInstance(redisJobInstance.getJobInstanceId(), redisJobInstance.getJobName()));

				}
			}
		}
		return result;
	}

	private List<JobInstance> sortDescending(List<JobInstance> result) {
		return (result.stream().sorted((ji1, ji2) -> Long.signum(ji2.getId() - ji1.getId()))
				.collect(Collectors.toList()));
	}

	private List<JobInstance> subset(List<JobInstance> jobInstances, int start, int count) {
		int startIndex = Math.min(start, jobInstances.size());
		int endIndex = Math.min(start + count, jobInstances.size());

		return jobInstances.subList(startIndex, endIndex);
	}

}
