package com.fedex.ziptodest.batch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.batch.service.IseriesDataService;

@RestController
@RequestMapping("/iseries")
public class IseriesDataController {
	
	@Autowired
	IseriesDataService iseriesDataService; 
	
	@GetMapping("/networks")
	public List<String> selectAllNetWork(){
		return iseriesDataService.selectAllNetworks();
	}
	
	@GetMapping("/destinations")
	public List<String> selectAllDestination(){
		return iseriesDataService.selectAllDestination();
	}
	
	@GetMapping("/countryCodes")
	public List<String> selectAllCountryCode(){
		return iseriesDataService.selectAllCountryCode();
	}
	
	@GetMapping("/stateProvinces")
	public List<String> selectAllStateProvince(){
		return iseriesDataService.selectAllStateProvince();
	}

}
