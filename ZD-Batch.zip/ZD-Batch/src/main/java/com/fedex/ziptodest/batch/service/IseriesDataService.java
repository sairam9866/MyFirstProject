package com.fedex.ziptodest.batch.service;

import java.util.List;

public interface IseriesDataService {

	public List<String> selectAllCountryCode();
	
	public List<String> selectAllDestination();
	
	public List<String> selectAllNetworks();
	
	public List<String> selectAllStateProvince();
	
}
