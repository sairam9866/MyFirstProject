package com.fedex.ziptodest.batch.service.impl;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.batch.dao.ZipToDestHasDeltaDao;
import com.fedex.ziptodest.batch.service.ZipToDestHasDeltaService;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

/**
 * 
 * @author 3818669
 *
 */
@Service
public class ZipToDestHasDeltaServiceImpl implements ZipToDestHasDeltaService {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestHasDeltaServiceImpl.class);
	
	@Autowired
	private ZipToDestHasDeltaDao zipToDestHasDeltaDao;
	
	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	@Override
	public int insertOrUpdateZipToDestHasDelta(Set<String> networks, Long effectiveDate) {
		int insertCount = 0;
		LOGGER.info("Processed Time : {}",effectiveDate);
		for(String network : networks){
			LOGGER.info("Has Delta : {}",network);			
			zipToDestHasDeltaDao.save(zipToDestBatchUtil.instanceOfZipToDestHasDelta(network, effectiveDate));
			insertCount++;
		}		
		return insertCount;
	}

}
