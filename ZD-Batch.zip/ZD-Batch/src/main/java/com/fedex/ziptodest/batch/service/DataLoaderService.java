package com.fedex.ziptodest.batch.service;

import java.util.List;

import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

public interface DataLoaderService {

	public List<ZipToDest> findAllCurrentTransaction();
	
	public List<ZipToDest> findAllFutureTransaction();
	
	public List<ZipToDestHasDelta> findAllFacilityHasDelta();

	public List<ZipToDest> findAllHistoryTransaction();
	
}
