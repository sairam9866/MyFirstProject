package com.fedex.ziptodest.batch.util;

import java.time.format.DateTimeFormatter;

public class AppConstants {
	
	private AppConstants(){		
	}
	
	public static final String TRANSACTION_TYPE_ADD = "A";
	public static final String TRANSACTION_TYPE_MODIFY = "M";
	public static final String TRANSACTION_TYPE_DELETE = "D";
	
	public static final String SEPARATOR_COLON = ":";
	public static final String ISERIES = "ISERIES";
	public static final String STATEPROVINCE = "STATEPROVINCE";
	public static final String STATEPROVINCE_COUNTRY = "STATEPROVINCE:COUNTRY";
	public static final String NETWORK = "NETWORK";
	public static final String DESTINATION = "DESTINATION";
	public static final String COUNTRY_CODE = "COUNTRY_CODE";
	public static final String PROCESSED_RECORDS = "PROCESSED_RECORDS";
	public static final String FUTURE_RECORDS = "FUTURE_RECORDS";
	public static final String HISTORICAL_RECORDS = "HISTORICAL_RECORDS";
	public static final String CURRENT_RECORDS = "CURRENT_RECORDS";
	public static final String FACILITYHASDELTA = "FACILITYHASDELTA";
	
	public static final String CURRENT_RECORDS_JSON = "CURRENT_RECORDS_JSON";
	
	public static final String FLAG_YES = "Y";
	public static final String FLAG_NO = "N";
	
	public static final String KEY_UNPROCESSED_ADDED = "unProcessedAddedTxn";
	public static final String KEY_UNPROCESSED_MODIFIED = "unProcessedModifiedTxn";
	public static final String KEY_UNPROCESSED_DELETED = "unProcessedDeletedTxn";
	
	public static final String KEY_JOB_START_TIME = "jobDateTime";
	public static final String KEY_EXECUTION_COUNT = "executionCount";
	
	public static final String ZD_DISTRIBUTION_CACHE_KEY = "zd.distribution.cache.key";
	public static final String ZD_DISTRIBUTION_CACHE_URL = "zd.distribution.cache.url";
	
	public static final String KEY_REFRESH = "app.refresh";
	public static final String STATUS_CODE_UNAUTHORIZED = "Unauthorized";
	public static final String STATUS_CODE_INVALID = "Invalid Resource";	
	
	public static final String EFFECTIVE_DATE_FORMAT = "yyyy-MM-dd.HH:mm:ss";
	public static final String ISEREIS_DATE_FORMAT = "yyyy-MM-dd";
	public static final String STAR_WILDCARD = "\\*";
	public static final String STAR_WILDCARD_PATTERN = ".*";
	
	public static final String SQL_ALL_COUNTRY_CODE = "select CYCODE,CYCLCU from ITLPF001";
	public static final String SQL_ALL_NETWORKS = "select ROW_ID,TERM_NUM,NETWORK_ID,CREATED_BY,CREATED_DT,UPDATED_BY,UPDATED_DT,MODEL_TYPE,COLOC_NUM from SRT509F";
	public static final String SQL_ALL_DESTINATIONS = "select TRMABR,TRMNUM,TRMSTS from SRTPF508";
	public static final String SQL_ALL_STATE_PROVINCES = "select STAPRO,SPNAME,CNTRYC from CANPF010";
	
	public static final String ISERIES_COUNTRY_CODE_SET_KEY = "COUNTRY_CODES";
	public static final String ISERIES_NETWORK_SET_KEY = "NETWORK";
	public static final String ISERIES_DESTINATION_SET_KEY = "DESTINATIONS";
	public static final String ISERIES_STATE_PROVINCE_SET_KEY = "STATE_PROVINCES";
	
	public static final String HASH_KEY_NETWORK = "NETWORK_IDS";
	public static final String ZIP_TO_DEST_HAS_DELTA_HASH_KEY = "MASTERZIPTODESTHASDELTA";
	
	public static final String APP_PROFILE_LOCAL = "local";	
	
	public static final String APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY = "SAVE_PROCESS_TMSTMP";	
	public static final String APP_TRANSACTION_SAVE_CREATION_TMSTAMP_KEY = "SAVE_CREATION_TMSTMP";
	
	public static final String APP_ZIPTODEST_NETWORK_KEY = "NETWORK";
	
	public static final String JOB_EXECUTION_CONTEXT = "JOB_EXECUTION_CONTEXT";
	public static final String STEP_EXECUTION_CONTEXT = "STEP_EXECUTION_CONTEXT";
	
	public static final String JOB_EXECUTION_SET_KEY = "JOB_EXECUTION_SET_KEY";
	public static final String JOB_EXECUTION_PARAMS_SET_KEY = "JOB_EXECUTION_PARAMS_SET_KEY";
	public static final String JOB_INSTANCE_SET_KEY = "JOB_INSTANCE_SET_KEY";		
	public static final String JOB_INSTANCE_STRING_KEY = "JOB_NAME_KEY";
	public static final String STEP_EXECUTION_SET_KEY = "STEP_EXECUTION_SET_KEY";
	
	public static final int DEFAULT_MAX_VARCHAR_LENGTH = 2500;
	
	public static final String EMPTY = "";	
	
	public static final String PROCESSED_DT = "processedAt";
	
	public static final DateTimeFormatter ZIP_TO_DEST_DATE_TIME_FORMATTER = DateTimeFormatter
			.ofPattern(AppConstants.EFFECTIVE_DATE_FORMAT);	
	
	public static DateTimeFormatter appDateTimeFormatter(){
		return ZIP_TO_DEST_DATE_TIME_FORMATTER;
	}
}
