package com.fedex.ziptodest.batch.model.mappers;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.Fields;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.Network;

@Component
public class NetworkMapper {

	public static final Logger LOGGER = LoggerFactory.getLogger(NetworkMapper.class);

	private final DateTimeFormatter ZIP_TO_DEST_DATE_TIME_FORMATTER = DateTimeFormatter
			.ofPattern(AppConstants.ISEREIS_DATE_FORMAT);

	@Autowired
	ZipToDestBatchUtil zipToDestBatchUtil;

	public Network toNetwork(Map<String, String> map) {
		Network network = new Network();
		network.setCreatedBy(map.get(Fields.CREATED_BY));
		network.setUpdatedBy(map.get(Fields.UPDATED_BY));
		network.setModelType(map.get(Fields.MODEL_TYPE));
		network.setNetworkId(map.get(Fields.NETWORK_ID));

		network.setCreatedDate(StringUtils.isBlank(map.get(Fields.CREATED_DATE)) ? null
				: LocalDate.parse(map.get(Fields.CREATED_DATE), ZIP_TO_DEST_DATE_TIME_FORMATTER));

		network.setRowId(StringUtils.isBlank(map.get(Fields.ROW_ID)) ? null : Integer.parseInt(map.get(Fields.ROW_ID)));

		network.setTermNum(
				StringUtils.isBlank(map.get(Fields.TERM_NUM)) ? null : Long.parseLong(map.get(Fields.TERM_NUM)));

		network.setUpdateDate(StringUtils.isBlank(map.get(Fields.UPDATED_DATE)) ? null
				: LocalDate.parse(map.get(Fields.UPDATED_DATE), ZIP_TO_DEST_DATE_TIME_FORMATTER));

		network.setColocNum(
				StringUtils.isBlank(map.get(Fields.COLOC_NUM)) ? null : Integer.parseInt(map.get(Fields.COLOC_NUM)));

		return network;
	}

	/**
	 * 
	 * @param map
	 * @return
	 */
	public String toJson(Map<String, String> map) {
		JsonBuilderFactory jsonBuilderFactory = Json.createBuilderFactory(null);
		JsonObject jsonObject = jsonBuilderFactory.createObjectBuilder()
				.add(Fields.NETWORK_ID, map.get(Fields.NETWORK_ID)).add(Fields.MODEL_TYPE, map.get(Fields.MODEL_TYPE))
				.add(Fields.COLOC_NUM, map.get(Fields.COLOC_NUM)).add(Fields.ROW_ID, map.get(Fields.ROW_ID))
				.add(Fields.TERM_NUM, map.get(Fields.TERM_NUM)).add(Fields.CREATED_BY, map.get(Fields.CREATED_BY))
				.add(Fields.CREATED_DATE, map.get(Fields.CREATED_DATE))
				.add(Fields.UPDATED_BY, map.get(Fields.UPDATED_BY))
				.add(Fields.UPDATED_DATE, map.get(Fields.UPDATED_DATE)).build();
		return jsonObject.toString();
	}

	public Map<String, String> toMap(Network network) {
		Map<String, String> map = new HashMap<>();
		map.put(Fields.CREATED_BY, zipToDestBatchUtil.stringValueOf(network.getCreatedBy()));
		map.put(Fields.MODEL_TYPE, zipToDestBatchUtil.stringValueOf(network.getModelType()));
		map.put(Fields.NETWORK_ID, zipToDestBatchUtil.stringValueOf(network.getNetworkId()));
		map.put(Fields.UPDATED_BY, zipToDestBatchUtil.stringValueOf(network.getUpdatedBy()));
		map.put(Fields.COLOC_NUM, zipToDestBatchUtil.stringValueOf(network.getColocNum()));
		map.put(Fields.ROW_ID, zipToDestBatchUtil.stringValueOf(network.getRowId()));
		map.put(Fields.TERM_NUM, zipToDestBatchUtil.stringValueOf(network.getTermNum()));
		map.put(Fields.UPDATED_DATE, zipToDestBatchUtil.stringValueOf(network.getUpdateDate()));
		map.put(Fields.CREATED_DATE, zipToDestBatchUtil.stringValueOf(network.getCreatedDate()));
		return map;
	}
}
