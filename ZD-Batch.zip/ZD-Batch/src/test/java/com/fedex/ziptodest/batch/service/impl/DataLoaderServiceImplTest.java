/*package com.fedex.ziptodest.batch.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.repository.FacilityDeltaRepository;
import com.fedex.ziptodest.batch.repository.ZipToDestHasDeltaRepository;
import com.fedex.ziptodest.batch.repository.ZipToDestTransactionRepository;
import com.fedex.ziptodest.batch.repository.ZipToDestinationRepository;
import com.fedex.ziptodest.batch.temp.service.impl.DataLoaderServiceImpl;
import com.fedex.ziptodest.model.FacilityDelta;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;
import com.fedex.ziptodest.model.ZipToDestination;

@RunWith(SpringRunner.class)
public class DataLoaderServiceImplTest {

	@InjectMocks
	private DataLoaderServiceImpl dataLoaderServiceImpl;

	@Mock
	ZipToDestTransactionRepository zipToDestRepository;

	@Mock
	ZipToDestinationRepository zipToDestinationRepository;

	@Mock
	ZipToDestHasDeltaRepository zipToDestHasDeltaRepository;

	@Mock
	FacilityDeltaRepository facilityIdRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFindAllTransaction() {
		List<ZipToDest> actual = Collections.emptyList();
		when(zipToDestRepository.findAll()).thenReturn(actual);
		List<ZipToDest> output = dataLoaderServiceImpl.findAllTransaction();
		assertNotNull(output);
	}

	@Test
	public void testFindAllFacilityDelta() {
		List<FacilityDelta> actual = Collections.emptyList();
		when(facilityIdRepository.findAll()).thenReturn(actual);
		List<FacilityDelta> output = dataLoaderServiceImpl.findAllFacilityDelta();
		assertNotNull(output);
	}

	@Test
	public void testFindAllFacilityHasDelta() {
		List<ZipToDestHasDelta> actual = Collections.emptyList();
		when(zipToDestHasDeltaRepository.findAll()).thenReturn(actual);
		List<ZipToDestHasDelta> output = dataLoaderServiceImpl.findAllFacilityHasDelta();
		assertNotNull(output);
	}

	@Test
	public void testFindAllZipToDestination() {
		List<ZipToDestination> actual = Collections.emptyList();
		when(zipToDestinationRepository.findAll()).thenReturn(actual);
		List<ZipToDestination> output = dataLoaderServiceImpl.findAllZipToDestination();
		assertNotNull(output);
	}
	
	@Test
	public void testFindAllCurrentTransaction(){
		List<ZipToDest> actual = Collections.emptyList();
		when(zipToDestRepository.findByProcessedAndCurrentAndCancelledFlag("Y", "Y", "N")).thenReturn(actual);
		List<ZipToDest> output = dataLoaderServiceImpl.findAllCurrentTransaction();
		assertNotNull(output);
	}
	
	@Test
	public void testFindAllFutureTransaction(){
		List<ZipToDest> actual = Collections.emptyList();
		when(zipToDestRepository.findByProcessedAndCurrentAndCancelledFlag("N", "N", "N")).thenReturn(actual);
		List<ZipToDest> output = dataLoaderServiceImpl.findAllFutureTransaction();
		assertNotNull(output);
	}
}
*/