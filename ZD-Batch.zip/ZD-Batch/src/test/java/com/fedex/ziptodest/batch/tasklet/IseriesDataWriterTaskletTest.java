/*package com.fedex.ziptodest.batch.tasklet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.repository.NetworkRepository;
import com.fedex.ziptodest.batch.repository.redis.CountryCodeRedisRepository;
import com.fedex.ziptodest.batch.repository.redis.DestinationRedisRepository;
import com.fedex.ziptodest.batch.repository.redis.StateProvinceRedisRepository;
import com.fedex.ziptodest.batch.tasklet.IseriesDataWriterTasklet;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.model.CountryCode;
import com.fedex.ziptodest.model.Destination;
import com.fedex.ziptodest.model.Network;
import com.fedex.ziptodest.model.StateProvince;

@RunWith(SpringRunner.class)
public class IseriesDataWriterTaskletTest {

	@InjectMocks
	IseriesDataWriterTasklet iseriesDataWriterTasklet;
	
	@Mock
	CountryCodeRedisRepository countryCodeRedisRepository;
	
	@Mock
	NetworkRepository networkRepository;
	
	@Mock
	DestinationRedisRepository destinationRedisRepository;
	
	@Mock
	StateProvinceRedisRepository stateProvinceRedisRepository;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testIseriesDataWriterTasklet() throws Exception{
		List<CountryCode> countryCodes = new ArrayList<>();		
		List<Network> networks = new ArrayList<>();		
		List<Destination> destinations = new ArrayList<>();		
		List<StateProvince> stateProvinces = new ArrayList<>();
		
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		jobExecution.getExecutionContext().put(AppConstants.KEY_COUNTRY_CODE, countryCodes);
		jobExecution.getExecutionContext().put(AppConstants.KEY_NETWORKS, networks);
		jobExecution.getExecutionContext().put(AppConstants.KEY_DESTINATIONS, destinations);
		jobExecution.getExecutionContext().put(AppConstants.KEY_STATE_PROVINCES, stateProvinces);
		

		StepExecution execution = new StepExecution("iseriesDataWriterTasklet", jobExecution);
		StepContribution contribution = new StepContribution(execution);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);	
		
		RepeatStatus status1 = iseriesDataWriterTasklet.execute(contribution, chunkContext);
		
		CountryCode countryCode = new CountryCode();
		countryCode.setCyclcu(840);
		countryCode.setCycode("CA");
		countryCodes.add(countryCode);
		
		Network network = new Network();
		network.setNetworkId("FXG");
		network.setTermNum(1234L);
		networks.add(network);
		
		Destination destination = new Destination();
		destination.setTerminalAbbreviation("ABCD");
		destination.setTerminalNumber(11);
		destination.setTerminalStatus("A");
		destinations.add(destination);
		
		StateProvince stateProvince = new StateProvince();
		stateProvince.setCntryc("CA");
		stateProvince.setSpName("Ontario");
		stateProvince.setStaPro("ON");
		stateProvinces.add(stateProvince);
		jobExecution.setStatus(BatchStatus.COMPLETED);
		
		jobExecution.getExecutionContext().put(AppConstants.KEY_COUNTRY_CODE, countryCodes);
		jobExecution.getExecutionContext().put(AppConstants.KEY_NETWORKS, networks);
		jobExecution.getExecutionContext().put(AppConstants.KEY_DESTINATIONS, destinations);
		jobExecution.getExecutionContext().put(AppConstants.KEY_STATE_PROVINCES, stateProvinces);
		
		when(countryCodeRedisRepository.saveAll(countryCodes)).thenReturn(countryCodes);
		when(networkRepository.saveAll(networks)).thenReturn(networks);
		when(destinationRedisRepository.saveAll(destinations)).thenReturn(destinations);
		when(stateProvinceRedisRepository.saveAll(stateProvinces)).thenReturn(stateProvinces);
		
		RepeatStatus status2 = iseriesDataWriterTasklet.execute(contribution, chunkContext);
		assertEquals(RepeatStatus.FINISHED, status1);
		assertEquals(RepeatStatus.FINISHED, status2);
	}
}
*/