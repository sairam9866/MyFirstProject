/*package com.fedex.ziptodest.batch.redis.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.repository.dao.NoSuchObjectException;
import org.springframework.core.env.Environment;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.redis.dao.RedisJobExecutionDao;
import com.fedex.ziptodest.batch.redis.dao.model.JobExecutionParams;
import com.fedex.ziptodest.batch.redis.dao.model.RedisJobExecution;
import com.fedex.ziptodest.batch.redis.dao.model.RedisJobInstance;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

@RunWith(SpringRunner.class)
public class RedisJobExecutionDaoTest {

	@InjectMocks
	RedisJobExecutionDao redisJobExecutionDao;

	@Mock
	ZSetOperations<String, RedisJobExecution> opsJobExecutionSortedSet;

	@Mock
	ZSetOperations<String, JobExecutionParams> opsJobExecutionParamsSortedSet;

	@Mock
	ZSetOperations<String, RedisJobInstance> opsJobInstanceSortedSet;

	@Mock
	Environment evironment;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSaveJobExecution() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);

		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(false);
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(0L);
		when(evironment.getProperty("redis.keys.expire.hours", Long.class, 0L)).thenReturn(0L);
		
		redisJobExecutionDao.saveJobExecution(jobExecution);
	}

	@Test
	public void testUpdateJobExecution() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		RedisJobExecution rje = new RedisJobExecution(jobExecution);

		Set<RedisJobExecution> jeSet = new HashSet<>();
		jeSet.add(rje);

		when(opsJobExecutionSortedSet.add(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				rje, rje.getJobExecutionId())).thenReturn(true);

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				1L, 1L)).thenReturn(jeSet);

		redisJobExecutionDao.updateJobExecution(jobExecution);
	}

	@Test
	public void testUpdateJobExecutionException1() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		RedisJobExecution rje = new RedisJobExecution(jobExecution);

		Set<RedisJobExecution> jeSet = new HashSet<>();
		jeSet.add(rje);

		when(opsJobExecutionSortedSet.add(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				rje, rje.getJobExecutionId())).thenReturn(false);

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				1L, 1L)).thenReturn(jeSet);

		Throwable throwable = catchThrowable(() -> redisJobExecutionDao.updateJobExecution(jobExecution));

		assertThat(throwable).isInstanceOf(OptimisticLockingFailureException.class);
	}

	@Test
	public void testUpdateJobExecutionException2() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		JobInstance jobInstance1 = new JobInstance(1213L, "JobName");
		JobExecution jobExecution1 = new JobExecution(11L);
		jobExecution1.setStatus(BatchStatus.STARTED);
		jobExecution1.setCreateTime(new Date());
		jobExecution1.setExitStatus(ExitStatus.EXECUTING);
		jobExecution1.setJobInstance(jobInstance1);
		jobExecution1.incrementVersion();

		RedisJobExecution rje1 = new RedisJobExecution(jobExecution);
		RedisJobExecution rje2 = new RedisJobExecution(jobExecution1);

		Set<RedisJobExecution> jeSet = new HashSet<>();
		jeSet.add(rje1);
		jeSet.add(rje2);

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				1L, 1L)).thenReturn(jeSet);

		assertThatExceptionOfType(NoSuchObjectException.class)
				.isThrownBy(() -> redisJobExecutionDao.updateJobExecution(jobExecution));
	}

	@Test
	public void testFindJobExecutions() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobInstance jobInstance2 = new JobInstance(124L, "JobName");

		Set<RedisJobExecution> jeSet = new HashSet<>();

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(jeSet);

		List<JobExecution> result = redisJobExecutionDao.findJobExecutions(jobInstance);

		assertTrue(result.isEmpty());

		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		JobExecution jobExecution2 = new JobExecution(2L);
		jobExecution2.setStatus(BatchStatus.STARTED);
		jobExecution2.setCreateTime(new Date());
		jobExecution2.setExitStatus(ExitStatus.EXECUTING);
		jobExecution2.setJobInstance(jobInstance2);
		jobExecution2.incrementVersion();

		RedisJobExecution redisJobExecution = new RedisJobExecution(jobExecution);
		RedisJobExecution redisJobExecution2 = new RedisJobExecution(jobExecution2);
		jeSet.add(redisJobExecution);
		jeSet.add(redisJobExecution2);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(jeSet);

		result = redisJobExecutionDao.findJobExecutions(jobInstance);

		assertFalse(result.isEmpty());
	}

	@Test
	public void testGetLastJobExecution() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobInstance jobInstance2 = new JobInstance(124L, "JobName");

		Set<RedisJobExecution> jeSet = new HashSet<>();

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(jeSet);

		JobExecution result = redisJobExecutionDao.getLastJobExecution(jobInstance);

		assertNull(result);

		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		JobExecution jobExecution2 = new JobExecution(2L);
		jobExecution2.setStatus(BatchStatus.STARTED);
		jobExecution2.setCreateTime(new Date());
		jobExecution2.setExitStatus(ExitStatus.EXECUTING);
		jobExecution2.setJobInstance(jobInstance);
		jobExecution2.incrementVersion();

		JobExecution jobExecution3 = new JobExecution(3L);
		jobExecution3.setStatus(BatchStatus.STARTED);
		jobExecution3.setCreateTime(new Date());
		jobExecution3.setExitStatus(ExitStatus.EXECUTING);
		jobExecution3.setJobInstance(jobInstance2);
		jobExecution3.incrementVersion();

		RedisJobExecution redisJobExecution = new RedisJobExecution(jobExecution);
		RedisJobExecution redisJobExecution2 = new RedisJobExecution(jobExecution2);
		RedisJobExecution redisJobExecution3 = new RedisJobExecution(jobExecution3);
		jeSet.add(redisJobExecution);
		jeSet.add(redisJobExecution2);
		jeSet.add(redisJobExecution3);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(jeSet);

		result = redisJobExecutionDao.getLastJobExecution(jobInstance);

		assertNotNull(result);
	}

	@Test
	public void testFindRunningJobExecutions() {
		Set<RedisJobInstance> rjiSet = new HashSet<>();
		Set<RedisJobExecution> rjeSet = new HashSet<>();

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY),
				0, -1)).thenReturn(rjiSet);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(rjeSet);
		Set<JobExecution> result = redisJobExecutionDao.findRunningJobExecutions("JobName");

		assertTrue(result.isEmpty());

		RedisJobInstance redisJobInstance = new RedisJobInstance(123L, "JobName");
		RedisJobInstance redisJobInstance2 = new RedisJobInstance(124L, "JobName2");

		rjiSet.add(redisJobInstance);
		rjiSet.add(redisJobInstance2);

		JobInstance jobInstance = new JobInstance(redisJobInstance.getJobInstanceId(), redisJobInstance.getJobName());
		JobInstance jobInstance2 = new JobInstance(redisJobInstance2.getJobInstanceId(),
				redisJobInstance2.getJobName());

		JobExecution jobExecution = new JobExecution(2L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();
		RedisJobExecution redisJobExecution = new RedisJobExecution(jobExecution);
		redisJobExecution.setStartTime(new Date());
		redisJobExecution.setEndTime(null);

		JobExecution jobExecution2 = new JobExecution(1L);
		jobExecution2.setStatus(BatchStatus.STARTED);
		jobExecution2.setCreateTime(new Date());
		jobExecution2.setExitStatus(ExitStatus.EXECUTING);
		jobExecution2.setJobInstance(jobInstance2);
		jobExecution2.incrementVersion();
		RedisJobExecution redisJobExecution2 = new RedisJobExecution(jobExecution2);
		redisJobExecution2.setStartTime(null);
		redisJobExecution2.setEndTime(new Date());

		rjeSet.add(redisJobExecution);
		rjeSet.add(redisJobExecution2);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY),
				0, -1)).thenReturn(rjiSet);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(rjeSet);

		result = redisJobExecutionDao.findRunningJobExecutions("JobName");

	}

	@Test
	public void testGetJobExecution() {
		Long executionId = 101L;
		Set<RedisJobExecution> redisJobExecutions = new HashSet<>();

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				executionId, executionId)).thenReturn(redisJobExecutions);

		JobExecution result = redisJobExecutionDao.getJobExecution(executionId);

		assertNull(result);

		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(2L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();
		RedisJobExecution redisJobExecution = new RedisJobExecution(jobExecution);
		redisJobExecutions.add(redisJobExecution);

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				executionId, executionId)).thenReturn(redisJobExecutions);

		result = redisJobExecutionDao.getJobExecution(executionId);

		assertNotNull(result);

	}

	@Test
	public void testSynchronizeStatus() {

		Set<RedisJobExecution> redisJobExecutions = new HashSet<>();

		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(2L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				jobExecution.getId(), jobExecution.getId())).thenReturn(redisJobExecutions);

		redisJobExecutionDao.synchronizeStatus(jobExecution);

		RedisJobExecution redisJobExecution = new RedisJobExecution(jobExecution);
		redisJobExecutions.add(redisJobExecution);

		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				jobExecution.getId(), jobExecution.getId())).thenReturn(redisJobExecutions);
		
		redisJobExecutionDao.synchronizeStatus(jobExecution);
		
		when(opsJobExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				jobExecution.getId(), jobExecution.getId())).thenReturn(redisJobExecutions);

		jobExecution.incrementVersion();
		redisJobExecutionDao.synchronizeStatus(jobExecution);

		assertNotNull(jobExecution);

	}
}
*/