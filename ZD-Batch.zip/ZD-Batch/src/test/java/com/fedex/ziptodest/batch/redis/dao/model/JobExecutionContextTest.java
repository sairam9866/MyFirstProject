package com.fedex.ziptodest.batch.redis.dao.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.batch.redis.dao.model.JobExecutionContext;

public class JobExecutionContextTest {

	JobExecutionContext obj;
	
	@Before
	public void init() {
		obj = new JobExecutionContext();
		obj.setJobExecutionId(123L);
		obj.setSerializedContext("one");
		obj.setShortContext("two");
	}
	
	@Test
	public void testJobExecutionContext() {
		assertNotNull(obj);
		assertNotNull(obj.getJobExecutionId());
		assertNotNull(obj.getSerializedContext());
		assertNotNull(obj.getShortContext());
		assertNotNull(obj.toString());
	}
	
	@Test
	public void testHashCode(){
		JobExecutionContext execution1 = new JobExecutionContext();
		JobExecutionContext execution2 = new JobExecutionContext();
		assertEquals(execution1.hashCode(), execution2.hashCode());		
		execution1.setJobExecutionId(123L);
		execution2.setJobExecutionId(123L);
		assertEquals(execution1.hashCode(), execution2.hashCode());
	}
	
	@Test
	public void testEquals(){
		JobExecutionContext execution = new JobExecutionContext();
		execution.setJobExecutionId(123L);		
		
		assertTrue(execution.equals(execution));
		JobExecutionContext execution2 = null;
		assertFalse(execution.equals(execution2));
		assertFalse(execution.equals(new Object()));
		execution2 = new JobExecutionContext();
		execution.setJobExecutionId(null);
		execution2.setJobExecutionId(null);
		assertTrue(execution.equals(execution2));
		execution2.setJobExecutionId(124L);
		assertFalse(execution.equals(execution2));
		execution.setJobExecutionId(123L);
		assertFalse(execution.equals(execution2));
		execution2.setJobExecutionId(execution.getJobExecutionId());
		assertTrue(execution.equals(execution2));		
	}
}
