/*package com.fedex.ziptodest.batch.redis.dao;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.repository.ExecutionContextSerializer;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.redis.dao.model.JobExecutionContext;
import com.fedex.ziptodest.batch.redis.dao.model.StepExecutionContext;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

@RunWith(SpringRunner.class)
public class RedisExecutionContextDaoTest {
	
	@InjectMocks
	RedisExecutionContextDao redisExecutionContextDao;
	
	@Mock
	ZSetOperations<String, JobExecutionContext> opsJobContextSortedSet;

	@Mock
	ZSetOperations<String, StepExecutionContext> opsStepContextSortedSet;
	
	@Mock
	ExecutionContextSerializer serializer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetExecutionContext(){
		Set<JobExecutionContext> executionContext = new HashSet<>();
		
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		
		Long executionId = jobExecution.getId();
		
		when(opsJobContextSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisExecutionContextDao.getKeySpace(), AppConstants.JOB_EXECUTION_CONTEXT),
				executionId, executionId)).thenReturn(executionContext);
		
		ExecutionContext context = redisExecutionContextDao.getExecutionContext(jobExecution);
		
		assertTrue(context.isEmpty());
		
		JobExecutionContext jobExecutionContext = new JobExecutionContext();
		jobExecutionContext.setJobExecutionId(executionId);
		jobExecutionContext.setShortContext("TST");
		
		executionContext.add(jobExecutionContext);
		
		
		when(opsJobContextSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisExecutionContextDao.getKeySpace(), AppConstants.JOB_EXECUTION_CONTEXT),
				executionId, executionId)).thenReturn(executionContext);
		
		//context = redisExecutionContextDao.getExecutionContext(jobExecution);
		
		//assertFalse(context.isEmpty());
		
	}
}
*/