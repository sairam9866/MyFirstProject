package com.fedex.ziptodest.batch.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fedex.ziptodest.batch.service.IseriesDataService;

public class IseriesDataControllerTest {

	@InjectMocks
	IseriesDataController iseriesDataController;

	@Mock
	IseriesDataService iseriesDataService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSelectAllNetWork() {
		List<String> actual = Collections.emptyList();
		when(iseriesDataService.selectAllNetworks()).thenReturn(actual);
		List<String> output = iseriesDataController.selectAllNetWork();
		assertNotNull(output);
	}

	@Test
	public void testSelectAllDestination() {
		List<String> actual = Collections.emptyList();
		when(iseriesDataService.selectAllDestination()).thenReturn(actual);
		List<String> output = iseriesDataController.selectAllDestination();
		assertNotNull(output);
	}

	@Test
	public void testSelectAllCountryCode() {
		List<String> actual = Collections.emptyList();
		when(iseriesDataService.selectAllCountryCode()).thenReturn(actual);
		List<String> output = iseriesDataController.selectAllCountryCode();
		assertNotNull(output);
	}
	
	@Test
	public void testSelectAllStateProvince() {
		List<String> actual = Collections.emptyList();
		when(iseriesDataService.selectAllStateProvince()).thenReturn(actual);
		List<String> output = iseriesDataController.selectAllStateProvince();
		assertNotNull(output);
	}
}
