package com.fedex.ziptodest.batch.model.mappers;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.model.mappers.NetworkRowMapper;
import com.fedex.ziptodest.model.Network;

@RunWith(SpringRunner.class)
public class NetworkRowMapperTest {

	NetworkRowMapper networkRowMapper = null;
	
	@Mock
	ResultSet resultSet;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testNetworkRowMapper() throws SQLException{
		networkRowMapper = new NetworkRowMapper();	
			
		when(resultSet.getDate("CREATED_DT")).thenReturn(null);
		when(resultSet.getDate("UPDATED_DT")).thenReturn(null);
		when(resultSet.getInt("COLOC_NUM")).thenReturn(12);
		when(resultSet.getString("CREATED_BY")).thenReturn("TEST");
		when(resultSet.getString("MODEL_TYPE")).thenReturn("A");
		when(resultSet.getString("NETWORK_ID")).thenReturn("FXG");
		when(resultSet.getInt("ROW_ID")).thenReturn(1);
		when(resultSet.getLong("TERM_NUM")).thenReturn(1234L);
		when(resultSet.getString("UPDATED_BY")).thenReturn("TEST");	
		
		Network network1 = networkRowMapper.mapRow(resultSet, 1);
		
		when(resultSet.getDate("CREATED_DT")).thenReturn(new Date(System.currentTimeMillis()));
		when(resultSet.getDate("UPDATED_DT")).thenReturn(new Date(System.currentTimeMillis()));
		Network network2 = networkRowMapper.mapRow(resultSet, 1);
		
		assertEquals("FXG", network1.getNetworkId());
		assertEquals("FXG", network2.getNetworkId());
	}
}
