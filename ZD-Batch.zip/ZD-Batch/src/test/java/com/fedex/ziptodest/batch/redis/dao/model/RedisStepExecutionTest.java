package com.fedex.ziptodest.batch.redis.dao.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;

import com.fedex.ziptodest.batch.redis.dao.model.RedisStepExecution;

public class RedisStepExecutionTest {

	RedisStepExecution obj;

	@Before
	public void init() {
		obj = new RedisStepExecution();
		obj.setCommitCount(1);
		obj.setEndTime(new Date());
		obj.setExistMessage("exist message");
		obj.setExitCode("COMPLETED");
		obj.setFilterCount(1);
		obj.setJobExecution(new JobExecution(23L));
		obj.setJobExecutionId(101L);
		obj.setLastUpdated(new Date());
		obj.setProcessSkipCount(0);
		obj.setReadCount(1);
		obj.setReadSkipCount(0);
		obj.setRollbackCount(0);
		obj.setStartTime(new Date());
		obj.setStatus("COMPLETED");
		obj.setStepExecutionId(11L);
		obj.setStepName("TEST");
		obj.setVersion(1);
		obj.setWriteCount(1);
		obj.setWriteSkipCount(0);
	}

	@Test
	public void testRedisStepExecution() {
		assertNotNull(obj);			
		assertNotNull(obj.getCommitCount());
		assertNotNull(obj.getEndTime());
		assertNotNull(obj.getExistMessage());
		assertNotNull(obj.getExitCode());
		assertNotNull(obj.getFilterCount());
		assertNotNull(obj.getJobExecution());
		assertNotNull(obj.getJobExecutionId());
		assertNotNull(obj.getLastUpdated());
		assertNotNull(obj.getProcessSkipCount());
		assertNotNull(obj.getReadCount());
		assertNotNull(obj.getReadSkipCount());
		assertNotNull(obj.getRollbackCount());
		assertNotNull(obj.getStartTime());
		assertNotNull(obj.getStatus());
		assertNotNull(obj.getStepExecutionId());
		assertNotNull(obj.getStepName());
		assertNotNull(obj.getVersion());
		assertNotNull(obj.getWriteCount());
		assertNotNull(obj.getWriteSkipCount());		
	}
	
	@Test
	public void testRedisStepExecutionWithParam() {
		StepExecution sExecution = new StepExecution("Step1", new JobExecution(12L));
		sExecution.setStatus(BatchStatus.COMPLETED);
		sExecution.setExitStatus(ExitStatus.COMPLETED);
		RedisStepExecution execution = new RedisStepExecution(sExecution);				
		assertNotNull(execution.toString());		
	}
	
	@Test
	public void testIncrementVersion(){
		RedisStepExecution execution = new RedisStepExecution();
		execution.incrementVersion();	
		assertEquals(Integer.valueOf(0), execution.getVersion());
		execution.incrementVersion();	
		assertEquals(Integer.valueOf(1), execution.getVersion());
	}
	
	@Test
	public void testHashCode(){
		RedisStepExecution execution1 = new RedisStepExecution();
		RedisStepExecution execution2 = new RedisStepExecution();
		assertEquals(execution1.hashCode(), execution2.hashCode());		
		execution1.setStepExecutionId(123L);
		execution2.setStepExecutionId(123L);
		assertEquals(execution1.hashCode(), execution2.hashCode());
	}
	
	@Test
	public void testEquals(){
		RedisStepExecution execution = new RedisStepExecution();
		execution.setStepExecutionId(123L);		
		
		assertTrue(execution.equals(execution));
		RedisStepExecution execution2 = null;
		assertFalse(execution.equals(execution2));
		assertFalse(execution.equals(new Object()));
		execution2 = new RedisStepExecution();
		execution.setStepExecutionId(null);
		execution2.setStepExecutionId(null);
		assertTrue(execution.equals(execution2));
		execution2.setStepExecutionId(124L);
		assertFalse(execution.equals(execution2));
		execution.setStepExecutionId(123L);
		assertFalse(execution.equals(execution2));
		execution2.setStepExecutionId(execution.getStepExecutionId());
		assertTrue(execution.equals(execution2));		
	}
}
