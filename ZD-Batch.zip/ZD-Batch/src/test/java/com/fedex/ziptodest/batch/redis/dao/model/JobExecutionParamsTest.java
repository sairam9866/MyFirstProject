package com.fedex.ziptodest.batch.redis.dao.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.batch.redis.dao.model.JobExecutionParams;

public class JobExecutionParamsTest {

	JobExecutionParams obj;
	
	@Before
	public void init() {	
		obj = new JobExecutionParams();
		obj.setDateVal(new Date());
		obj.setDoubleVal(1D);
		obj.setIdentifying("Y");
		obj.setJobExecutionId(123L);
		obj.setKeyName("ONE");
		obj.setLongVal(1L);
		obj.setStringVal("str");
		obj.setTypeCd("String");
	}
	
	@Test
	public void testConstructors(){		
		JobExecutionParams obj = new JobExecutionParams(123L, "TEST", "DATE", new Date(), "Y");
		assertNotNull(obj.getDateVal());
		obj = new JobExecutionParams(123L, "TEST", "DOUBLE", 1D, "Y");
		assertNotNull(obj.getDoubleVal());
		obj = new JobExecutionParams(123L, "TEST", "LONG", 1L, "Y");
		assertNotNull(obj.getLongVal());
		obj = new JobExecutionParams(123L, "TEST", "STRING", "STR", "Y");
		assertNotNull(obj.getStringVal());
	}
	
	@Test
	public void testJobExecutionParams() {		
		assertNotNull(obj);
		
		assertNotNull(obj.getDateVal());
		assertNotNull(obj.getDoubleVal());
		assertNotNull(obj.getIdentifying());
		assertNotNull(obj.getJobExecutionId());
		assertNotNull(obj.getKeyName());
		assertNotNull(obj.getLongVal());
		assertNotNull(obj.getStringVal());
		assertNotNull(obj.getTypeCd());
		assertNotNull(obj.toString());
	}
	
	@Test
	public void testHashCode(){
		JobExecutionParams execution1 = new JobExecutionParams();
		JobExecutionParams execution2 = new JobExecutionParams();
		assertEquals(execution1.hashCode(), execution2.hashCode());		
		execution1.setJobExecutionId(123L);
		execution2.setJobExecutionId(123L);
		assertEquals(execution1.hashCode(), execution2.hashCode());
	}
	@Test
	public void testEquals(){
		JobExecutionParams execution = new JobExecutionParams();
		execution.setJobExecutionId(123L);		
		
		assertTrue(execution.equals(execution));
		JobExecutionParams execution2 = null;
		assertFalse(execution.equals(execution2));
		assertFalse(execution.equals(new Object()));
		execution2 = new JobExecutionParams();
		execution.setJobExecutionId(null);
		execution2.setJobExecutionId(null);
		assertTrue(execution.equals(execution2));
		execution2.setJobExecutionId(124L);
		assertFalse(execution.equals(execution2));
		execution.setJobExecutionId(123L);
		assertFalse(execution.equals(execution2));
		execution2.setJobExecutionId(execution.getJobExecutionId());
		assertTrue(execution.equals(execution2));		
	}
}
