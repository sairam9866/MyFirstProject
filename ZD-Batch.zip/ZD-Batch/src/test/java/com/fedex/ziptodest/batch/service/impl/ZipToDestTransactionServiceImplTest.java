/*package com.fedex.ziptodest.batch.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.dao.ZipToDestTransactionDao;
import com.fedex.ziptodest.batch.service.impl.ZipToDestTransactionServiceImpl;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;


@RunWith(SpringRunner.class)
public class ZipToDestTransactionServiceImplTest {

	@InjectMocks
	private ZipToDestTransactionServiceImpl zipToDestTransactionService;	

	@Mock
	ZipToDestTransactionDao zipToDestRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetDestinationCanada() {		
		Long currentTime = ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond();
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(new ZipToDest());
		
		when(zipToDestRepository.findUnProcessedTransactionByType(currentTime, "A")).thenReturn(transactions);
		
		List<ZipToDest>  rvalue = zipToDestTransactionService.findUnProcessedTransactionByType(currentTime, "A");
		
		assertNotNull(rvalue);
	}
	
	@Test
	public void testFindOlderTransactions() {		
		String network = "FXGL";
		String zipCode = "A0A0A0";
		Long currentTime = ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond();
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(new ZipToDest());
		
		when(zipToDestRepository.findOlderTransactions(network, zipCode, currentTime)).thenReturn(transactions);
		
		List<ZipToDest>  rvalue = zipToDestTransactionService.findOlderTransactions(network, zipCode);
		
		assertNotNull(rvalue);
	}
	
	@Test
	public void testUpdateNotProcessedTransactions() {
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);
		
		zipToDestTransactionService.updateNotProcessedTransactions(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), ZipToDestBatchUtil.TRANSACTION_TYPE_ADD);
		zipToDestTransactionService.updateNotProcessedTransactions(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), ZipToDestBatchUtil.TRANSACTION_TYPE_MODIFY);
		zipToDestTransactionService.updateNotProcessedTransactions(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond(), ZipToDestBatchUtil.TRANSACTION_TYPE_DELETE);
		assertNotNull(zipToDest);
	}
	
	@Test
	public void testUpdateOlderTransactions(){
		ZipToDest zipToDest = new ZipToDest();		
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		List<ZipToDest> transactions = new ArrayList<>();
		transactions.add(zipToDest);
		
		zipToDestTransactionService.updateOlderTransactions(transactions, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		assertNotNull(zipToDest);
	}
	
}
*/