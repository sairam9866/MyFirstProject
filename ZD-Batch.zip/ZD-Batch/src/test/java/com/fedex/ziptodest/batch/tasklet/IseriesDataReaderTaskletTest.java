/*package com.fedex.ziptodest.batch.tasklet;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.config.IseriesJdbcTemplate;
import com.fedex.ziptodest.batch.model.mappers.CountryCodeRowMapper;
import com.fedex.ziptodest.batch.model.mappers.DestionationRowMapper;
import com.fedex.ziptodest.batch.model.mappers.NetworkRowMapper;
import com.fedex.ziptodest.batch.model.mappers.StateProvinceRowMapper;
import com.fedex.ziptodest.batch.tasklet.IseriesDataReaderTasklet;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.model.CountryCode;

@RunWith(SpringRunner.class)
public class IseriesDataReaderTaskletTest {
	
	@InjectMocks
	private IseriesDataReaderTasklet iseriesDataReaderTasklet;
	
	@Mock
	IseriesJdbcTemplate iseriesJdbcTemplate;
	
	@Mock
	JdbcTemplate jdbcTemplate;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testIseriesDataReaderTasklet() throws Exception{
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);

		StepExecution execution = new StepExecution("iseriesDataReaderTasklet", jobExecution);
		StepContribution contribution = new StepContribution(execution);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);	
		
		when(iseriesJdbcTemplate.getJdbcTemplate()).thenReturn(jdbcTemplate);
		
		List<CountryCode> countryCodes = new ArrayList<>();
		CountryCode countryCode = new CountryCode();
		countryCode.setCyclcu(840);
		countryCode.setCycode("CA");
		countryCodes.add(countryCode);
		
		when(jdbcTemplate.query(AppConstants.SQL_ALL_COUNTRY_CODE,
				new CountryCodeRowMapper())).thenReturn(Collections.emptyList());
		
		when(jdbcTemplate.query(AppConstants.SQL_ALL_NETWORKS, new NetworkRowMapper())).thenReturn(Collections.emptyList());		
		
		when(jdbcTemplate.query(AppConstants.SQL_ALL_DESTINATIONS,
				new DestionationRowMapper())).thenReturn(Collections.emptyList());
		
		when(jdbcTemplate.query(AppConstants.SQL_ALL_STATE_PROVINCES,
				new StateProvinceRowMapper())).thenReturn(Collections.emptyList());		
		
		RepeatStatus status = iseriesDataReaderTasklet.execute(contribution, chunkContext);
		
		assertEquals(RepeatStatus.FINISHED, status);
		
	}

}
*/