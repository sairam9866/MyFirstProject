/*package com.fedex.ziptodest.batch.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fedex.ziptodest.batch.controller.ZipToDestJobExplorer;
import com.fedex.ziptodest.model.JobAuditResponse;

public class ZipToDestJobExplorerTest {

	@InjectMocks
	ZipToDestJobExplorer zipToDestJobExplorer;

	@Mock
	private JobExplorer jobExplorer;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllJobs() {
		ResponseEntity<List<String>> response = zipToDestJobExplorer.getAllJobNames();
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGetJobExecution() {
		List<JobInstance> jobInstances = new ArrayList<>();

		Mockito.doReturn(jobInstances).when(jobExplorer).findJobInstancesByJobName(Mockito.anyString(),
				Mockito.anyInt(), Mockito.anyInt());
		ResponseEntity<List<JobAuditResponse>> response1 = zipToDestJobExplorer.getJobExecution("import");
		
		assertEquals(HttpStatus.OK, response1.getStatusCode());
		assertNotNull(response1.getBody());
		assertTrue(response1.getBody().isEmpty());

		JobInstance jobInstance = new JobInstance(0l, "import");
		jobInstances.add(jobInstance);

		JobExecution jobExecution = new JobExecution(1l);
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);

		List<JobExecution> jobExecutions = new ArrayList<>();
		jobExecutions.add(jobExecution);

		Mockito.doReturn(jobInstances).when(jobExplorer).findJobInstancesByJobName(Mockito.anyString(),
				Mockito.anyInt(), Mockito.anyInt());

		Mockito.doReturn(jobExecutions).when(jobExplorer).getJobExecutions(jobInstance);

		ResponseEntity<List<JobAuditResponse>> response2 = zipToDestJobExplorer.getJobExecution("import");
		
		assertEquals(HttpStatus.OK, response2.getStatusCode());
		assertNotNull(response2.getBody());
		assertFalse(response2.getBody().isEmpty());

		Mockito.doReturn(jobInstances).when(jobExplorer).findJobInstancesByJobName(Mockito.anyString(),
				Mockito.anyInt(), Mockito.anyInt());

		Mockito.doReturn(getTenJobExecutions()).when(jobExplorer).getJobExecutions(jobInstance);

		ResponseEntity<List<JobAuditResponse>> response3 = zipToDestJobExplorer.getJobExecution("import");
		
		assertEquals(HttpStatus.OK, response3.getStatusCode());
		assertNotNull(response3.getBody());
		assertFalse(response2.getBody().isEmpty());
		assertEquals(10, response3.getBody().size());
	}

	private List<JobExecution> getTenJobExecutions() {
		List<JobExecution> jobExecutions = new ArrayList<>();

		for (int i = 0; i < 10; i++) {
			JobExecution jobExecution = new JobExecution((long) i);
			jobExecution.setCreateTime(new Date());
			jobExecution.setEndTime(new Date());
			jobExecution.setExitStatus(ExitStatus.COMPLETED);
			jobExecution.setLastUpdated(new Date());
			jobExecution.setStartTime(new Date());
			jobExecution.setStatus(BatchStatus.COMPLETED);
			jobExecutions.add(jobExecution);
		}

		return jobExecutions;
	}
}
*/