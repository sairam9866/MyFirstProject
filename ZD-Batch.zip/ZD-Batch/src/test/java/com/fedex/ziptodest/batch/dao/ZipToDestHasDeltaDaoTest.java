package com.fedex.ziptodest.batch.dao;
/*package com.fedex.ziptodest.batch.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.repository.ZipToDestHasDeltaRepository;
import com.fedex.ziptodest.batch.repository.redis.ZipToDestHasDeltaRedisRepository;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

@RunWith(SpringRunner.class)
public class ZipToDestHasDeltaRepositoryTest {

	@InjectMocks
	ZipToDestHasDeltaRepository zipToDestHasDeltaRepository;
	
	@Mock
	ZipToDestHasDeltaRedisRepository zipToDestHasDeltaRedisRepository;
	
	@Mock
	ZSetOperations<String, ZipToDestHasDelta> sortedzipToDestHasDeltaSetOperations;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testCount() {
		when(zipToDestHasDeltaRedisRepository.count()).thenReturn(0L);
		Long count = zipToDestHasDeltaRepository.count();
		assertEquals(Long.valueOf(0L), count);
	}
	
	@Test
	public void testDelete() {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork("FXG");
		zipToDestHasDeltaRepository.delete(zipToDestHasDelta);
		assertEquals("FXG", zipToDestHasDelta.getNetwork());
	}
	
	@Test
	public void testDeleteById() {
		String id = "FXG";
		zipToDestHasDeltaRepository.deleteById(id);
		assertEquals("FXG", id);
	}
	
	@Test
	public void testListDeleteAll() {
		List<ZipToDestHasDelta> entities = Collections.emptyList();
		zipToDestHasDeltaRepository.deleteAll(entities);
		assertTrue(entities.isEmpty());
	}
	
	@Test
	public void testDeleteAll() {
		Boolean isDeleted = true;
		zipToDestHasDeltaRepository.deleteAll();
		assertTrue(isDeleted);
	}
	
	@Test
	public void testExistsById() {
		when(zipToDestHasDeltaRedisRepository.existsById("FXG")).thenReturn(false);
		boolean isExist = zipToDestHasDeltaRepository.existsById("FXG");
		assertFalse(isExist);
	}
	
	@Test
	public void testFindAll() {
		Iterable<ZipToDestHasDelta> zipToDests = Collections.emptyList();
		when(zipToDestHasDeltaRedisRepository.findAll()).thenReturn(zipToDests);
		List<ZipToDestHasDelta> rvalue = (List<ZipToDestHasDelta>) zipToDestHasDeltaRepository.findAll();
		assertTrue(rvalue.isEmpty());
	}
	
	@Test
	public void testFindAllById() {
		List<String> ids = new ArrayList<>();
		ids.add("1234");
		List<ZipToDestHasDelta> zipToDestHasDeltas = new ArrayList<>();
		when(zipToDestHasDeltaRedisRepository.findAllById(ids)).thenReturn(zipToDestHasDeltas);
		List<ZipToDestHasDelta> rValue = (List<ZipToDestHasDelta>) zipToDestHasDeltaRepository.findAllById(ids);
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void testFindById() {
		Optional<ZipToDestHasDelta> zipToDestHasDelta = Optional.empty();
		when(zipToDestHasDeltaRedisRepository.findById("123")).thenReturn(zipToDestHasDelta);
		Optional<ZipToDestHasDelta> rValue = zipToDestHasDeltaRepository.findById("123");
		assertFalse(rValue.isPresent());
	}
	
	@Test
	public void testSaveAll() {
		List<ZipToDestHasDelta> zipToDestHasDeltas = new ArrayList<>();
		when(zipToDestHasDeltaRedisRepository.saveAll(zipToDestHasDeltas)).thenReturn(zipToDestHasDeltas);
		List<ZipToDestHasDelta> rValue = (List<ZipToDestHasDelta>) zipToDestHasDeltaRepository.saveAll(zipToDestHasDeltas);
		assertTrue(rValue.isEmpty());
	}
	
	@Test
	public void testGetKeySpace() {
		String rValue = zipToDestHasDeltaRepository.getKeySpace();
		assertNull(rValue);
	}
	
	@Test
	public void testSave() {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		
		zipToDestHasDelta.setNetwork("FXG");
		zipToDestHasDelta.setLastUpdateTimestamp(System.currentTimeMillis() / 1000);
		
		when(zipToDestHasDeltaRedisRepository.save(zipToDestHasDelta)).thenReturn(zipToDestHasDelta);

		ZipToDestHasDelta output = zipToDestHasDeltaRepository.save(zipToDestHasDelta);
		assertNotNull(output.getNetwork());		
	}
}
*/