package com.fedex.ziptodest.batch.redis.dao.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;

import com.fedex.ziptodest.batch.redis.dao.model.RedisJobExecution;

public class RedisJobExecutionTest {
	RedisJobExecution obj;
	
	@Before
	public void init() {
		obj = new RedisJobExecution();
		obj.setCreateTime(new Date());
		obj.setEndTime(new Date());
		obj.setExitCode("COMPLETED");
		obj.setExitMessage("");
		obj.setJobConfigurationLocation("");
		obj.setJobExecutionId(123L);
		obj.setJobInstanceId(1L);
		obj.setLastUpdated(new Date());
		obj.setStartTime(new Date());
		obj.setStatus("COMPLETED");
		obj.setVersion(0);
	}
	
	@Test
	public void testRedisJobExecution() {
		assertNotNull(obj);
		assertNotNull(obj.getCreateTime());
		assertNotNull(obj.getEndTime());
		assertNotNull(obj.getExitCode());
		assertNotNull(obj.getExitMessage());
		assertNotNull(obj.getJobConfigurationLocation());
		assertNotNull(obj.getJobExecutionId());
		assertNotNull(obj.getJobInstanceId());
		assertNotNull(obj.getLastUpdated());
		assertNotNull(obj.getStartTime());
		assertNotNull(obj.getStatus());
		assertNotNull(obj.getVersion());
		assertNotNull(obj.toString());
	}
	
	@Test
	public void testConstructors(){
		JobExecution je = new JobExecution(12L);
		je.setStatus(BatchStatus.COMPLETED);
		je.setExitStatus(ExitStatus.COMPLETED);
		RedisJobExecution obj = new RedisJobExecution(je);
		assertNotNull(obj.getJobExecutionId());
	}
	
	@Test
	public void testIncrementVersion(){
		RedisJobExecution je = new RedisJobExecution();
		je.incrementVersion();
		assertEquals(Integer.valueOf(0), je.getVersion());
		je.incrementVersion();
		assertEquals(Integer.valueOf(1), je.getVersion());
	}
	
	@Test
	public void testHashCode(){
		RedisJobExecution execution1 = new RedisJobExecution();
		RedisJobExecution execution2 = new RedisJobExecution();
		assertEquals(execution1.hashCode(), execution2.hashCode());		
		execution1.setJobExecutionId(123L);
		execution2.setJobExecutionId(123L);
		assertEquals(execution1.hashCode(), execution2.hashCode());
	}
	
	@Test
	public void testEquals(){
		RedisJobExecution execution = new RedisJobExecution();
		execution.setJobExecutionId(123L);		
		
		assertTrue(execution.equals(execution));
		RedisJobExecution execution2 = null;
		assertFalse(execution.equals(execution2));
		assertFalse(execution.equals(new Object()));
		execution2 = new RedisJobExecution();
		execution.setJobExecutionId(null);
		execution2.setJobExecutionId(null);
		assertTrue(execution.equals(execution2));
		execution2.setJobExecutionId(124L);
		assertFalse(execution.equals(execution2));
		execution.setJobExecutionId(123L);
		assertFalse(execution.equals(execution2));
		execution2.setJobExecutionId(execution.getJobExecutionId());
		assertTrue(execution.equals(execution2));		
	}
}
