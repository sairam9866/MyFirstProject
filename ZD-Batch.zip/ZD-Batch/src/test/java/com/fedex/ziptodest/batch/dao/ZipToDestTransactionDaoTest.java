package com.fedex.ziptodest.batch.dao;
/*package com.fedex.ziptodest.batch.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.repository.redis.ZipToDestRedisRepository;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;

@RunWith(SpringRunner.class)
public class ZipToDestTransactionRepositoryTest {

	@InjectMocks
	ZipToDestTransactionRepository zipToDestTransactionRepository;

	@Mock
	ZipToDestRedisRepository zipToDestRedisRepository;

	@Mock
	private RedisTemplate<String, String> redisStringTemplate;

	@Mock
	private RedisTemplate<String, Long> redisLongTemplate;

	@Mock
	ZSetOperations<String, String> zipSetOperations;

	@Mock
	ZSetOperations<String, Long> zipSetProcessedDateOperations;

	@Mock
	ZSetOperations<String, ZipToDest> zSetOperations;

	@Mock
	ZSetOperations<String, ZipToDest> zSetProcessedOperations;

	@Mock
	ZSetOperations<String, ZipToDest> zSetCreationOperations;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testCount() {
		when(zipToDestRedisRepository.count()).thenReturn(0L);
		Long count = zipToDestTransactionRepository.count();
		assertEquals(Long.valueOf(0L), count);
	}

	@Test
	public void testDelete() {
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setId("1234");
		zipToDestTransactionRepository.delete(zipToDest);
		assertEquals("1234", zipToDest.getId());
	}

	@Test
	public void testDeleteById() {
		String id = "1234";
		zipToDestTransactionRepository.deleteById(id);
		assertEquals("1234", id);
	}

	@Test
	public void testListDeleteAll() {
		List<ZipToDest> entities = new ArrayList<>();
		zipToDestTransactionRepository.deleteAll(entities);
		assertTrue(entities.isEmpty());
	}

	@Test
	public void testDeleteAll() {
		Boolean isDeleted = true;
		zipToDestTransactionRepository.deleteAll();
		assertTrue(isDeleted);
	}

	@Test
	public void testExistsById() {
		when(zipToDestRedisRepository.existsById("123")).thenReturn(false);
		boolean isExist = zipToDestTransactionRepository.existsById("123");
		assertFalse(isExist);
	}

	@Test
	public void testFindAll() {
		Iterable<ZipToDest> zipToDests = new ArrayList<>();
		when(zipToDestRedisRepository.findAll()).thenReturn(zipToDests);
		List<ZipToDest> rvalue = (List<ZipToDest>) zipToDestTransactionRepository.findAll();
		assertTrue(rvalue.isEmpty());
	}

	@Test
	public void testFindAllById() {
		List<String> ids = new ArrayList<>();
		ids.add("1234");
		List<ZipToDest> zipToDests = new ArrayList<>();
		when(zipToDestRedisRepository.findAllById(ids)).thenReturn(zipToDests);
		List<ZipToDest> rValue = (List<ZipToDest>) zipToDestTransactionRepository.findAllById(ids);
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void testFindById() {
		Optional<ZipToDest> zipToDest = Optional.empty();
		when(zipToDestRedisRepository.findById("123")).thenReturn(zipToDest);
		Optional<ZipToDest> rValue = zipToDestTransactionRepository.findById("123");
		assertFalse(rValue.isPresent());
	}

	@Test
	public void testSaveAll() {
		List<ZipToDest> zipToDests = new ArrayList<>();
		when(zipToDestRedisRepository.saveAll(zipToDests)).thenReturn(zipToDests);
		List<ZipToDest> rValue = (List<ZipToDest>) zipToDestTransactionRepository.saveAll(zipToDests);
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void testFindByNetworkAndZipCodeAndProcessed() {
		List<ZipToDest> result = new ArrayList<>();
		when(zipToDestRedisRepository.findByNetworkAndZipCodeAndProcessed("FXG", "12345000000", "Y"))
				.thenReturn(result);
		List<ZipToDest> rValue = zipToDestTransactionRepository.findByNetworkAndZipCodeAndProcessed("FXG",
				"12345000000", "Y");
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void findByProcessedAndCurrentAndCancelledFlagAndTransactionType() {
		List<ZipToDest> result = new ArrayList<>();
		when(zipToDestRedisRepository.findByProcessedAndCurrentAndCancelledFlagAndTransactionType("Y", "Y", "Y", "A"))
				.thenReturn(result);
		List<ZipToDest> rValue = zipToDestTransactionRepository
				.findByProcessedAndCurrentAndCancelledFlagAndTransactionType("Y", "Y", "Y", "A");
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void testFindOlderTransactions() {
		List<ZipToDest> output = Collections.emptyList();
		when(zipToDestRedisRepository.findByNetworkAndZipCodeAndProcessed("FXG", "12345000000", "Y"))
				.thenReturn(output);
		List<ZipToDest> rValue = zipToDestTransactionRepository.findOlderTransactions("FXG", "12345000000",
				System.currentTimeMillis() / 1000);
		assertTrue(rValue.isEmpty());

		output = new ArrayList<>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setEffectiveDateAt(System.currentTimeMillis() / 1000);
		output.add(zipToDest);

		when(zipToDestRedisRepository.findByNetworkAndZipCodeAndProcessed("FXG", "12345000000", "Y"))
				.thenReturn(output);
		rValue = zipToDestTransactionRepository.findOlderTransactions("FXG", "12345000000",
				System.currentTimeMillis() / 1000);
		assertFalse(rValue.isEmpty());

		when(zipToDestRedisRepository.findByNetworkAndZipCodeAndProcessed("FXG", "12345000000", "Y"))
				.thenReturn(output);
		rValue = zipToDestTransactionRepository.findOlderTransactions("FXG", "12345000000",
				(System.currentTimeMillis() / 1000) - 1000);
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void testFindUnProcessedTransactionByType() {
		List<ZipToDest> output = Collections.emptyList();

		when(zipToDestRedisRepository.findByProcessedAndCurrentAndCancelledFlagAndTransactionType("N", "N", "N", "A"))
				.thenReturn(output);
		List<ZipToDest> rValue = zipToDestTransactionRepository
				.findUnProcessedTransactionByType(System.currentTimeMillis() / 1000, "A");
		assertTrue(rValue.isEmpty());

		output = new ArrayList<>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setEffectiveDateAt(System.currentTimeMillis() / 1000);
		output.add(zipToDest);

		when(zipToDestRedisRepository.findByProcessedAndCurrentAndCancelledFlagAndTransactionType("N", "N", "N", "A"))
				.thenReturn(output);
		rValue = zipToDestTransactionRepository.findUnProcessedTransactionByType(System.currentTimeMillis() / 1000,
				"A");
		assertFalse(rValue.isEmpty());

		when(zipToDestRedisRepository.findByProcessedAndCurrentAndCancelledFlagAndTransactionType("N", "N", "N", "A"))
				.thenReturn(output);
		rValue = zipToDestTransactionRepository
				.findUnProcessedTransactionByType(System.currentTimeMillis() / 1000 - 100, "A");
		assertTrue(rValue.isEmpty());
	}

	@Test
	public void testGetKeySpace() {
		String rValue = zipToDestTransactionRepository.getKeySpace();
		assertNull(rValue);
	}

	@Test
	public void testSave() {
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setId("12345");
		zipToDest.setNetwork("FXG");
		zipToDest.setEffectiveDateAt(System.currentTimeMillis() / 1000);
		zipToDest.setZipCode("A0A");
		zipToDest.setCreatedDateAt(System.currentTimeMillis() / 1000);
		when(zipToDestRedisRepository.save(zipToDest)).thenReturn(zipToDest);

		ZipToDest output = zipToDestTransactionRepository.save(zipToDest);
		assertNotNull(output.getEffectiveDate());

		zipToDest.setProcessedDateTime(System.currentTimeMillis() / 1000);
		ZipToDest zipToDest2 = new ZipToDest();
		zipToDest2.setId("345");
		zipToDest2.setProcessedDateTime(System.currentTimeMillis() / 1000);
		Set<ZipToDest> processedTrans = new HashSet<>();
		processedTrans.add(zipToDest);
		processedTrans.add(zipToDest2);
		when(zSetProcessedOperations.range(ZipToDestBatchUtil.getRedisKey(zipToDestTransactionRepository.getKeySpace(),
				AppConstants.APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY), 0, -1)).thenReturn(processedTrans);
		when(zipToDestRedisRepository.save(zipToDest)).thenReturn(zipToDest);
		output = zipToDestTransactionRepository.save(zipToDest);
		assertNotNull(output.getProcessedDateTime());
	}

	@Test
	public void testInit() {
		when(redisStringTemplate.opsForZSet()).thenReturn(zipSetOperations);
		when(redisLongTemplate.opsForZSet()).thenReturn(zipSetProcessedDateOperations);
		zipToDestTransactionRepository.init();
		assertNotNull(zipToDestTransactionRepository.getZipSetProcessedDateOperations());
	}

	@Test
	public void testFindByProcessedAndCurrentAndCancelledFlag() {
		List<ZipToDest> actual = Collections.emptyList();
		when(zipToDestRedisRepository.findByProcessedAndCurrentAndCancelledFlag("Y", "Y", "Y")).thenReturn(actual);
		List<ZipToDest> output = zipToDestTransactionRepository.findByProcessedAndCurrentAndCancelledFlag("Y", "Y",
				"Y");
		assertNotNull(output);
	}
}
*/