package com.fedex.ziptodest.batch.util;

import static org.junit.Assert.assertNotEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import org.junit.Test;

import com.fedex.ziptodest.batch.util.AppConstants;

public class AppConstantTest {

	@Test
	public void testPrivateConstructor() throws Exception {
		Constructor<AppConstants> constructor = AppConstants.class.getDeclaredConstructor();
		assertNotEquals(1, Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}
}
