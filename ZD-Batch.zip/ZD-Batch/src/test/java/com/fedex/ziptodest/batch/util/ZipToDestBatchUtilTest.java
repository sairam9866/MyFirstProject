/*package com.fedex.ziptodest.batch.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import com.fedex.ziptodest.model.JobAuditResponse;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

public class ZipToDestBatchUtilTest {
	ZipToDest zipToDest;
	
	@Before
	public void init(){		
		zipToDest = new ZipToDest();
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setTransactionType("A");
		zipToDest.setProcessed("N");		
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
	}
	
	@Test
	public void testInstanceOfZipToDestHistory(){
		ZipToDestHasDelta zipToDestHasDelta = ZipToDestBatchUtil.instanceOfZipToDestHasDelta("FHDL", ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());				
		assertNotNull(zipToDestHasDelta.getNetwork());
		assertNotNull(zipToDestHasDelta.getLastUpdateTimestamp());
	}
	
	@Test
	public void testGetCurrentUtcTimestamp(){
		Timestamp utcTime = ZipToDestBatchUtil.getCurrentUtcTimestamp();		
		assertNotNull(utcTime);
	}
	
	@Test
	public void testIsValidUsaZipCode(){
		assertTrue(ZipToDestBatchUtil.isValidUsaZipCode("12456"));
		assertFalse(ZipToDestBatchUtil.isValidUsaZipCode("A0A0A0"));
	}
	
	@Test
	public void testIsValidCanadaZipCode(){
		assertTrue(ZipToDestBatchUtil.isValidCanadaZipCode("A0A0A0"));
		assertTrue(ZipToDestBatchUtil.isValidCanadaZipCode("A0A"));
		assertFalse(ZipToDestBatchUtil.isValidCanadaZipCode("12345"));
	}
	
	@Test
	public void testGetActualZipcode(){
		assertEquals("50450", ZipToDestBatchUtil.getActualZipcode("50450000000"));
		assertEquals("A0A0A0", ZipToDestBatchUtil.getActualZipcode("A0A0A0"));
	}
	
	@Test
	public void testInstanceOfJobAuditResponse(){
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		
		JobAuditResponse jobAuditResponse = ZipToDestBatchUtil.instanceOfJobAuditResponse(jobExecution);
		assertNotNull(jobAuditResponse.getCreateTime());
		assertNotNull(jobAuditResponse.getEndTime());
		assertNotNull(jobAuditResponse.getExitMessage());
		assertNotNull(jobAuditResponse.getLastUpdated());
		assertNotNull(jobAuditResponse.getStartTime());
		assertNotNull(jobAuditResponse.getStatus());
		
		jobExecution.addFailureException(new RuntimeException("Testing"));
		jobAuditResponse = ZipToDestBatchUtil.instanceOfJobAuditResponse(jobExecution);
		assertNotNull(jobAuditResponse.getStackTrace());
	}
	
	@Test
	public void testGetCurrentExecutionContext(){
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);
		assertNotNull(ZipToDestBatchUtil.getCurrentExecutionContext(chunkContext));
	}

}
*/