package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.ZipToDestHasDelta;

public class ZipToDestHasDeltaTest {

	ZipToDestHasDelta zipToDestHasDelta;

	@Before
	public void init() {
		zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork("FHDL");
		zipToDestHasDelta.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
	}

	@Test
	public void testZipToDestHasDelta() {
		assertNotNull(zipToDestHasDelta.getNetwork());
		assertNotNull(zipToDestHasDelta.getLastUpdateTimestamp());
		assertNotNull(zipToDestHasDelta.toString());
	}

	@Test
	public void testHashCode() {
		ZipToDestHasDelta zipToDestHasDelta1 = new ZipToDestHasDelta();
		ZipToDestHasDelta zipToDestHasDelta2 = new ZipToDestHasDelta();
		assertEquals(zipToDestHasDelta1.hashCode(), zipToDestHasDelta1.hashCode());
		zipToDestHasDelta1.setNetwork("FXG");
		zipToDestHasDelta2.setNetwork("FXG");
		assertEquals(zipToDestHasDelta1.hashCode(), zipToDestHasDelta2.hashCode());
	}

	@Test
	public void testEquals() {
		ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork("FHDL");
		zipToDestHasDelta.setLastUpdateTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());

		assertTrue(zipToDestHasDelta.equals(zipToDestHasDelta));
		ZipToDestHasDelta zipToDestHasDelta2 = null;
		assertFalse(zipToDestHasDelta.equals(zipToDestHasDelta2));
		assertFalse(zipToDestHasDelta.equals(new Object()));
		zipToDestHasDelta2 = new ZipToDestHasDelta();
		zipToDestHasDelta.setNetwork(null);
		zipToDestHasDelta2.setNetwork(null);
		assertTrue(zipToDestHasDelta.equals(zipToDestHasDelta2));
		zipToDestHasDelta2.setNetwork("");
		assertFalse(zipToDestHasDelta.equals(zipToDestHasDelta2));
		zipToDestHasDelta.setNetwork("FXG");
		assertFalse(zipToDestHasDelta.equals(zipToDestHasDelta2));
		zipToDestHasDelta2.setNetwork(zipToDestHasDelta.getNetwork());
		assertTrue(zipToDestHasDelta.equals(zipToDestHasDelta2));

	}
}
