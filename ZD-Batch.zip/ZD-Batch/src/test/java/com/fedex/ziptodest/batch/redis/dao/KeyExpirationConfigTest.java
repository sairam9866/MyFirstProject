package com.fedex.ziptodest.batch.redis.dao;

import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class KeyExpirationConfigTest {

	@InjectMocks
	RedisJobInstanceDao keyExpirationConfig;

	@Mock
	private RedisTemplate<String, Object> redisTemplate;

	@Mock
	Environment evironment;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testSetTimeToLive(){
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(false);
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(0L);
		when(evironment.getProperty("redis.keys.expire.hours", Long.class, 0L)).thenReturn(0L);
		
		when(redisTemplate.getExpire("KEY")).thenReturn(11L);		
		keyExpirationConfig.setTimeToLive("KEY");
		
		when(redisTemplate.getExpire("KEY")).thenReturn(-2L);		
		keyExpirationConfig.setTimeToLive("KEY");
		
		when(redisTemplate.getExpire("KEY")).thenReturn(112L);		
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(true);
		keyExpirationConfig.setTimeToLive("KEY");
		
		when(redisTemplate.getExpire("KEY")).thenReturn(-1L);
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(true);		
		keyExpirationConfig.setTimeToLive("KEY");
		
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(120L);
		when(redisTemplate.getExpire("KEY")).thenReturn(-1L);
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(true);		
		keyExpirationConfig.setTimeToLive("KEY");
		
		when(evironment.getProperty("redis.keys.expire.hours", Long.class, 0L)).thenReturn(120L);
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(0L);
		when(redisTemplate.getExpire("KEY")).thenReturn(-1L);
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(true);		
		keyExpirationConfig.setTimeToLive("KEY");
	}
}
