/*package com.fedex.ziptodest.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.model.ZipToDest;

public class ZipToDestTest {
	ZipToDest zipToDest;

	@Before
	public void init() {
		zipToDest = new ZipToDest();
		zipToDest.setCountryCode(840);
		zipToDest.setNetwork("FXG");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Fedex");
		zipToDest.setDestinationTerminal("123");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipCode("12345");
		zipToDest.setState("PA");
		zipToDest.setProcessed("N");
		zipToDest.setUuid("ASWE-VDR34D-SSD2AE");
		zipToDest.setCancelledFlag("N");
		zipToDest.setCurrent("N");
		zipToDest.setTransactionType("A");
		zipToDest.setProcessedDateTime(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCancelledTimestamp(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setZipFrom("123");
		zipToDest.setZipTo("23434");
		zipToDest.setTimeZone("UTC");
		zipToDest.setCancelledUser("TEST");
		zipToDest.buildKey();
	}

	@Test
	public void testZipToDest() {
		assertNotNull(zipToDest.getId());
		assertNotNull(zipToDest.getCancelledFlag());
		assertNotNull(zipToDest.getCancelledTimestamp());
		assertNotNull(zipToDest.getCancelledUser());
		assertNotNull(zipToDest.getCountryCode());
		assertNotNull(zipToDest.getCreatedDateAt());
		assertNotNull(zipToDest.getCreationUser());
		assertNotNull(zipToDest.getCurrent());
		assertNotNull(zipToDest.getDestinationTerminal());
		assertNotNull(zipToDest.getEffectiveDateAt());
		assertNotNull(zipToDest.getNetwork());
		assertNotNull(zipToDest.getProcessed());
		assertNotNull(zipToDest.getState());
		assertNotNull(zipToDest.getTransactionType());
		assertNotNull(zipToDest.getUuid());
		assertNotNull(zipToDest.getZipCode());
		assertNotNull(zipToDest.getZipFrom());
		assertNotNull(zipToDest.getZipTo());
		assertNotNull(zipToDest.getTimeZone());
		assertNotNull(zipToDest.toString());
		assertNotNull(zipToDest.getProcessedDateTime());
		assertNotNull(zipToDest.getCreationDate());
		assertNotNull(zipToDest.getEffectiveDate());
		assertNotNull(zipToDest.getProcessedAt());
		assertNotNull(zipToDest.getCancelledAt());		
	}
	
	@Test
	public void testLocalDateFields(){
		ZipToDest zipToDest = new ZipToDest();
		assertNull(zipToDest.getProcessedAt());
		assertNull(zipToDest.getCreationDate());
		assertNull(zipToDest.getEffectiveDate());		
		assertNull(zipToDest.getCancelledAt());
	}

	@Test
	public void testHashCode() {
		ZipToDest zipToDest1 = new ZipToDest();
		ZipToDest zipToDest2 = new ZipToDest();
		assertEquals(zipToDest1.hashCode(), zipToDest2.hashCode());
		zipToDest1.setId("FXG");
		zipToDest2.setId("FXG");
		assertEquals(zipToDest1.hashCode(), zipToDest2.hashCode());
	}

	@Test
	public void testEquals() {
		assertTrue(zipToDest.equals(zipToDest));
		ZipToDest zipToDest2 = null;
		assertFalse(zipToDest.equals(zipToDest2));
		assertFalse(zipToDest.equals(new Object()));
		zipToDest2 = new ZipToDest();
		zipToDest.setId(null);
		zipToDest2.setId(null);
		assertTrue(zipToDest.equals(zipToDest2));
		zipToDest2.setId("");
		assertFalse(zipToDest.equals(zipToDest2));
		zipToDest.buildKey();
		assertFalse(zipToDest.equals(zipToDest2));
		zipToDest2.setId(zipToDest.getId());
		assertTrue(zipToDest.equals(zipToDest2));
	}
	
	@Test
	public void testIsCancelled(){
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCancelledFlag("N");
		zipToDest.setProcessed("N");
		zipToDest.setCurrent("N");
		zipToDest.getTimeToLive();
		zipToDest.setCancelledFlag("Y");
		zipToDest.setProcessed("N");
		zipToDest.setCurrent("N");
		zipToDest.getTimeToLive();
		zipToDest.setCancelledFlag("N");
		zipToDest.setProcessed("Y");
		zipToDest.setCurrent("N");
		zipToDest.getTimeToLive();
		zipToDest.setCancelledFlag("N");
		zipToDest.setProcessed("Y");
		zipToDest.setCurrent("Y");
		zipToDest.getTimeToLive();
	}
}
*/