/*package com.fedex.ziptodest.batch.redis.dao;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.StepExecution;
import org.springframework.core.env.Environment;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.redis.dao.model.RedisJobExecution;
import com.fedex.ziptodest.batch.redis.dao.model.RedisStepExecution;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

@RunWith(SpringRunner.class)
public class RedisStepExecutionDaoTest {

	@InjectMocks
	RedisStepExecutionDao redisStepExecutionDao;

	@Mock
	ZSetOperations<String, RedisStepExecution> opsStepExecutionSortedSet;

	@Mock
	ZSetOperations<String, RedisJobExecution> opsJobExecutionSortedSet;
	
	@Mock
	Environment evironment;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSaveStepExecution() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		StepExecution stepExecution = new StepExecution("StepName", jobExecution);
		
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(false);
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(0L);
		when(evironment.getProperty("redis.keys.expire.hours", Long.class, 0L)).thenReturn(0L);
		
		redisStepExecutionDao.saveStepExecution(stepExecution);
	}

	@Test
	public void testSaveStepExecutions() {
		List<StepExecution> stepExecutions = Collections.emptyList();
		redisStepExecutionDao.saveStepExecutions(stepExecutions);

		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		StepExecution stepExecution = new StepExecution("StepName", jobExecution);

		stepExecutions = new ArrayList<>();
		stepExecutions.add(stepExecution);

		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(false);
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(0L);
		when(evironment.getProperty("redis.keys.expire.hours", Long.class, 0L)).thenReturn(0L);
		redisStepExecutionDao.saveStepExecutions(stepExecutions);
	}

	@Test
	public void testGetStepExecution() {
		Long stepExecutionId = 123L;

		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);

		JobInstance jobInstance1 = new JobInstance(124L, "JobName1");
		JobExecution jobExecution1 = new JobExecution(2L);
		jobExecution1.setStatus(BatchStatus.STARTED);
		jobExecution1.setCreateTime(new Date());
		jobExecution1.setExitStatus(ExitStatus.EXECUTING);
		jobExecution1.setJobInstance(jobInstance1);

		redisStepExecutionDao.getStepExecution(jobExecution, stepExecutionId);

		RedisStepExecution redisStepExecution = getRedisStepExecution();
		redisStepExecution.setJobExecution(jobExecution);
		redisStepExecution.setJobExecutionId(jobExecution.getId());

		Set<RedisStepExecution> redisStepExecutions = new HashSet<>();
		redisStepExecutions.add(redisStepExecution);

		when(opsStepExecutionSortedSet.rangeByScore(ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
				AppConstants.STEP_EXECUTION_SET_KEY), stepExecutionId, stepExecutionId))
						.thenReturn(redisStepExecutions);

		redisStepExecutionDao.getStepExecution(jobExecution, stepExecutionId);

		RedisStepExecution redisStepExecution1 = getRedisStepExecution();
		redisStepExecution1.setJobExecution(jobExecution1);
		redisStepExecution1.setJobExecutionId(jobExecution1.getId());

		redisStepExecutions = new HashSet<>();
		redisStepExecutions.add(redisStepExecution1);

		when(opsStepExecutionSortedSet.rangeByScore(ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
				AppConstants.STEP_EXECUTION_SET_KEY), stepExecutionId, stepExecutionId))
						.thenReturn(redisStepExecutions);

		redisStepExecutionDao.getStepExecution(jobExecution, stepExecutionId);
	}

	@Test
	public void testAddStepExecutions() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);

		redisStepExecutionDao.addStepExecutions(jobExecution);

		Set<RedisStepExecution> stepExecutions = new HashSet<>();

		RedisStepExecution redisStepExecution = getRedisStepExecution();
		redisStepExecution.setJobExecution(jobExecution);
		redisStepExecution.setJobExecutionId(jobExecution.getId());

		stepExecutions.add(redisStepExecution);

		when(opsStepExecutionSortedSet.range(ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
				AppConstants.STEP_EXECUTION_SET_KEY), 0, -1)).thenReturn(stepExecutions);

		redisStepExecutionDao.addStepExecutions(jobExecution);

		JobInstance jobInstance1 = new JobInstance(123L, "JobName");
		JobExecution jobExecution1 = new JobExecution(21L);
		jobExecution1.setStatus(BatchStatus.STARTED);
		jobExecution1.setCreateTime(new Date());
		jobExecution1.setExitStatus(ExitStatus.EXECUTING);
		jobExecution1.setJobInstance(jobInstance1);

		RedisStepExecution redisStepExecution1 = getRedisStepExecution();
		redisStepExecution1.setJobExecution(jobExecution1);
		redisStepExecution1.setJobExecutionId(jobExecution1.getId());
		stepExecutions.clear();
		stepExecutions.add(redisStepExecution1);

		when(opsStepExecutionSortedSet.range(ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
				AppConstants.STEP_EXECUTION_SET_KEY), 0, -1)).thenReturn(stepExecutions);

		redisStepExecutionDao.addStepExecutions(jobExecution);
	}

	@Test
	public void testGetLastStepExecution() {
		String stepName = "stepName";
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobInstance jobInstance1 = new JobInstance(124L, "JobName");

		Set<RedisStepExecution> stepExecutions = new HashSet<>();
		Set<RedisJobExecution> jobExecutions = new HashSet<>();

		when(opsStepExecutionSortedSet.range(ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
				AppConstants.STEP_EXECUTION_SET_KEY), 0, -1)).thenReturn(stepExecutions);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(jobExecutions);

		redisStepExecutionDao.getLastStepExecution(jobInstance, stepName);

		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();
		RedisJobExecution redisJobExecution = new RedisJobExecution(jobExecution);
		
		JobExecution jobExecution1 = new JobExecution(2L);
		jobExecution1.setStatus(BatchStatus.STARTED);
		jobExecution1.setCreateTime(new Date());
		jobExecution1.setExitStatus(ExitStatus.EXECUTING);
		jobExecution1.setJobInstance(jobInstance1);
		jobExecution1.incrementVersion();
		RedisJobExecution redisJobExecution2 = new RedisJobExecution(jobExecution1);
		
		jobExecutions.add(redisJobExecution);
		jobExecutions.add(redisJobExecution2);
		
		RedisStepExecution redisStepExecution = getRedisStepExecution();
		redisStepExecution.setJobExecution(jobExecution);
		redisStepExecution.setJobExecutionId(jobExecution.getId());		
		
		stepExecutions.add(redisStepExecution);		
		
		when(opsStepExecutionSortedSet.range(ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
				AppConstants.STEP_EXECUTION_SET_KEY), 0, -1)).thenReturn(stepExecutions);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(jobExecutions);

		redisStepExecutionDao.getLastStepExecution(jobInstance, stepName);
	}
	
	@Test
	public void testUpdateStepExecution(){
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		
		RedisStepExecution redisStepExecution = getRedisStepExecution();
		redisStepExecution.setJobExecution(jobExecution);
		redisStepExecution.setJobExecutionId(jobExecution.getId());	
		
		StepExecution stepExecution = getStepExecution(redisStepExecution, jobExecution);		
		ExitStatus exitStatus = ExitStatus.COMPLETED;		
		exitStatus.addExitDescription(getExtiDescription());
		stepExecution.setExitStatus(exitStatus);		
		
		when(opsStepExecutionSortedSet.add(
				ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
						AppConstants.STEP_EXECUTION_SET_KEY), redisStepExecution,
				redisStepExecution.getStepExecutionId())).thenReturn(true);
		
		redisStepExecutionDao.updateStepExecution(stepExecution);
	}
	
	@Test
	public void testUpdateStepExecutionLock(){
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		
		RedisStepExecution redisStepExecution = getRedisStepExecution();
		redisStepExecution.setJobExecution(jobExecution);
		redisStepExecution.setJobExecutionId(jobExecution.getId());	
		
		StepExecution stepExecution = getStepExecution(redisStepExecution, jobExecution);		
		ExitStatus exitStatus = ExitStatus.COMPLETED;		
		exitStatus.addExitDescription(getExtiDescription());
		stepExecution.setExitStatus(exitStatus);		
		
		Set<RedisStepExecution> currentStepExecution = new HashSet<>();
		
		currentStepExecution.add(redisStepExecution);
		
		when(opsStepExecutionSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisStepExecutionDao.getKeySpace(),
						AppConstants.STEP_EXECUTION_SET_KEY),
				stepExecution.getId(), stepExecution.getId())).thenReturn(currentStepExecution);
		stepExecution.incrementVersion();		
		
		assertThatExceptionOfType(OptimisticLockingFailureException.class)
		.isThrownBy(() -> redisStepExecutionDao.updateStepExecution(stepExecution));
	}

	private RedisStepExecution getRedisStepExecution() {
		RedisStepExecution stepExecution = new RedisStepExecution();
		stepExecution.setStepExecutionId(123L);
		stepExecution.setStepName("stepName");
		stepExecution.setStartTime(new Date());
		stepExecution.setEndTime(new Date());
		stepExecution.setStatus(BatchStatus.COMPLETED.toString());
		stepExecution.setCommitCount(1);
		stepExecution.setReadCount(1);
		stepExecution.setFilterCount(0);
		stepExecution.setWriteCount(0);
		stepExecution.setExitCode(ExitStatus.COMPLETED.toString());
		stepExecution.setReadSkipCount(0);
		stepExecution.setWriteSkipCount(0);
		stepExecution.setProcessSkipCount(0);
		stepExecution.setRollbackCount(0);
		stepExecution.setLastUpdated(new Date());
		stepExecution.setVersion(0);
		return stepExecution;
	}
	

	private StepExecution getStepExecution(RedisStepExecution redisStepExecution, JobExecution jobExecution) {
		StepExecution stepExecution = new StepExecution(redisStepExecution.getStepName(), jobExecution,
				redisStepExecution.getStepExecutionId());
		stepExecution.setStartTime(redisStepExecution.getStartTime());
		stepExecution.setEndTime(redisStepExecution.getEndTime());
		stepExecution.setStatus(BatchStatus.valueOf(redisStepExecution.getStatus()));
		stepExecution.setCommitCount(redisStepExecution.getCommitCount());
		stepExecution.setReadCount(redisStepExecution.getReadCount());
		stepExecution.setFilterCount(redisStepExecution.getFilterCount());
		stepExecution.setWriteCount(redisStepExecution.getWriteCount());
		stepExecution
				.setExitStatus(new ExitStatus(redisStepExecution.getExitCode(), redisStepExecution.getExistMessage()));
		stepExecution.setReadSkipCount(redisStepExecution.getReadSkipCount());
		stepExecution.setWriteSkipCount(redisStepExecution.getWriteSkipCount());
		stepExecution.setProcessSkipCount(redisStepExecution.getProcessSkipCount());
		stepExecution.setRollbackCount(redisStepExecution.getRollbackCount());
		stepExecution.setLastUpdated(redisStepExecution.getLastUpdated());
		stepExecution.setVersion(redisStepExecution.getVersion());
		return stepExecution;
	}
	
	private String getExtiDescription(){		
		StringBuilder str = new StringBuilder("Test string greater than 2500.");
		for(int i=0; i<8; i++){
			str.append(str);
		}		
		System.out.println("Description zise :" +str.length());
		return str.toString();
	}
}
*/