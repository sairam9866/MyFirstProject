/*package com.fedex.ziptodest.batch.service.impl;

import static org.junit.Assert.assertEquals;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.dao.ZipToDestHasDeltaDao;
import com.fedex.ziptodest.batch.service.impl.ZipToDestHasDeltaServiceImpl;
import com.fedex.ziptodest.model.ZipToDest;

@RunWith(SpringRunner.class)
public class ZipToDestHasDeltaServiceImplTest {

	@InjectMocks
	ZipToDestHasDeltaServiceImpl zipToDestHasDeltaService;
	
	@Mock
	ZipToDestHasDeltaDao zipToDestHasDeltaDao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testInsertOrUpdateZipToDestHistory(){
		List<ZipToDest> zipToDestList1 = new ArrayList<>();
		ZipToDest zipToDest1 = new ZipToDest();
		zipToDest1.setNetwork("FHDL");
		ZipToDest zipToDest2 = new ZipToDest();
		zipToDest2.setNetwork("FXGL");		
		ZipToDest zipToDest3 = new ZipToDest();
		zipToDest3.setNetwork("FXL");
		zipToDestList1.add(zipToDest1);
		zipToDestList1.add(zipToDest2);
		zipToDestList1.add(zipToDest3);
		
		Set<String> networks = (zipToDestList1.stream().map(ZipToDest::getNetwork).collect(Collectors.toSet()));
		
		int insertCount = zipToDestHasDeltaService.insertOrUpdateZipToDestHasDelta(networks, ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		assertEquals(networks.size(), insertCount);
	}
}
*/