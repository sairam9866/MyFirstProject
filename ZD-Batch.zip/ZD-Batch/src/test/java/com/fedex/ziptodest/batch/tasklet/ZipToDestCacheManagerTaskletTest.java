/*package com.fedex.ziptodest.batch.tasklet;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.fedex.ziptodest.batch.util.AppConstants;

@RunWith(SpringRunner.class)
public class ZipToDestCacheManagerTaskletTest {

	@InjectMocks
	ZipToDestCacheManagerTasklet zipToDestCacheManagerTasklet;
	
	@Mock
	private RestTemplate restTemplate;

	@Mock
	private Environment environment;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testZipToDestCacheManagerTasklet() throws Exception{
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);		
		jobExecution.getExecutionContext().putInt(AppConstants.KEY_EXECUTION_COUNT, 1);

		StepExecution execution = new StepExecution("zipToDestModifyReadTasklet", jobExecution);
		StepContribution contribution = new StepContribution(execution);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);
		
		Mockito.doReturn("http://localhost:8080/clearAllCaches").when(environment).getProperty(AppConstants.ZD_DISTRIBUTION_CACHE_URL);
		Mockito.doReturn("cache").when(environment).getProperty(AppConstants.ZD_DISTRIBUTION_CACHE_KEY);
		

		RepeatStatus status = zipToDestCacheManagerTasklet.execute(contribution, chunkContext);
		
		assertEquals(RepeatStatus.FINISHED, status);
		
	}
}
*/