package com.fedex.ziptodest.batch.util;

import java.util.List;

import org.junit.Test;

import com.fedex.ziptodest.model.ZipToDest;

public class CsvReaderTest {

	@Test
	public void test() {
		CsvReader<ZipToDest> reader1 = new CsvReader<>();

		List<ZipToDest> records1 = reader1.read(ZipToDest.class, "transactions.csv");
		List<ZipToDest> empty1 = reader1.read(ZipToDest.class, "");
		// assertFalse(records1.isEmpty());
		// assertTrue(empty1.isEmpty());

	}
}
