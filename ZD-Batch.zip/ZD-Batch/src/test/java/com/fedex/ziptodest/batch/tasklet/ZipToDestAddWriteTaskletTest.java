/*package com.fedex.ziptodest.batch.tasklet;

import static org.junit.Assert.assertEquals;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.service.ZipToDestTransactionService;
import com.fedex.ziptodest.batch.service.ZipToDestinationService;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;

@RunWith(SpringRunner.class)
public class ZipToDestAddWriteTaskletTest {

	@InjectMocks
	ZipToDestAddWriteTasklet zipToDestAddWriteTasklet;
	
	@Mock
	private ZipToDestinationService zipToDestinationService;

	@Mock
	private ZipToDestTransactionService zipToDestTransactionService;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testZipToDestAddWriteTasklet() throws Exception{
		
		List<ZipToDest> unprocessed = new ArrayList<>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(840);
		zipToDest.setCancelledFlag("N");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Test");
		zipToDest.setCurrent("N");
		zipToDest.setDestinationTerminal("11");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setProcessed("N");
		zipToDest.setNetwork("FHDL");
		zipToDest.setState("WA");
		zipToDest.setTransactionType("A");
		zipToDest.setUuid("asdsadsd-asdsad--adsa");
		zipToDest.setZipCode("50450000000");
		
		
		
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		jobExecution.getExecutionContext().put(ZipToDestBatchUtil.KEY_UNPROCESSED_ADDED, unprocessed);

		StepExecution execution = new StepExecution("zipToDestModifyReadTasklet", jobExecution);
		StepContribution contribution = new StepContribution(execution);
		
		StepExecution stepExecution = new StepExecution("Step1", jobExecution);
		StepContext stepContext = new StepContext(stepExecution); 
		ChunkContext chunkContext = new ChunkContext(stepContext);	
		
		RepeatStatus status = zipToDestAddWriteTasklet.execute(contribution, chunkContext);
		assertEquals(RepeatStatus.FINISHED, status);
		unprocessed.add(zipToDest);
		jobExecution.getExecutionContext().putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, 1);
		status = zipToDestAddWriteTasklet.execute(contribution, chunkContext);
		assertEquals(RepeatStatus.FINISHED, status);
		
		
		
	}
}
*/