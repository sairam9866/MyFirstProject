/*package com.fedex.ziptodest.batch.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.repository.NetworkRepository;
import com.fedex.ziptodest.batch.repository.redis.CountryCodeRedisRepository;
import com.fedex.ziptodest.batch.repository.redis.DestinationRedisRepository;
import com.fedex.ziptodest.batch.repository.redis.StateProvinceRedisRepository;
import com.fedex.ziptodest.model.CountryCode;
import com.fedex.ziptodest.model.Destination;
import com.fedex.ziptodest.model.Network;
import com.fedex.ziptodest.model.StateProvince;

@RunWith(SpringRunner.class)
public class IseriesDataServiceImplTest {

	@InjectMocks
	IseriesDataServiceImpl iseriesDataServiceImpl;
	
	@Mock
	NetworkRepository networkRepository;
	
	@Mock
	CountryCodeRedisRepository countryCodeRedisRepository;
	
	@Mock
	DestinationRedisRepository destinationRedisRepository;
	
	@Mock
	StateProvinceRedisRepository stateProvinceRedisRepository;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testSelectAllCountryCode() {
		List<CountryCode> actual = Collections.emptyList();
		when(countryCodeRedisRepository.findAll()).thenReturn(actual);
		List<CountryCode> output = iseriesDataServiceImpl.selectAllCountryCode();
		assertNotNull(output);
	}

	@Test
	public void testSelectAllDestination() {
		List<Destination> actual = Collections.emptyList();
		when(destinationRedisRepository.findAll()).thenReturn(actual);
		List<Destination> output = iseriesDataServiceImpl.selectAllDestination();
		assertNotNull(output);
	}

	@Test
	public void testSelectAllNetworks() {
		List<Network> actual = Collections.emptyList();
		when(networkRepository.findAll()).thenReturn(actual);
		List<Network> output = iseriesDataServiceImpl.selectAllNetworks();
		assertNotNull(output);
	}

	@Test
	public void testSelectAllStateProvince() {
		List<StateProvince> actual = Collections.emptyList();
		when(stateProvinceRedisRepository.findAll()).thenReturn(actual);
		List<StateProvince> output = iseriesDataServiceImpl.selectAllStateProvince();
		assertNotNull(output);
	}
}
*/