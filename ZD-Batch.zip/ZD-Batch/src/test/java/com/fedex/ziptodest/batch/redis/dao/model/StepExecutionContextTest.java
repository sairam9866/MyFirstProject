package com.fedex.ziptodest.batch.redis.dao.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.batch.redis.dao.model.StepExecutionContext;

public class StepExecutionContextTest {

	StepExecutionContext obj;
	
	@Before
	public void init() {
		obj = new StepExecutionContext();
		obj.setSerializedContext("STR");
		obj.setShortContext("shotStr");
		obj.setStepExecutionId(123L);		
	}
	
	@Test
	public void testJobExecutionContext() {
		assertNotNull(obj);
		assertNotNull(obj.getStepExecutionId());
		assertNotNull(obj.getSerializedContext());
		assertNotNull(obj.getShortContext());
		assertNotNull(obj.toString());
	}
	
	@Test
	public void testHashCode(){
		StepExecutionContext execution1 = new StepExecutionContext();
		StepExecutionContext execution2 = new StepExecutionContext();
		assertEquals(execution1.hashCode(), execution2.hashCode());		
		execution1.setStepExecutionId(123L);
		execution2.setStepExecutionId(123L);
		assertEquals(execution1.hashCode(), execution2.hashCode());
	}
	
	@Test
	public void testEquals(){
		StepExecutionContext execution = new StepExecutionContext();
		execution.setStepExecutionId(123L);		
		
		assertTrue(execution.equals(execution));
		StepExecutionContext execution2 = null;
		assertFalse(execution.equals(execution2));
		assertFalse(execution.equals(new Object()));
		execution2 = new StepExecutionContext();
		execution.setStepExecutionId(null);
		execution2.setStepExecutionId(null);
		assertTrue(execution.equals(execution2));
		execution2.setStepExecutionId(124L);
		assertFalse(execution.equals(execution2));
		execution.setStepExecutionId(123L);
		assertFalse(execution.equals(execution2));
		execution2.setStepExecutionId(execution.getStepExecutionId());
		assertTrue(execution.equals(execution2));		
	}
}
