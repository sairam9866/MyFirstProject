/*package com.fedex.ziptodest.batch.redis.dao;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.model.ZipToDest;

@RunWith(SpringRunner.class)
public class ZipToDestDaoTest {

	@InjectMocks
	ZipToDestDao zipToDestDao;
	
	@Mock
	private ZSetOperations<String, ZipToDest> zSetOperations;

	@Mock
	private RedisTemplate<String, Long> redisLongTemplate;	

	@Mock
	private ZSetOperations<String, ZipToDest> zSetProcessedOperations;

	@Mock
	private ZSetOperations<String, ZipToDest> zSetCreationOperations;

	@Mock
	private ZSetOperations<String, ZipToDest> zSetCancelledOperations;

	@Mock
	private ZSetOperations<String, Long> zipSetCreationDateOperations;
	
	@Mock
	private ZSetOperations<String, Long> zipSetCancelledDateOperations;
	
	@Mock
	private ZSetOperations<String, Long> zipSetProcessedDateOperations;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testRemoveHistoryRecords(){
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setId("1234");
		zipToDest.setEffectiveDateAt(System.currentTimeMillis() / 1000);
		zipToDest.setCreatedDateAt(System.currentTimeMillis() / 1000);
		zipToDestDao.removeHistoryRecords(zipToDest);
		
		zipToDest.setProcessedDateTime(System.currentTimeMillis() / 1000);
		zipToDest.setCancelledTimestamp(System.currentTimeMillis() / 1000);
		zipToDestDao.removeHistoryRecords(zipToDest);
	}
	
	@Test
	public void testInit(){
		zipToDestDao.init();
	}
}
*/