package com.fedex.ziptodest.batch.service.impl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.dao.ZipToDestTransactionDao;

@RunWith(SpringRunner.class)
public class TransactionPayloadServiceImplTest {

	@InjectMocks
	private TransactionPayloadServiceImpl transactionPayloadServiceImpl;
	
	@Mock
	ZipToDestTransactionDao zipToDestTransactionDao;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testInit(){
		transactionPayloadServiceImpl.init();
	}
}
