package com.fedex.ziptodest.batch.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fedex.ziptodest.batch.service.DataLoaderService;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;

public class TransactionControllerTest {

	@InjectMocks
	TransactionController transactionController;

	@Mock
	DataLoaderService dataLoaderService;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFindAllFacilityHasDelta() {
		List<ZipToDestHasDelta> actual = Collections.emptyList();
		when(dataLoaderService.findAllFacilityHasDelta()).thenReturn(actual);
		List<ZipToDestHasDelta> output = transactionController.findAllFacilityHasDelta();
		assertNotNull(output);
	}

	@Test
	public void testFindAllHistoryTransaction() {
		List<ZipToDest> actual = Collections.emptyList();
		when(dataLoaderService.findAllHistoryTransaction()).thenReturn(actual);
		List<ZipToDest> output = transactionController.findAllHistoryTransaction();
		assertNotNull(output);
	}
	
	@Test
	public void testFindAllFutureTransaction(){
		List<ZipToDest> actual = Collections.emptyList();
		when(dataLoaderService.findAllFutureTransaction()).thenReturn(actual);
		List<ZipToDest> output = transactionController.findAllFutureTransaction();
		assertNotNull(output);
	}
	
	@Test
	public void testFindAllCurrentTransaction(){
		List<ZipToDest> actual = Collections.emptyList();
		when(dataLoaderService.findAllCurrentTransaction()).thenReturn(actual);
		List<ZipToDest> output = transactionController.findAllCurrentTransaction();
		assertNotNull(output);
	}
}
