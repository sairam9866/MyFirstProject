/*package com.fedex.ziptodest.batch.dao;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.model.mappers.NetworkMapper;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.commons.HashSetOperations;
import com.fedex.ziptodest.model.Network;

@RunWith(SpringRunner.class)
public class NetworkDaoTest {

	@InjectMocks
	NetworkDao networkDao;

	@Mock
	HashOperations<String, String, String> strHashOperations;

	@Mock
	SetOperations<String, String> strSetOperations;

	@Mock
	RedisTemplate<String, String> strRedisTemplate;

	@Mock
	NetworkMapper networkMapper;

	@Mock
	HashSetOperations hashSetOperations;

	@Mock
	ZipToDestBatchUtil zipToDestBatchUtil;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSave() {
		Network network = getNetwork();
		
		String hashKey = ":ISERIES:NETWORK:"+network.getNetworkId().toUpperCase();

		when(zipToDestBatchUtil.getIseriesNetworkKey(null, network.getNetworkId())).thenReturn(hashKey);
		
		Network output = networkDao.save(network);
		
		assertEquals(network.getNetworkId(), output.getNetworkId());
	}
	
	@Test
	public void testSaveAll() {
		List<Network> networks = new ArrayList<>();
		
		List<Object> list = new ArrayList<>();
		
		Network network = getNetwork();
		//networks.add(network);
		
		String hashKey = ":ISERIES:NETWORK:"+network.getNetworkId().toUpperCase();

		when(zipToDestBatchUtil.getIseriesNetworkKey(null, network.getNetworkId())).thenReturn(hashKey);
		
		when(strRedisTemplate.executePipelined(ArgumentMatchers.any(SessionCallback.class))).thenReturn(list);
		
		networkDao.saveAll(networks);
		
	}

	@Test
	public void testFindAll() {
		List<String> output = null;
		
		String expectedKey = ":ISERIES:NETWORK";
		Set<String> primaryKeys = null;

		// Null Testing
		when(zipToDestBatchUtil.getIseriesKey(null, AppConstants.ISERIES_NETWORK_SET_KEY)).thenReturn(expectedKey);

		when(hashSetOperations.findPrimaryKeys(expectedKey)).thenReturn(primaryKeys);
		output = networkDao.findAll();

		// Empty Testing
		primaryKeys = new HashSet<>();
		when(zipToDestBatchUtil.getIseriesKey(null, AppConstants.ISERIES_NETWORK_SET_KEY)).thenReturn(expectedKey);

		when(hashSetOperations.findPrimaryKeys(expectedKey)).thenReturn(primaryKeys);
		output = networkDao.findAll();

		// Not Empty Testing and Null Testing
		primaryKeys.add("pm1");
		when(zipToDestBatchUtil.getIseriesKey(null, AppConstants.ISERIES_NETWORK_SET_KEY)).thenReturn(expectedKey);

		when(hashSetOperations.findPrimaryKeys(expectedKey)).thenReturn(primaryKeys);
		List<Object> mapedObjects = null;
		when(hashSetOperations.getHashesFromRedis(primaryKeys)).thenReturn(mapedObjects);
		output = networkDao.findAll();

		// Not Empty Testing and not Null Testing
		primaryKeys.add("pm1");
		when(zipToDestBatchUtil.getIseriesKey(null, AppConstants.ISERIES_NETWORK_SET_KEY)).thenReturn(expectedKey);

		when(hashSetOperations.findPrimaryKeys(expectedKey)).thenReturn(primaryKeys);
		mapedObjects = new ArrayList<>();
		when(hashSetOperations.getHashesFromRedis(primaryKeys)).thenReturn(mapedObjects);
		output = networkDao.findAll();

		// Not Empty Testing and not empty Testing
		primaryKeys.add("pm1");
		when(zipToDestBatchUtil.getIseriesKey(null, AppConstants.ISERIES_NETWORK_SET_KEY)).thenReturn(expectedKey);

		when(hashSetOperations.findPrimaryKeys(expectedKey)).thenReturn(primaryKeys);
		mapedObjects.add(toMap());
		when(hashSetOperations.getHashesFromRedis(primaryKeys)).thenReturn(mapedObjects);
		output = networkDao.findAll();
	}

	private Map<String, String> toMap() {
		Network network = new Network();
		network.setNetworkId("FXG");
		network.setTermNum(1234L);
		network.setColocNum(1);
		network.setCreatedBy("TEST");
		network.setCreatedDate(LocalDate.now());
		network.setModelType("A");
		network.setRowId(1);
		network.setTermNum(11L);
		network.setUpdateDate(LocalDate.now());
		network.setUpdatedBy("TEST2");
		return networkMapper.toMap(network);
	}
	
	private Network getNetwork(){
		Network network = new Network();
		network.setNetworkId("FXG");
		network.setTermNum(1234L);
		network.setColocNum(123);
		network.setCreatedBy("TEST");
		network.setCreatedDate(LocalDate.now());
		network.setModelType("A");
		network.setRowId(101);
		network.setUpdateDate(LocalDate.now());
		network.setUpdatedBy("TEST");
		return network;
	}

}*/