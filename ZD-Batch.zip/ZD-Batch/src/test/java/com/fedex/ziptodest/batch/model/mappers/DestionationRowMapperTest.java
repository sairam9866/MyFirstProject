package com.fedex.ziptodest.batch.model.mappers;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.model.mappers.DestionationRowMapper;
import com.fedex.ziptodest.model.Destination;

@RunWith(SpringRunner.class)
public class DestionationRowMapperTest {
	
	DestionationRowMapper destionationRowMapper;

	@Mock
	ResultSet resultSet;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testDestionationRowMapper() throws SQLException{
		destionationRowMapper = new DestionationRowMapper();
		
		when(resultSet.getString("TRMABR")).thenReturn("PUER");
		when(resultSet.getInt("TRMNUM")).thenReturn(1245);
		when(resultSet.getString("TRMSTS")).thenReturn("A");
		
		Destination destination = destionationRowMapper.mapRow(resultSet, 1);
		assertEquals("PUER", destination.getTerminalAbbreviation());
		assertEquals(Integer.valueOf(1245), destination.getTerminalNumber());
		assertEquals("A", destination.getTerminalStatus());
	}
}


