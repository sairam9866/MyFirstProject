package com.fedex.ziptodest.batch.redis.dao.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.fedex.ziptodest.batch.redis.dao.model.RedisJobInstance;

public class RedisJobInstanceTest {
	RedisJobInstance obj;
	
	@Before
	public void init() {
		obj = new RedisJobInstance();
		obj.setJobInstanceId(123L);
		obj.setJobKey("JobKey");
		obj.setJobName("JobName");
		obj.setVersion(0);
	}
	
	@Test
	public void testRedisJobInstance() {
		assertNotNull(obj);
		
		assertNotNull(obj.getJobInstanceId());
		assertNotNull(obj.getJobKey());
		assertNotNull(obj.getJobName());
		assertNotNull(obj.getVersion());
		assertNotNull(obj.toString());
	}
	
	@Test
	public void testConstructors(){
		RedisJobInstance obj = new RedisJobInstance(123L, "JobName");
		assertNotNull(obj.getJobInstanceId());		
		assertNotNull(obj.getJobName());
	}
	
	@Test
	public void testIncrementVersion(){
		RedisJobInstance instance = new RedisJobInstance();
		instance.incrementVersion();
		assertEquals(Integer.valueOf(0), instance.getVersion());
		instance.incrementVersion();
		assertEquals(Integer.valueOf(1), instance.getVersion());
	}
	
	@Test
	public void testHashCode(){
		RedisJobInstance execution1 = new RedisJobInstance();
		RedisJobInstance execution2 = new RedisJobInstance();
		assertEquals(execution1.hashCode(), execution2.hashCode());		
		execution1.setJobInstanceId(123L);
		execution2.setJobInstanceId(123L);
		assertEquals(execution1.hashCode(), execution2.hashCode());
	}
	
	@Test
	public void testEquals(){
		RedisJobInstance execution = new RedisJobInstance();
		execution.setJobInstanceId(123L);		
		
		assertTrue(execution.equals(execution));
		RedisJobInstance execution2 = null;
		assertFalse(execution.equals(execution2));
		assertFalse(execution.equals(new Object()));
		execution2 = new RedisJobInstance();
		execution.setJobInstanceId(null);
		execution2.setJobInstanceId(null);
		assertTrue(execution.equals(execution2));
		execution2.setJobInstanceId(124L);
		assertFalse(execution.equals(execution2));
		execution.setJobInstanceId(123L);
		assertFalse(execution.equals(execution2));
		execution2.setJobInstanceId(execution.getJobInstanceId());
		assertTrue(execution.equals(execution2));		
	}
}

