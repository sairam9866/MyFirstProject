/*package com.fedex.ziptodest.batch.redis.dao;

import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.DefaultJobKeyGenerator;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobKeyGenerator;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.redis.dao.RedisJobInstanceDao;
import com.fedex.ziptodest.batch.redis.dao.model.RedisJobExecution;
import com.fedex.ziptodest.batch.redis.dao.model.RedisJobInstance;
import com.fedex.ziptodest.batch.util.AppConstants;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;

@RunWith(SpringRunner.class)
public class RedisJobInstanceDaoTest {

	@InjectMocks
	RedisJobInstanceDao redisJobInstanceDao;

	@Mock
	ZSetOperations<String, RedisJobInstance> opsJobInstanceSortedSet;

	@Mock
	ZSetOperations<String, String> opsJobInstanceString;

	@Mock
	ZSetOperations<String, RedisJobExecution> opsJobExecutionSortedSet;

	@Mock
	Environment evironment;

	@Mock
	JobKeyGenerator<JobParameters> jobKeyGenerator;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testCreateJobInstance() {
		String jobName = "jobName";
		JobParameters jobParameters = getJobParamaters();
		when(evironment.getProperty("redis.keys.expire.enabled", Boolean.class, false)).thenReturn(false);
		when(evironment.getProperty("redis.keys.expire.days", Long.class, 0L)).thenReturn(0L);
		when(evironment.getProperty("redis.keys.expire.hours", Long.class, 0L)).thenReturn(0L);
		redisJobInstanceDao.createJobInstance(jobName, jobParameters);
	}

	private JobParameters getJobParamaters() {
		JobParameters params = new JobParametersBuilder()
				.addString("job.id", String.valueOf(System.currentTimeMillis())).toJobParameters();
		return params;
	}

	@Test
	public void testGetJobInstance() {
		JobKeyGenerator<JobParameters> jobKeyGenerator1 = new DefaultJobKeyGenerator();

		Set<RedisJobInstance> redisJobInstances = new HashSet<>();
		String jobName = "jobName";
		JobParameters jobParameters = getJobParamaters();
		String jobKey = jobKeyGenerator1.generateKey(jobParameters);

		when(jobKeyGenerator.generateKey(jobParameters)).thenReturn(jobKey);
		redisJobInstanceDao.getJobInstance(jobName, jobParameters);

		RedisJobInstance redisJobInstance = new RedisJobInstance();
		redisJobInstance.setJobName(jobName);
		redisJobInstance.setJobInstanceId(1L);
		redisJobInstance.setJobKey(jobKey);
		redisJobInstance.incrementVersion();

		RedisJobInstance redisJobInstance2 = new RedisJobInstance();
		redisJobInstance2.setJobName("ABC");
		redisJobInstance2.setJobInstanceId(2L);
		redisJobInstance2.setJobKey("sddd");
		redisJobInstance2.incrementVersion();

		RedisJobInstance redisJobInstance3 = new RedisJobInstance();
		redisJobInstance3.setJobName(jobName);
		redisJobInstance3.setJobInstanceId(3L);
		redisJobInstance3.setJobKey("sddd");
		redisJobInstance3.incrementVersion();

		RedisJobInstance redisJobInstance4 = new RedisJobInstance();
		redisJobInstance4.setJobName("ABC");
		redisJobInstance4.setJobInstanceId(4L);
		redisJobInstance4.setJobKey(jobKey);
		redisJobInstance4.incrementVersion();

		redisJobInstances.add(redisJobInstance);
		redisJobInstances.add(redisJobInstance2);
		redisJobInstances.add(redisJobInstance3);
		redisJobInstances.add(redisJobInstance4);
		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(redisJobInstances);
		redisJobInstanceDao.getJobInstance(jobName, jobParameters);

		JobParameters params = new JobParametersBuilder().toJobParameters();
		jobKey = jobKeyGenerator.generateKey(params);
		redisJobInstance.setJobKey(null);
		when(jobKeyGenerator.generateKey(params)).thenReturn("");
		redisJobInstanceDao.getJobInstance(jobName, params);

		redisJobInstance.setJobKey("");
		redisJobInstanceDao.getJobInstance(jobName, params);
	}

	@Test
	public void testGetJobInstanceById() {
		Long instanceId = 123L;
		Set<RedisJobInstance> setjobInstances = new HashSet<>();

		redisJobInstanceDao.getJobInstance(instanceId);

		RedisJobInstance redisJobInstance = new RedisJobInstance();
		redisJobInstance.setJobName("jobName");
		redisJobInstance.setJobInstanceId(123L);
		redisJobInstance.incrementVersion();
		setjobInstances.add(redisJobInstance);

		when(opsJobInstanceSortedSet.rangeByScore(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY),
				instanceId, instanceId)).thenReturn(setjobInstances);

		redisJobInstanceDao.getJobInstance(instanceId);
	}

	@Test
	public void testGetJobInstancebyJobExecution() {
		JobInstance jobInstance = new JobInstance(123L, "JobName");
		JobExecution jobExecution = new JobExecution(1L);
		jobExecution.setStatus(BatchStatus.STARTED);
		jobExecution.setCreateTime(new Date());
		jobExecution.setExitStatus(ExitStatus.EXECUTING);
		jobExecution.setJobInstance(jobInstance);
		jobExecution.incrementVersion();

		JobExecution jobExecution1 = new JobExecution(2L);
		jobExecution1.setStatus(BatchStatus.STARTED);
		jobExecution1.setCreateTime(new Date());
		jobExecution1.setExitStatus(ExitStatus.EXECUTING);
		jobExecution1.setJobInstance(jobInstance);
		jobExecution1.incrementVersion();

		redisJobInstanceDao.getJobInstance(jobExecution);

		Set<RedisJobInstance> redisJobInstances = new HashSet<>();
		Set<RedisJobExecution> redisJobExecutions = new HashSet<>();

		RedisJobInstance redisJobInstance = new RedisJobInstance();
		redisJobInstance.setJobName("jobName");
		redisJobInstance.setJobInstanceId(123L);
		redisJobInstance.incrementVersion();
		redisJobInstances.add(redisJobInstance);

		
		 * RedisJobInstance redisJobInstance = new RedisJobInstance();
		 * redisJobInstance.setJobName("jobName");
		 * redisJobInstance.setJobInstanceId(123L);
		 * redisJobInstance.incrementVersion();
		 * redisJobInstances.add(redisJobInstance);
		 

		RedisJobExecution rje1 = new RedisJobExecution(jobExecution);
		RedisJobExecution rje2 = new RedisJobExecution(jobExecution1);
		redisJobExecutions.add(rje1);
		redisJobExecutions.add(rje2);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(Collections.emptySet());

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(Collections.emptySet());

		redisJobInstanceDao.getJobInstance(jobExecution);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(redisJobInstances);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(redisJobExecutions);

		redisJobInstanceDao.getJobInstance(jobExecution);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(Collections.emptySet());

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(redisJobExecutions);

		redisJobInstanceDao.getJobInstance(jobExecution);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(redisJobInstances);

		when(opsJobExecutionSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_EXECUTION_SET_KEY),
				0, -1)).thenReturn(Collections.emptySet());

		redisJobInstanceDao.getJobInstance(jobExecution);

		
		 * 
		 * redisJobInstanceDao.getJobInstance(jobExecution);
		 * 
		 * 
		 * 
		 * redisJobInstanceDao.getJobInstance(jobExecution);
		 * 
		 * when(opsJobInstanceSortedSet.range(
		 * ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(),
		 * AppConstants.JOB_INSTANCE_SET_KEY), 0,
		 * -1)).thenReturn(Collections.emptySet());
		 * 
		 * when(opsJobExecutionSortedSet.range(
		 * ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(),
		 * AppConstants.JOB_EXECUTION_SET_KEY), 0,
		 * -1)).thenReturn(Collections.emptySet());
		 * 
		 * redisJobInstanceDao.getJobInstance(jobExecution);
		 

	}

	@Test
	public void testGetJobInstances() {
		String jobName = "jobName";
		redisJobInstanceDao.getJobInstances(jobName, 0, 10);

		Set<RedisJobInstance> redisJobInstances = new HashSet<>();

		RedisJobInstance redisJobInstance = new RedisJobInstance();
		redisJobInstance.setJobName("jobName");
		redisJobInstance.setJobInstanceId(123L);
		redisJobInstance.incrementVersion();
		redisJobInstances.add(redisJobInstance);

		RedisJobInstance redisJobInstance2 = new RedisJobInstance();
		redisJobInstance2.setJobName("jobName2");
		redisJobInstance2.setJobInstanceId(1232L);
		redisJobInstance2.incrementVersion();
		redisJobInstances.add(redisJobInstance2);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(redisJobInstances);

		redisJobInstanceDao.getJobInstances(jobName, 0, 10);
	}

	@Test
	public void testGetJobNames() {
		redisJobInstanceDao.getJobNames();

		Set<String> setJobNames = new HashSet<>();
		setJobNames.add("jobName");

		when(opsJobInstanceString.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_STRING_KEY),
				0, -1)).thenReturn(setJobNames);
		redisJobInstanceDao.getJobNames();
	}

	@Test
	public void testFindJobInstancesByName() {
		String jobName = "jobName";
		redisJobInstanceDao.findJobInstancesByName(jobName, 0, 10);

		Set<RedisJobInstance> redisJobInstances = new HashSet<>();

		RedisJobInstance redisJobInstance = new RedisJobInstance();
		redisJobInstance.setJobName("jobName");
		redisJobInstance.setJobInstanceId(123L);
		redisJobInstance.incrementVersion();
		redisJobInstances.add(redisJobInstance);

		RedisJobInstance redisJobInstance2 = new RedisJobInstance();
		redisJobInstance2.setJobName("import");
		redisJobInstance2.setJobInstanceId(1232L);
		redisJobInstance2.incrementVersion();
		redisJobInstances.add(redisJobInstance2);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(redisJobInstances);

		redisJobInstanceDao.findJobInstancesByName(jobName, 0, 10);
	}

	@Test
	public void testGetJobInstanceCount() throws NoSuchJobException {
		String jobName = "jobName";

		redisJobInstanceDao.getJobInstanceCount(jobName);
		Set<RedisJobInstance> redisJobInstances = new HashSet<>();

		RedisJobInstance redisJobInstance = new RedisJobInstance();
		redisJobInstance.setJobName("jobName");
		redisJobInstance.setJobInstanceId(123L);
		redisJobInstance.incrementVersion();
		redisJobInstances.add(redisJobInstance);

		when(opsJobInstanceSortedSet.range(
				ZipToDestBatchUtil.getRedisKey(redisJobInstanceDao.getKeySpace(), AppConstants.JOB_INSTANCE_SET_KEY), 0,
				-1)).thenReturn(redisJobInstances);

		redisJobInstanceDao.getJobInstanceCount(jobName);

	}
}
*/