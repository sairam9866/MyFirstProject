package com.fedex.ziptodest.batch.model.mappers;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.model.mappers.CountryCodeRowMapper;
import com.fedex.ziptodest.model.CountryCode;

@RunWith(SpringRunner.class)
public class CountryCodeRowMapperTest {
	
	CountryCodeRowMapper countryCodeRowMapper;

	@Mock
	ResultSet resultSet;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testCountryCodeRowMapper() throws SQLException{		
		countryCodeRowMapper = new CountryCodeRowMapper();
		when(resultSet.getInt("CYCLCU")).thenReturn(840);
		when(resultSet.getString("CYCODE")).thenReturn("CA");
		CountryCode countryCode = countryCodeRowMapper.mapRow(resultSet, 1);
		assertEquals(Integer.valueOf(840), countryCode.getCyclcu());
		assertEquals("CA", countryCode.getCycode());
	}
}
