/*package com.fedex.ziptodest.batch.service.impl;

import static org.junit.Assert.assertEquals;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.batch.service.FacilityIdService;
import com.fedex.ziptodest.batch.service.ZipToDestTransactionService;
import com.fedex.ziptodest.batch.service.ZipToDestinationService;
import com.fedex.ziptodest.batch.service.impl.WriteProcessImpl;
import com.fedex.ziptodest.batch.util.ZipToDestBatchUtil;
import com.fedex.ziptodest.model.ZipToDest;

@RunWith(SpringRunner.class)
public class WriteProcessImplTest {
	
	@InjectMocks
	private WriteProcessImpl writeProcess;	

	@Mock
	FacilityIdService facilityIdService;

	@Mock
	ZipToDestinationService zipToDestinationService;

	@Mock
	private ZipToDestTransactionService zipToDestTransactionService;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
	}	
	
	@Test
	public void testExecuteWriteModifyProcess(){
		int commitCount;
		List<ZipToDest> unprocessed = new ArrayList<>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(840);
		zipToDest.setCancelledFlag("N");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Test");
		zipToDest.setCurrent("N");
		zipToDest.setDestinationTerminal("11");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setProcessed("N");
		zipToDest.setNetwork("FHDL");
		zipToDest.setState("WA");
		zipToDest.setTransactionType("M");
		zipToDest.setUuid("asdsadsd-asdsad--adsa");
		zipToDest.setZipCode("50450000000");
		
		ZipToDest zipToDestCa = new ZipToDest();
		zipToDestCa.setCountryCode(840);
		zipToDestCa.setCancelledFlag("N");
		zipToDestCa.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestCa.setCreationUser("Test");
		zipToDestCa.setCurrent("N");
		zipToDestCa.setDestinationTerminal("11");
		zipToDestCa.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestCa.setProcessed("N");
		zipToDestCa.setNetwork("FHDL");
		zipToDestCa.setState("WA");
		zipToDestCa.setTransactionType("M");
		zipToDestCa.setUuid("asdsadsd-asdsad--adsa");
		zipToDestCa.setZipCode("A0A0A0");
		
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		jobExecution.getExecutionContext().put(ZipToDestBatchUtil.KEY_UNPROCESSED_MODIFIED, unprocessed);
		
		commitCount = writeProcess.executeWriteProcess(jobExecution.getExecutionContext(), 
				ZipToDestBatchUtil.TRANSACTION_TYPE_MODIFY, ZipToDestBatchUtil.KEY_UNPROCESSED_MODIFIED);
		assertEquals(0, commitCount);
		
		unprocessed.add(zipToDest);
		unprocessed.add(zipToDestCa);
		jobExecution.getExecutionContext().putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, 1);
		
		
		commitCount = writeProcess.executeWriteProcess(jobExecution.getExecutionContext(), 
				ZipToDestBatchUtil.TRANSACTION_TYPE_MODIFY, ZipToDestBatchUtil.KEY_UNPROCESSED_MODIFIED);
		assertEquals(2, commitCount);
		
	}
	
	@Test
	public void testExecuteWriteDeleteProcess(){
		int commitCount;
		List<ZipToDest> unprocessed = new ArrayList<>();
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCountryCode(840);
		zipToDest.setCancelledFlag("N");
		zipToDest.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setCreationUser("Test");
		zipToDest.setCurrent("N");
		zipToDest.setDestinationTerminal("11");
		zipToDest.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDest.setProcessed("N");
		zipToDest.setNetwork("FHDL");
		zipToDest.setState("WA");
		zipToDest.setTransactionType("D");
		zipToDest.setUuid("asdsadsd-asdsad--adsa");
		zipToDest.setZipCode("50450000000");
		
		ZipToDest zipToDestCa = new ZipToDest();
		zipToDestCa.setCountryCode(840);
		zipToDestCa.setCancelledFlag("N");
		zipToDestCa.setCreatedDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestCa.setCreationUser("Test");
		zipToDestCa.setCurrent("N");
		zipToDestCa.setDestinationTerminal("11");
		zipToDestCa.setEffectiveDateAt(ZonedDateTime.now(ZoneOffset.UTC).toEpochSecond());
		zipToDestCa.setProcessed("N");
		zipToDestCa.setNetwork("FHDL");
		zipToDestCa.setState("WA");
		zipToDestCa.setTransactionType("D");
		zipToDestCa.setUuid("asdsadsd-asdsad--adsa");
		zipToDestCa.setZipCode("A0A0A0");
		
		JobExecution jobExecution = new JobExecution(1l); 
		jobExecution.setCreateTime(new Date());
		jobExecution.setEndTime(new Date());
		jobExecution.setExitStatus(ExitStatus.COMPLETED);
		jobExecution.setLastUpdated(new Date());
		jobExecution.setStartTime(new Date());
		jobExecution.setStatus(BatchStatus.COMPLETED);
		jobExecution.getExecutionContext().put(ZipToDestBatchUtil.KEY_UNPROCESSED_DELETED, unprocessed);
		
		unprocessed.add(zipToDest);
		unprocessed.add(zipToDestCa);
		jobExecution.getExecutionContext().putInt(ZipToDestBatchUtil.KEY_EXECUTION_COUNT, 1);
		
		commitCount = writeProcess.executeWriteProcess(jobExecution.getExecutionContext(), 
				ZipToDestBatchUtil.TRANSACTION_TYPE_DELETE, ZipToDestBatchUtil.KEY_UNPROCESSED_DELETED);
		
		assertEquals(2, commitCount);
		
	}
}
*/