package com.fedex.ziptodest.util;

import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public final class ZipToDestConstants {

	public static final String APP_HASH_KEY = "ZDTRANSACTIONS";
	public static final String APP_TRANSACTION_TMSTMP_KEY = "ZDTRANSACTIONS_TMSTMP";
	public static final String APP_TRANSACTION_ZIP_KEY = "TRANSACTIONS_ZIPCODES";
	public static final double ZIP_CODE_DEFAULT_SCORE = 1d;
	//public static final String APP_TRANSACTION_ZIP_CA_KEY = "TRANSACTION_CA";

	public static final String APP_DATE_FORMAT = "yyyy-MM-dd.HH:mm:ss";

	public static final String FLAG_YES = "Y";
	public static final String FLAG_NO = "N";

	public static final String TRANS_TYPE_ADD = "A";
	public static final String TRANS_TYPE_MODIFY = "M";
	public static final String TRANS_TYPE_DELETE = "D";

	public static final String UTC_TIME_ZONE = "UTC";
	
	//Facility
	public static final String FACILITY_HASH_KEY = "FACILITYDELTA";
	public static final String ZIP_TO_DEST_HAS_DELTA_HASH_KEY = "ZIPTODESTHASDELTA";
	
	public static final String ZIP_TO_DEST_NETWORKS = "ZIPTODESTNETWORKS";
	public static final String ZIP_TO_DEST = "ZIPTODEST";
	

	// US Zipcode Pattern
	public static final Pattern PATTERN_US_ZIP_CODE = Pattern.compile("[0-9]{5,5}");
	public static final Pattern PATTERN_CANADA_ZIP_CODE3 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z]$");
	public static final Pattern PATTERN_CANADA_ZIP_CODE6 = Pattern.compile("[a-zA-Z][\\d][a-zA-Z][\\d][a-zA-Z][\\d]$");
	
	
	public static final String APP_TRANSACTION_ZIP_US_KEY = "TRANSACTION_US";
	public static final String APP_TRANSACTION_ZIP_CA_KEY = "TRANSACTION_CA";
	public static final String APP_TRANSACTION_PROCESS_TMSTAMP_KEY = "PROCESS_TMSTMP";
	public static final String APP_TRANSACTION_CANCELLED_TMSTAMP_KEY = "CANCELLED_TMSTMP";
	
	public static final String APP_TRANSACTION_CREATION_TMSTAMP_KEY = "CREATION_TMSTMP";
	public static final String APP_TRANSACTION_SAVE_PROCESS_TMSTAMP_KEY = "SAVE_PROCESS_TMSTMP";
	public static final String APP_TRANSACTION_SAVE_CANCELLED_TMSTAMP_KEY = "SAVE_CANCELLED_TMSTMP";
	public static final String APP_TRANSACTION_SAVE_CREATION_TMSTAMP_KEY = "SAVE_CREATION_TMSTMP";
	
	
	public static final double ZIP_CODE_CANCELLED_DEFAULT_SCORE = 3d;
	public static final double ZIP_CODE_CREATION_DEFAULT_SCORE = 4d;

	public static final String TRANS_TYPE_CANCEL = "C";

	public static final DateTimeFormatter ZIP_TO_DEST_DATE_TIME_FORMATTER = DateTimeFormatter
			.ofPattern(APP_DATE_FORMAT);

}
