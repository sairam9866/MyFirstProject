package com.fedex.ziptodest.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.dao.HashSetDao;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.service.ZipToDestService;
import com.fedex.ziptodest.util.ZdTimer;

@RestController
@RequestMapping("/ziptodest")
public class ZipToDestController {
	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestController.class);
	@Autowired
	ZipToDestService zipToDestService;

	@Autowired
	HashSetDao hashSetDao;
	


	@PostMapping("/saveZiptoDestTransactionalToRedis")
	public String saveAllZipToDestTransactionalRecordsToRedis() {
		return zipToDestService.saveDataToRedis();
	}

	@DeleteMapping("/deleteAll")
	public String deleteAllZipToDestTransactionalRecordsToRedis() {
		return zipToDestService.deleteDataFromRedis();
	}
	@DeleteMapping("/deleteAllLocalRecords")
	public String deleteAllZipToDestTransactionalRecordsToRedisLocal() {
		ZdTimer timer = ZdTimer.start();
		LOGGER.info("Time Taken to delete records from Redis : {}ms", timer.stop());
		return zipToDestService.deleteDataFromRedisLocal();
	}
	@GetMapping("/findByNetworkAndCountryCode")
	public List<ZipToDest> findByNetworkAndCountryCode(@RequestParam String network, @RequestParam String countryCode) {
		ZdTimer timer = ZdTimer.start();
		
		List<ZipToDest> result = hashSetDao.getZipToDestfromRedis(network, countryCode);
		
		LOGGER.info("Time Taken for /findByNetwork : {}ms", timer.stop());
		return result;
	}
	
}
