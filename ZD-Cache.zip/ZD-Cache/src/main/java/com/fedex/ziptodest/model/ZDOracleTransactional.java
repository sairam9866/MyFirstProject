package com.fedex.ziptodest.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "TRX_ZIP_TO_DEST")
public class ZDOracleTransactional  implements Serializable{

	private static final long serialVersionUID = 1234567897847L;

	
	@EmbeddedId
	private ZDOracleTransactionalPK zdOracleTransactionalPK;
	

//	@Column(name = "NETWORK")
//	private String network;

	@Column(name = "COUNTRY_CD")
	private Integer countryCode;

//	@Column(name = "ZIP_CD")
//	private String zipCode;

//	@Column(name = "DEST_TERMINAL")
//	private String destinationTerminal;

	@Column(name = "STATE")
	private String state;

	@Column(name = "CURRENT_FLG")
	private String current;

	@Column(name = "CREATION_USER")
	private String createdBy;

	@Column(name = "TRANS_TYPE")
	private String transactionType;

	@Column(name = "PROCESSED_FLG")
	private String processed;

	@Column(name = "CANCELLED_FLG")
	private String cancelled;

	@Column(name = "UUID")
	private String uuid;

	@Column(name = "CANCELLED_USER")
	private String cancelledBy;

	@Column(name = "EFFECTIVE_DATE_TMSTP")
	private Timestamp effectiveDateTime;

//	 @Column(name = "CREATED_DT")
//	 private Long createdDateTime;

	@Column(name = "PROCESSED_DATE_TMSTP")
	private Timestamp processedDateTime;

	@Column(name = "CANCELLED_DATE_TMSTP")
	private Timestamp cancelledDateTime;

	

//	public String getNetwork() {
//		return network;
//	}
//
//	public void setNetwork(String network) {
//		this.network = network;
//	}

	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}

//	public String getZipCode() {
//		return zipCode;
//	}
//
//	public void setZipCode(String zipCode) {
//		this.zipCode = zipCode;
//	}

//	public String getDestinationTerminal() {
//		return destinationTerminal;
//	}
//
//	public void setDestinationTerminal(String destinationTerminal) {
//		this.destinationTerminal = destinationTerminal;
//	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCurrent() {
		return current;
	}

	public void setCurrent(String current) {
		this.current = current;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getProcessed() {
		return processed;
	}

	public void setProcessed(String processed) {
		this.processed = processed;
	}

	public String getCancelled() {
		return cancelled;
	}

	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCancelledBy() {
		return cancelledBy;
	}

	public void setCancelledBy(String cancelledBy) {
		this.cancelledBy = cancelledBy;
	}

	public Timestamp getEffectiveDateTime() {
		return effectiveDateTime;
	}

	public void setEffectiveDateTime(Timestamp effectiveDateTime) {
		this.effectiveDateTime = effectiveDateTime;
	}

	// public Long getCreatedDateTime() {
	// return createdDateTime;
	// }
	//
	// public void setCreatedDateTime(Long createdDateTime) {
	// this.createdDateTime = createdDateTime;
	// }

	public Timestamp getProcessedDateTime() {
		return processedDateTime;
	}

	public void setProcessedDateTime(Timestamp processedDateTime) {
		this.processedDateTime = processedDateTime;
	}

	public Timestamp getCancelledDateTime() {
		return cancelledDateTime;
	}

	public void setCancelledDateTime(Timestamp cancelledDateTime) {
		this.cancelledDateTime = cancelledDateTime;
	}

	public ZDOracleTransactionalPK getZdOracleTransactionalPK() {
		return zdOracleTransactionalPK;
	}

	public void setZdOracleTransactionalPK(ZDOracleTransactionalPK zdOracleTransactionalPK) {
		this.zdOracleTransactionalPK = zdOracleTransactionalPK;
	}
	
	

}
