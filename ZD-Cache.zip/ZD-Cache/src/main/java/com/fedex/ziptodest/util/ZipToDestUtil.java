package com.fedex.ziptodest.util;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Component;
import com.fasterxml.uuid.Generators;
import com.fedex.ziptodest.dao.HashSetDao;
import com.fedex.ziptodest.model.ZDOracleTransactional;
import com.fedex.ziptodest.model.ZipToDest;


@Component
public final class ZipToDestUtil {

	private final DateTimeFormatter ZIP_TO_DEST_DATE_TIME_FORMATTER = DateTimeFormatter
			.ofPattern(AppConstants.EFFECTIVE_DATE_FORMAT);
	
	private final String CANCELLED_FLAG = "cancelled_Flag";

	@Value(value = "${keyspace}")
	private String keyspace;

	public String getKeySpace() {
		return keyspace;
	}

	public ZipToDest getCurrentTransaction(String zip) {
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCancelledFlag("N");
		zipToDest.setCancelledTimestamp(null);
		zipToDest.setCancelledUser(null);
		zipToDest.setCountryCode(124);
		zipToDest.setCreatedDateAt(System.currentTimeMillis() / 1000);
		zipToDest.setCreationUser("TEST");
		zipToDest.setCurrent("Y");
		zipToDest.setDestinationTerminal("11");
		zipToDest.setEffectiveDateAt(System.currentTimeMillis() / 1000);
		zipToDest.setNetwork("FXG");
		zipToDest.setProcessed("Y");
		zipToDest.setProcessedDateTime(System.currentTimeMillis() / 1000);
		zipToDest.setState("WA");
		zipToDest.setTransactionType("A");
		zipToDest.setZipCode(zip);
		return zipToDest;
	}
	
	


	public String hashMasterKey(String key) {
		return (("{" + getKeySpace() + "-" + key + "}").toUpperCase());
	}
	
	public String hashDistMasterKey(String key) {
		return (("{" + getKeySpace() + "-" + key + "}").toUpperCase());
	}

	public String zipToDestHashKey(ZipToDest zipToDest) {
		String key = keyspace.toUpperCase() + ":" + zipToDest.getNetwork() + ":" + zipToDest.getCountryCode() + ":" + zipToDest.getDestinationTerminal() + ":" + zipToDest.getZipCode()
				+  ":"	+ zipToDest.getCreatedDateAt();
		return key;
	}

	public String zipToDestID(ZipToDest zipToDest) {
		String key = zipToDest.getNetwork() + ":" + zipToDest.getCountryCode() + ":" + zipToDest.getDestinationTerminal() + ":" + zipToDest.getZipCode()
				+  ":"	+ zipToDest.getCreatedDateAt();
		return key;
	}
	 public static String getProcessedByNetworkAndZipCodeKey(String keyspace, String network, String zipCode) {
	        return (getProcessedKey(keyspace) + ":" + network + ":" + zipCode).toUpperCase();
	    }
	    public static String getProcessedKey(String keySpace) {
	        return (keySpace + ":" + "PROCESSED_RECORDS").toUpperCase();
	    }

	public Long getUtcEpochTimes(String dateTime, String timeZone) {
		Long result = null;
		try {
			LocalDateTime localDateTime = LocalDateTime.parse(dateTime, instanceOfAppDateTimeFormatter());
			int post = timeZone.trim().indexOf(')');
			String fromTimeZone = timeZone.substring(++post).trim();
			ZonedDateTime fromDateTimeZone = localDateTime.atZone(ZoneId.of(fromTimeZone));
			result = fromDateTimeZone.withZoneSameInstant(ZoneOffset.UTC).toEpochSecond();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public DateTimeFormatter instanceOfAppDateTimeFormatter() {
		return ZIP_TO_DEST_DATE_TIME_FORMATTER;
	}
	
	

	public List<ZipToDest> mapToZipToDest(List<Map<String,String>> maps) {
		List<ZipToDest> output = new ArrayList() ;
		for(Map<String,String> map: maps){
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setCancelledFlag(map.get(CANCELLED_FLAG));
		zipToDest.setCancelledTimestamp(Long.parseLong(map.get("cancelled_timestamp")));
		zipToDest.setCancelledUser(null);
		zipToDest.setCountryCode(124);
		zipToDest.setCreatedDateAt(System.currentTimeMillis() / 1000);
		zipToDest.setCreationUser("TEST");
		zipToDest.setCurrent("Y");
		zipToDest.setDestinationTerminal("11");
		zipToDest.setEffectiveDateAt(System.currentTimeMillis() / 1000);
		zipToDest.setNetwork("FXG");
		zipToDest.setProcessed("Y");
		zipToDest.setProcessedDateTime(System.currentTimeMillis() / 1000);
		zipToDest.setState("WA");
		zipToDest.setTransactionType("A");
		zipToDest.setZipCode(map.get("zipCode"));
		output.add(zipToDest);
		}
		return output;
	}
	
	public ZipToDest fromZipToDestDataToRedis(ZDOracleTransactional zipToDestData) {
		ZipToDest zipToDest = new ZipToDest();
		zipToDest.setNetwork(zipToDestData.getZdOracleTransactionalPK().getNetwork());
		zipToDest.setCountryCode(zipToDestData.getCountryCode());
		zipToDest.setState(zipToDestData.getState());
		zipToDest.setZipCode(zipToDestData.getZdOracleTransactionalPK().getZipCode());
		zipToDest.setDestinationTerminal(zipToDestData.getZdOracleTransactionalPK().getDestinationTerminal());
		zipToDest.setCreationUser(zipToDestData.getCreatedBy());
		zipToDest.setUuid(generateUuid());
		zipToDest.setEffectiveDateAt(zipToDestData.getEffectiveDateTime().getTime() / 1000);
		zipToDest.setCreatedDateAt(
				zipToDestData.getZdOracleTransactionalPK().getCreationDateTimestamp().getTime() / 1000);
		if (zipToDestData.getProcessedDateTime() != null) {
			zipToDest.setProcessedDateTime(zipToDestData.getProcessedDateTime().getTime() / 1000);
		} else {
			zipToDest.setProcessedDateTime(
					zipToDestData.getZdOracleTransactionalPK().getCreationDateTimestamp().getTime() / 1000);
		}
		zipToDest.setCurrent(zipToDestData.getCurrent());
		zipToDest.setProcessed(zipToDestData.getProcessed());
		zipToDest.setCancelledFlag(zipToDestData.getCancelled());
		zipToDest.setTransactionType(zipToDestData.getTransactionType());
		if (zipToDestData.getCancelledBy() != null) {
			zipToDest.setCancelledUser(zipToDestData.getCancelledBy());
		} else {
			zipToDest.setCancelledUser(" ");
		}
		if (zipToDestData.getCancelledDateTime() != null) {
			zipToDest.setCancelledTimestamp(zipToDestData.getCancelledDateTime().getTime() / 1000);
		}
		return zipToDest;
	}
	public String generateUuid() {
		return Generators.timeBasedGenerator().generate().toString();
	}
	
	public String getRedisKey(String prefix, String key) {
        return (prefix + ":" + key).toUpperCase();
    }
	
	public String getCurrentByProcessedDate(String keyspace,String network, int countryCode, String processedat){
		return(keyspace+":CURRENT_RECORDS:"+network+":"+countryCode+":"+processedat).toUpperCase();
	}
	
	public String getHasDeltaLastProcessed(String keyspace,String network, String processedat){
		return(keyspace+":FACILITYHASDELTA:"+network+":"+processedat).toUpperCase();
	}

}
