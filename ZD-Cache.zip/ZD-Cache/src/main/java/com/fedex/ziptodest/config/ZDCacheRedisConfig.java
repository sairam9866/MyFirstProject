package com.fedex.ziptodest.config;

import java.io.Closeable;
import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.convert.MappingConfiguration;
import org.springframework.data.redis.core.index.IndexConfiguration;
import org.springframework.data.redis.core.mapping.RedisMappingContext;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import redis.embedded.RedisServer;
import redis.embedded.RedisServerBuilder;

@Configuration
@EnableRedisRepositories
@Profile("lcl")
public class ZDCacheRedisConfig implements Closeable{
	public static final Logger LOGGER = LoggerFactory.getLogger(ZDCacheRedisConfig.class);

	private RedisServer redisServer;
	
	@Value(value = "${keyspace}")
	private String keyspace;
	
	@Bean
	JedisConnectionFactory jedisConnectionFactory(){
		JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
		jedisConnectionFactory.setHostName("localhost");
		jedisConnectionFactory.setPort(6378);
		return jedisConnectionFactory;
	}
	
	@Bean
	RedisTemplate<?, ?> redisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
    	redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
    	redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}
	@Bean(name = "strRedisTemplate")
	RedisTemplate<?, ?> strRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		redisTemplate.setKeySerializer(new StringRedisSerializer());

		//redisTemplate.setHashKeySerializer(new GenericToStringSerializer<Object>(Object.class));
		//redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
		//redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
		
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());		
		redisTemplate.setHashValueSerializer(new StringRedisSerializer());
		redisTemplate.setValueSerializer(new StringRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}
	
//	@Bean(name = "jsonRedisTemplate")
//	RedisTemplate<?, ?> jsonRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
//		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
//		redisTemplate.setConnectionFactory(redisConnectionFactory);
//		redisTemplate.setKeySerializer(new StringRedisSerializer());
//
//		//redisTemplate.setHashKeySerializer(new GenericToStringSerializer<Object>(Object.class));
//		//redisTemplate.setHashValueSerializer(new JdkSerializationRedisSerializer());
//		//redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
//		
//		redisTemplate.setHashKeySerializer(new StringRedisSerializer());		
//		redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
//		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
//		redisTemplate.afterPropertiesSet();
//		return redisTemplate;
//	}
	

	@Bean
	ZDKeyspaceConfiguration bookKeySpaceConfig(){
		LOGGER.info("Setting keyspace to BookKeySpaceConfig : {}", keyspace);
		return new ZDKeyspaceConfiguration(keyspace);
	}

	
	@PostConstruct
	public void init() {
		redisServer = new RedisServerBuilder().port(6378).setting("maxmemory 256M").build();
		redisServer.start();
	}

	@PreDestroy
	public void destroy() {
		LOGGER.info("Redis server Shutdown initiated destroy: {}", "...");
		redisServer.stop();
	}

	@Bean
	public RedisMappingContext keyValueMappingContext(ZDKeyspaceConfiguration keyspaceConfiguration){
		
		return new RedisMappingContext(
				new MappingConfiguration(new IndexConfiguration(), keyspaceConfiguration));
	}

	@Override
	public void close() throws IOException {
		LOGGER.info("Redis server Shutdown initiated close: {}", "...");
		redisServer.stop();
		
	}
	
}
