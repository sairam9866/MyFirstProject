package com.fedex.ziptodest.dao;

import org.springframework.beans.factory.annotation.Value;

public abstract class ZipToDestKeySpace {

	
}
