package com.fedex.ziptodest.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.model.ZipToDest;

import com.fedex.ziptodest.util.AppConstants;

@Component
public final class ZipToDestMapper {
	
	@Autowired
	ZipToDestUtil zipToDestUtil;
	
	//while returning back to front end
	public ZipToDest toObj(Map<String, String> map){
		ZipToDest ziptodest =  new ZipToDest();
		ziptodest.setCancelledFlag(map.get(AppConstants.CANCELLED_FLAG));
		ziptodest.setCancelledTimestamp((StringUtils.isBlank(map.get(AppConstants.CANCELLED_TIMESTAMP)) ? 1L : Long.valueOf(map.get(AppConstants.CANCELLED_TIMESTAMP))));
		ziptodest.setCancelledUser(map.get(AppConstants.CANCELLED_USER));
		ziptodest.setCountryCode(Integer.parseInt(StringUtils.isEmpty(map.get(AppConstants.COUNTRY_CODE)) ? "0" : map.get(AppConstants.COUNTRY_CODE)));
		ziptodest.setCreatedDateAt(StringUtils.isBlank(map.get(AppConstants.CREATION_AT)) ? 1L : Long.valueOf(map.get(AppConstants.CREATION_AT )));
		ziptodest.setCreationUser(map.get(AppConstants.CREATION_USER));
		ziptodest.setCurrent(map.get(AppConstants.CURRENT_FLAG));
		ziptodest.setDestinationTerminal(map.get(AppConstants.DESTINATION_TERMINAL));
		ziptodest.setEffectiveDateAt(StringUtils.isBlank(map.get(AppConstants.EFFECTIVE_DATE_AT)) ? 1L : Long.valueOf(map.get(AppConstants.EFFECTIVE_DATE_AT)));
		ziptodest.setNetwork(map.get(AppConstants.NETWORK));
		ziptodest.setProcessed(AppConstants.PROCESSED_FLAG);
		ziptodest.setProcessedDateTime(StringUtils.isBlank(map.get(AppConstants.PROCESSED_AT)) ? 1L : Long.valueOf(map.get(AppConstants.PROCESSED_AT)));
		ziptodest.setState(map.get(AppConstants.STATE));
		ziptodest.setTransactionType(map.get(AppConstants.TRANSACTION_TYPE));
		ziptodest.setUuid(map.get(AppConstants.UUID));
		ziptodest.setZipCode(map.get(AppConstants.ZIP_CODE));
		ziptodest.setTimeZone(AppConstants.TIME_ZONE);
		return ziptodest;
			
	}
	
	//before saving to DB
	public Map<String,String> toMap (ZipToDest ziptodest){
		Map<String,String> map = new HashMap();
		map.put(AppConstants.ID, zipToDestUtil.zipToDestID(ziptodest));
		map.put(AppConstants.CANCELLED_DT, ziptodest.getCancelledAt() == null? "": ziptodest.getCancelledAt());
		map.put(AppConstants.CANCELLED_FLAG, ziptodest.getCancelledFlag() == null ? "N" : ziptodest.getCancelledFlag() );
		map.put(AppConstants.CANCELLED_TIMESTAMP, ziptodest.getCancelledAt() == null ? "" : ziptodest.getCancelledAt() );
		map.put(AppConstants.CANCELLED_USER, ziptodest.getCancelledUser() == null ? "" : ziptodest.getCancelledUser());
		map.put(AppConstants.COUNTRY_CODE, String.valueOf((ziptodest.getCountryCode() == 0 ? "NA" : ziptodest.getCountryCode())));
		map.put(AppConstants.CREATION_DT, ziptodest.getcreationDate() == null ? "": ziptodest.getcreationDate());
		map.put(AppConstants.CREATION_AT, String.valueOf(ziptodest.getCreatedDateAt() == null? "": ziptodest.getCreatedDateAt()));
		map.put(AppConstants.CREATION_USER, ziptodest.getCreationUser() == null ? "": ziptodest.getCreationUser());
		map.put(AppConstants.CURRENT_FLAG, ziptodest.getCurrent() == null ? "" : ziptodest.getCurrent());
		map.put(AppConstants.DESTINATION_TERMINAL, ziptodest.getDestinationTerminal() == null ? "NA" :String.valueOf(Integer.parseInt(ziptodest.getDestinationTerminal())));
		
		map.put(AppConstants.EFFECTIVE_DATE_AT, String.valueOf(ziptodest.getEffectiveDateAt() == null ? "": ziptodest.getEffectiveDateAt()));
		map.put(AppConstants.EFFECTIVE_DT, String.valueOf(ziptodest.getEffectiveDate() == null ? "" : ziptodest.getEffectiveDate()));
		
		map.put(AppConstants.NETWORK, ziptodest.getNetwork() == null ? "NA" : ziptodest.getNetwork());
		map.put(AppConstants.PROCESSED_DT, ziptodest.getProcessedAt() == null ? "" : ziptodest.getProcessedAt());
		map.put(AppConstants.PROCESSED_AT, String.valueOf(ziptodest.getProcessedDateTime() == null ? Long.MIN_VALUE : ziptodest.getProcessedDateTime()));
		map.put(AppConstants.PROCESSED_FLAG, ziptodest.getProcessed() == null ? "NA" : ziptodest.getProcessed());
		map.put(AppConstants.STATE, ziptodest.getState() == null ? "NA" : ziptodest.getState());
		map.put(AppConstants.TIME_ZONE, ziptodest.getTimeZone() == null ? "NA" : ziptodest.getTimeZone());
		map.put(AppConstants.TRANSACTION_TYPE, ziptodest.getTransactionType());
		map.put(AppConstants.UUID, ziptodest.getUuid() == null ? "NA" : ziptodest.getUuid());
		map.put(AppConstants.ZIP_CODE, ziptodest.getZipCode() == null ? "NA" : ziptodest.getZipCode());
		return map;
		
		
	}

}
