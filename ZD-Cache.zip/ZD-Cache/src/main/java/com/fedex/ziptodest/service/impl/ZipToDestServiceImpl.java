package com.fedex.ziptodest.service.impl;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fedex.ziptodest.config.ZDKeyspaceConfiguration;
import com.fedex.ziptodest.dao.HashSetDao;
import com.fedex.ziptodest.model.ZDOracleTransactional;
import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.repository.ZDOracleTransactionalRepository;
import com.fedex.ziptodest.service.ZipToDestService;
import com.fedex.ziptodest.util.ZdTimer;
import com.fedex.ziptodest.util.ZipToDestUtil;

@Service
public class ZipToDestServiceImpl implements ZipToDestService {

	public static final Logger LOGGER = LoggerFactory.getLogger(ZipToDestServiceImpl.class);
	@Autowired
	ZDOracleTransactionalRepository zdOracleTransactionalRepository;
	
	@Autowired
	ZipToDestUtil zipToDestUtil;

	@Autowired
	RedisTemplate<?, ?> redisTemplate;

	@Autowired
	ZDKeyspaceConfiguration keyConfig;
	
	@Autowired
	HashSetDao hashSetDao;

	

	@Override
	public String saveDataToRedis() {
		List<ZDOracleTransactional> listOfRecords = (List<ZDOracleTransactional>) zdOracleTransactionalRepository
				.selectAll();
		LOGGER.info("Records fetched from Oracle DB  : {}", listOfRecords.size());
		List<ZipToDest> zipToDestList= new ArrayList<ZipToDest>();
		listOfRecords.stream().forEach(zipToDestData -> {

			ZipToDest zipToDest = zipToDestUtil.fromZipToDestDataToRedis(zipToDestData);
			zipToDestList.add(zipToDest);
		});
		ZdTimer timer = ZdTimer.start();
		hashSetDao.saveAll(zipToDestList);
		LOGGER.info("Time Taken to saveAll records from Redis : {}ms", timer.stop());
		return "Success";

	}



	@Override
	public String deleteDataFromRedis() {
		String key = keyConfig.getKeyspace().toUpperCase();
		String pattern =key+":"+"*";
		Set<byte[]> keySet = redisTemplate.getConnectionFactory().getConnection().keys(pattern.getBytes());
		Set<String> keysSet = new HashSet<String>();
		ZdTimer timer = ZdTimer.start();
		Iterator it = keySet.iterator();
		while (it.hasNext()) {
			String str = new String((byte[]) it.next(), StandardCharsets.UTF_8);
			keysSet.add(str);
		}
		try {

			redisTemplate.executePipelined(new SessionCallback<List<String>>() {

				@Override
				public List<String> execute(RedisOperations operations) throws DataAccessException {
					//operations.multi();

					for (String zipToDest : keysSet) {
						operations.opsForHash().getOperations().unlink(zipToDest);
						
					}

					return  null;
				}

			});

		} catch (Exception e) {
			LOGGER.error("Error while Deleting records" + e);
			return "facing issue in delete";
		}

		LOGGER.info("Time Taken to Delete records from Redis : {}ms", timer.stop());
		return "Deleted";
	}
	
	@Override
	public String deleteDataFromRedisLocal() {
		String key = keyConfig.getKeyspace().toUpperCase();
		String pattern =key+":"+"*";
		Set<byte[]> keySet = redisTemplate.getConnectionFactory().getConnection().keys(pattern.getBytes());
		Set<String> keysSet = new HashSet<String>();
		ZdTimer timer = ZdTimer.start();
		Iterator it = keySet.iterator();
		while (it.hasNext()) {
			String str = new String((byte[]) it.next(), StandardCharsets.UTF_8);
			keysSet.add(str);
		}
	

			redisTemplate.execute(new SessionCallback<List<String>>() {

				@Override
				public List<String> execute(RedisOperations operations) throws DataAccessException {
					operations.multi();

					for (String zipToDest : keysSet) {
						operations.opsForHash().getOperations().delete(zipToDest);
						
					}

					return  operations.exec();
				}

			});
			LOGGER.info("Time Taken to DeleteAll records from Redis : {}ms", timer.stop());
		
		return "Deleted";
	}

}
