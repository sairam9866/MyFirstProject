package com.fedex.ziptodest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.model.ZDOracleTransactional;


@Repository
public interface ZDOracleTransactionalRepository extends CrudRepository<ZDOracleTransactional, Long>{

	@Query("select d from ZDOracleTransactional  d order by d.effectiveDateTime asc")
	public List<ZDOracleTransactional> selectAll();
}
