package com.fedex.ziptodest.util;

public class AppConstants {

	public static final String HASH_KEY_ZIPTODEST_CURRENT = "HASH_KEY_UI_CURRENT";
	public static final String HASH_KEY_ZIPTODEST_FUTURE = "HASH_KEY_UI_FUTURE";
	public static final String HASH_KEY_ZIPTODEST_HISTORY = "HASH_KEY_UI_HISTORY";
	public static final String SORTED_SET_KEY_EFFECTIVE_DATE = "ZIP_TO_DEST_EFFECTIVE_DATE_KEY";
	
	//public static final String BATCH_PROCESS_SUCCESS_TIMESTAMP = "BATCH_PROCESS_SUCCESS_TIMESTAMP";
	
	public static final String HASH_KEY_DIST_CURRENT_NETWORK = "HASH_DIS_CURRENT_NETWORK";
	
	public static final String SORTED_SET_FACILITY_HAS_DELTA = "ZSET_HAS_DELTA";
	
	public static final String HASH_KEY_DIS_CURRENT_FACILITY = "HASH_FACILTY_DELTA";	
	
	public static final String FLAG_NO = "N";
	public static final String FLAG_YES = "Y";
	
	public static final String TRANSACTION_TYPE_ADD = "A";
	public static final String TRANSACTION_TYPE_MODIFY = "M";
	public static final String TRANSACTION_TYPE_DELETE = "D";
	
	public static final String EFFECTIVE_DATE_FORMAT = "yyyy-MM-dd.HH:mm:ss";	
	

	public static final String ID = "id";
	
	public static final String NETWORK = "network";
	public static final String LAST_UPDATE_TIMESTAMP = "lastUpdateTimestamp";

	public static final String COUNTRY_CODE = "countryCode";
	
	public static final String ZIP_CODE = "zipCode";

	public static final String STATE = "state";

	public static final String DESTINATION_TERMINAL = "destinationTerminal";

	public static final String CREATION_USER = "creationUser";
	
	public static final String CREATION_AT = "createdDateAt";
	
	public static final String EFFECTIVE_DATE_AT = "effectiveDateAt";
//	static final String EFFECTIVE_DATE = "effectiveDate";
	
	public static final String TRANSACTION_TYPE = "transactionType";
	
	public static final String PROCESSED_FLAG = "processed";
	
	public static final String CURRENT_FLAG = "current";
	
	public static final String UUID = "uuid";
	
	public static final String CANCELLED_USER = "cancelledUser";
	
	public static final String CANCELLED_TIMESTAMP =  "cancelledTimestamp";
	
	public static final String CANCELLED_FLAG = "cancelledFlag";
	
	public static final String  PROCESSED_AT = "processedDateTime";
	
	public static final String ZIP_FROM = "zipFrom";
	
	public static final String ZIP_TO = "zipTo";
	
	public static final String TIME_ZONE = "timeZone";

	static final transient String EFFECTIVE_DT_AT = "effectiveDateAt";
	public static final transient String EFFECTIVE_DT = "effectiveDate";

	public static final transient String CREATION_DT = "creationDate";

	public static final transient String PROCESSED_DT = "processedAt";

	static final transient String CANCELLED_DT = "cancelledAt";
	
	public static final String APP_TRANSACTION_TMSTMP_KEY = "ZDTRANSACTIONS_TMSTMP";
	
	public static final String APP_TRANSACTION_ZIP_KEY = "TRANSACTIONS_ZIPCODES";
	
    public static final double ZIP_CODE_DEFAULT_SCORE = 1d;
    
	public static final String APP_FACILITY_KEY = "MASTERFACILITYDELTA";
	
	public static final String APP_ZIPTODEST_NETWORK_KEY = "NETWORK";
	
	public static final String APP_ZIPTODEST_HASDELTA_KEY = "MASTERZIPTODESTHASDELTA";
	
	public static final String APP_TRANSACTION_SAVE_CANCELLED_TMSTAMP_KEY = "SAVE_CANCELLED_TMSTMP";
	public static final String APP_TRANSACTION_SAVE_CREATION_TMSTAMP_KEY = "SAVE_CREATION_TMSTMP";
	
		
}
