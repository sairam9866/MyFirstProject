package com.fedex.ziptodest.dao;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.stereotype.Component;

import com.fedex.ziptodest.model.ZipToDest;
import com.fedex.ziptodest.model.ZipToDestHasDelta;
import com.fedex.ziptodest.util.AppConstants;
import com.fedex.ziptodest.util.ZdTimer;
import com.fedex.ziptodest.util.ZipToDestHasDeltaMapper;
import com.fedex.ziptodest.util.ZipToDestMapper;
import com.fedex.ziptodest.util.ZipToDestUtil;

@Component
public class HashSetDao {

	public static final Logger LOGGER = LoggerFactory.getLogger(HashSetDao.class);

	private static String HASH_MASTER_KEY = "HASH_MASTER_KEY";

	private static String SET_NETWORK_ZIP_CODE = "SET_NETWORK_ZIPCODE_KEY";

	private static String SET_NETWORK = "SET_NETWORK_KEY";

	private static String SET_NETWORK_COUNTRY_CODE = "SET_NETWORK_COUNTRY_CODE_KEY";

	@Value(value = "${keyspace}")
	private String keyspace;

	@Autowired
	public ZipToDestUtil zipToDestUtil;

	@Resource(name = "strRedisTemplate")
	HashOperations<String, String, String> zdHashOperations;

	@Resource(name = "strRedisTemplate")
	SetOperations<String, String> zdSetOperations;

	@Autowired
	@Qualifier("strRedisTemplate")
	public RedisTemplate<String, String> strRedisTemplate;

	@Autowired
	ZipToDestMapper mapper;

	@Autowired
	ZipToDestHasDeltaMapper zipToDestHasDeltaMapper;

	public boolean save(ZipToDest zipToDest) {

		try {

			// pipeline need to add

			String hashKey = zipToDestUtil.zipToDestHashKey(zipToDest);

			strRedisTemplate.execute(new SessionCallback<List<String>>() {

				@Override
				public List<String> execute(RedisOperations operations) throws DataAccessException {
					operations.multi();

					operations.opsForHash().putAll(hashKey, mapper.toMap(zipToDest));

					// zdHashOperations.put(HASH_MASTER_KEY, subKey,
					// jsonZipToDest);

					// Stores the unique id to set data structure,
					operations.opsForSet().add(getUIKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkZipcodeKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkCountryCodeKey(zipToDest), hashKey);

					return operations.exec();
				}

			});

		} catch (Exception e) {
			LOGGER.error("Error while saving records" + e);
			return false;
		}

		return true;
	}

	public boolean saveAllOld(List<ZipToDest> zipToDests) {

		strRedisTemplate.executePipelined(new SessionCallback<List<String>>() {

			@Override
			public List<String> execute(RedisOperations operations) throws DataAccessException {
				// operations.multi();

				for (ZipToDest zipToDest : zipToDests) {

					String hashKey = zipToDestUtil.zipToDestHashKey(zipToDest);
					operations.opsForHash().putAll(hashKey, mapper.toMap(zipToDest));

					// zdHashOperations.put(HASH_MASTER_KEY, subKey,
					// jsonZipToDest);

					// Stores the unique id to set data structure,
					operations.opsForSet().add(getUIKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkZipcodeKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkCountryCodeKey(zipToDest), hashKey);
				}

				return operations.exec();
			}

		});

		return true;
	}

	public boolean saveAll(List<ZipToDest> zipToDests) {

		strRedisTemplate.executePipelined(new SessionCallback<List<String>>() {
			@SuppressWarnings({ "unchecked", "static-access" })
			@Override
			public List<String> execute(RedisOperations operations) throws DataAccessException {
				String zipToDestHasDeltaHash = "";
				for (ZipToDest zipToDest : zipToDests) {

					String hashKey = zipToDestUtil.zipToDestHashKey(zipToDest);
					operations.opsForHash().putAll(hashKey, mapper.toMap(zipToDest));

					// zdHashOperations.put(HASH_MASTER_KEY, subKey,
					// jsonZipToDest);

					// Stores the unique id to set data structure,
					operations.opsForSet().add(getUIKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkZipcodeKey(zipToDest), hashKey);

					operations.opsForSet().add(getNetworkCountryCodeKey(zipToDest), hashKey);

					operations.opsForSet().add(getFacilityIdKey(zipToDest), hashKey);
					if (zipToDest.getCurrent().equals("Y") && zipToDest.getProcessed().equals("Y")) {

						ZipToDestHasDelta zipToDestHasDelta = new ZipToDestHasDelta();
						zipToDestHasDelta.setLastUpdateTimestamp(zipToDest.getProcessedDateTime());
						zipToDestHasDelta.setNetwork(zipToDest.getNetwork());

						zipToDestHasDeltaHash = getFacilityHasDeltaKey(keyspace, zipToDestHasDelta.getNetwork());
						
						//creates hash for ziptodesthasdelta
						operations.opsForHash().putAll(zipToDestHasDeltaHash,
								zipToDestHasDeltaMapper.toMap(zipToDestHasDelta));
						
						// Has Delta last processed query
						operations.opsForZSet().add(zipToDestUtil.getHasDeltaLastProcessed(keyspace,
								zipToDest.getNetwork(), AppConstants.PROCESSED_DT), zipToDestHasDeltaHash,
								zipToDest.getProcessedDateTime());

						// Distribution network and zipcode qurey
						operations.opsForSet().add(zipToDestUtil.getProcessedByNetworkAndZipCodeKey(keyspace,
								zipToDest.getNetwork(), zipToDest.getZipCode()), hashKey);

						// Distribution network query
						operations.opsForSet().add(
								zipToDestUtil.getRedisKey(keyspace, AppConstants.APP_ZIPTODEST_NETWORK_KEY),
								zipToDest.getNetwork());

						// Distribution Has Delta
						operations.opsForZSet().add(
								getFacilityHasDeltaKey(keyspace, AppConstants.APP_ZIPTODEST_HASDELTA_KEY), hashKey,
								zipToDest.getProcessedDateTime());

						// Distribution network and country code by processed
						// date query
						operations.opsForZSet()
								.add(zipToDestUtil.getCurrentByProcessedDate(keyspace, zipToDest.getNetwork(),
										zipToDest.getCountryCode(), AppConstants.PROCESSED_DT), hashKey,
										zipToDest.getProcessedDateTime());						

						//Distribution facility by effective date query
						operations.opsForZSet().add(zipToDestUtil.getRedisKey(keyspace, AppConstants.APP_FACILITY_KEY),
								hashKey, zipToDest.getEffectiveDateAt());

						//Distribution network query
						operations.opsForSet().add(networkKey(zipToDest.getNetwork()), hashKey);

						//Distribution network and zipcode query
						operations.opsForSet().add(networkZipCodeKey(zipToDest.getNetwork(), zipToDest.getZipCode()),
								hashKey);

						//Distribution facility query
						operations.opsForSet().add(getFacilityIdKey(zipToDest.getDestinationTerminal()), hashKey);
						
						//Batch network and country code query to find old current transaction
						operations.opsForSet().add(
								getNetworkCountryCodeKey(zipToDest.getNetwork(), zipToDest.getCountryCode()), hashKey);
						operations.opsForHash().put(getJSONCurrentRecordsKey(), hashKey, zipToDest.toJson(hashKey));

					}
					
					operations.opsForZSet().add(
							zipToDestUtil.getRedisKey(keyspace, AppConstants.APP_TRANSACTION_TMSTMP_KEY), hashKey,
							zipToDest.getEffectiveDateAt());
					
					operations.opsForZSet().add(
							zipToDestUtil.getRedisKey(keyspace, AppConstants.APP_TRANSACTION_ZIP_KEY),
							zipToDest.getZipCode(), AppConstants.ZIP_CODE_DEFAULT_SCORE);

					if (zipToDest.getCancelledTimestamp() != null) {
						operations.opsForZSet()
								.add(zipToDestUtil.getRedisKey(keyspace,
										AppConstants.APP_TRANSACTION_SAVE_CANCELLED_TMSTAMP_KEY), hashKey,
										zipToDest.getCancelledTimestamp());
					}

					/*
					operations.opsForZSet().add(
							zipToDestUtil.getRedisKey(keyspace, AppConstants.APP_TRANSACTION_SAVE_CREATION_TMSTAMP_KEY),
							hashKey, zipToDest.getCreatedDateAt());*/
				}

				return null;
			}

		});

		return true;
	}

	public boolean delete(ZipToDest zipToDest) {

		try {

			// pipeline need to add

			String subKey = zipToDestUtil.zipToDestHashKey(zipToDest);

			strRedisTemplate.execute(new SessionCallback<List<String>>() {

				@Override
				public List<String> execute(RedisOperations operations) throws DataAccessException {
					operations.multi();

					operations.opsForHash().getOperations().unlink(subKey);
					// zdHashOperations.put(HASH_MASTER_KEY, subKey,
					// jsonZipToDest);

					// Stores the unique id to set data structure
					operations.opsForSet().remove(getUIKey(zipToDest), subKey);

					operations.opsForSet().remove(getNetworkKey(zipToDest), subKey);

					operations.opsForSet().remove(getNetworkZipcodeKey(zipToDest), subKey);

					operations.opsForSet().remove(getNetworkCountryCodeKey(zipToDest), subKey);

					return operations.exec();
				}

			});

		} catch (Exception e) {
			LOGGER.error("Error while saving records" + e);
			return false;
		}

		return true;
	}

	public boolean deleteAll(List<ZipToDest> zipToDests) {

		try {

			strRedisTemplate.execute(new SessionCallback<List<String>>() {

				@Override
				public List<String> execute(RedisOperations operations) throws DataAccessException {
					operations.multi();

					for (ZipToDest zipToDest : zipToDests) {

						String subKey = zipToDestUtil.zipToDestHashKey(zipToDest);
						operations.opsForHash().getOperations().unlink(subKey);
						// zdHashOperations.put(HASH_MASTER_KEY, subKey,
						// jsonZipToDest);

						// Stores the unique id to set data structure
						operations.opsForSet().remove(getUIKey(zipToDest), subKey);

						operations.opsForSet().remove(getNetworkKey(zipToDest), subKey);

						operations.opsForSet().remove(getNetworkZipcodeKey(zipToDest), subKey);

						operations.opsForSet().remove(getNetworkCountryCodeKey(zipToDest), subKey);
					}

					return operations.exec();
				}

			});

		} catch (Exception e) {
			LOGGER.error("Error while saving records" + e);
			return false;
		}

		return true;
	}

	public Set<String> selectSubKeyByNetwork(String hashKey) {
		Set<String> ids = zdSetOperations.members(hashKey.toUpperCase());
		return ids;
	}

	public List<String> findByNetworkAndCountryCode(String network, String countryCode) {
		ZdTimer timer = ZdTimer.start();
		List<String> result = new ArrayList<>();
		Set<String> ids = selectSubKeyByNetwork(networkCountryCodeKey(network, countryCode));

		// List<String> result = zdHashOperations.multiGet(HASH_MASTER_KEY,
		// ids);

		for (String id : ids) {
			LOGGER.info("Id : {}", id);
			Map<String, String> map = zdHashOperations.entries(id);
			String ziptodest = getZipToDestJson(map);
			result.add(ziptodest);
		}

		LOGGER.info("Result Count : {}", result.size());
		LOGGER.info("findByNetworkAndCountryCode Time Taken : {}ms", timer.stop());
		return result;
	}

	@SuppressWarnings("unchecked")
	public List<String> selectByNetwork(String network) {
		ZdTimer timer = ZdTimer.start();
		List<String> output = null;

		Set<String> ids = selectSubKeyByNetwork(network);

		List<String> result = strRedisTemplate.execute(new SessionCallback<List<String>>() {

			@Override
			public List<String> execute(RedisOperations operations) throws DataAccessException {
				operations.multi();

				for (String id : ids) {
					Map<String, String> map = operations.opsForHash().entries(id);

				}

				return operations.exec();
			}

		});

		LOGGER.info("Result Count : {}", result.size());
		LOGGER.info("selectByNetwork Time Taken : {}ms", timer.stop());

		return result;
	}

	public List<Object> findByNetwork(String network) {
		ZdTimer timer = ZdTimer.start();
		Set<String> ids = selectSubKeyByNetwork(network);

		List<Object> result = strRedisTemplate.executePipelined(new RedisCallback<List<String>>() {

			@Override
			public List<String> doInRedis(RedisConnection connection) throws DataAccessException {

				for (String id : ids) {
					connection.hGet(HASH_MASTER_KEY.getBytes(StandardCharsets.UTF_8),
							id.getBytes(StandardCharsets.UTF_8));
				}

				return null;
			}

		});

		LOGGER.info("Result Count : {}", result.size());
		LOGGER.info("findByNetwork Time Taken : {}ms", timer.stop());
		return result;
	}

	public List<Object> executePipelinedByNetwork(String network) {
		ZdTimer timer = ZdTimer.start();
		Set<String> ids = selectSubKeyByNetwork(network);
		// StringBuilder zipToDests = new StringBuilder();

		List<Object> result = strRedisTemplate.executePipelined(new SessionCallback<List<String>>() {

			@Override
			public List<String> execute(RedisOperations operations) throws DataAccessException {
				for (String id : ids) {
					operations.opsForHash().get(HASH_MASTER_KEY, id);
					/*
					 * if (zipToDests.length() == 0) {
					 * zipToDests.append("[").append(String.valueOf(zipToDest));
					 * }
					 */

				}
				return null;
			}
		}, new StringRedisSerializer());

		/*
		 * if (zipToDests.length() != 0) { zipToDests.append("]"); }
		 * LOGGER.info("REsult : {}", zipToDests);
		 */

		LOGGER.info("Result Count : {}", result.size());
		LOGGER.info("executePipelinedByNetwork Time Taken : {}ms", timer.stop());
		return result;
	}

	public List<String> multiGetByNetwork(String network) {
		ZdTimer timer = ZdTimer.start();

		Set<String> ids = selectSubKeyByNetwork(network);

		List<String> result = zdHashOperations.multiGet(HASH_MASTER_KEY, ids);

		LOGGER.info("Result Count : {}", result.size());
		LOGGER.info("multiGetByNetwork Time Taken : {}ms", timer.stop());
		return result;

	}

	public String hashMasterKey(String key) {
		return ("{" + keyspace + "_" + key + "}").toUpperCase();
	}

	public String getNetworkKey(ZipToDest zipToDest) {
		return (getUIKey(zipToDest) + ":" + zipToDest.getNetwork().toUpperCase());
	}

	public String getNetworkZipcodeKey(ZipToDest zipToDest) {
		return (getUIKey(zipToDest) + ":" + zipToDest.getNetwork() + ":" + zipToDest.getZipCode()).toUpperCase();
	}

	public String getNetworkCountryCodeKey(ZipToDest zipToDest) {
		return (getUIKey(zipToDest) + ":" + zipToDest.getNetwork() + ":" + zipToDest.getCountryCode()).toUpperCase();
	}

	public String getFacilityIdKey(ZipToDest zipToDest) {
		return (getUIKey(zipToDest) + ":" + Integer.parseInt(zipToDest.getDestinationTerminal())).toUpperCase();
	}

	public String getUIKey(ZipToDest zipToDest) {
		if (zipToDest.getCurrent().equalsIgnoreCase("Y") && zipToDest.getProcessed().equalsIgnoreCase("Y")
				&& zipToDest.getCancelledFlag().equalsIgnoreCase("N")) {

			return (keyspace.toUpperCase() + ":" + "CURRENT_RECORDS");
		}

		if (zipToDest.getCurrent().equalsIgnoreCase("N") && zipToDest.getProcessed().equalsIgnoreCase("N")
				&& zipToDest.getCancelledFlag().equalsIgnoreCase("N")) {

			return (keyspace.toUpperCase() + ":" + "FUTURE_RECORDS");
		}

		if (zipToDest.getCurrent().equalsIgnoreCase("N") && zipToDest.getProcessed().equalsIgnoreCase("Y")
				&& zipToDest.getCancelledFlag().equalsIgnoreCase("N")) {

			return (keyspace.toUpperCase() + ":" + "HISTORICAL_RECORDS");
		}

		if (zipToDest.getCurrent().equalsIgnoreCase("N") && zipToDest.getProcessed().equalsIgnoreCase("N")
				&& zipToDest.getCancelledFlag().equalsIgnoreCase("Y")) {

			return (keyspace.toUpperCase() + ":" + "HISTORICAL_RECORDS");
		}

		return (keyspace.toUpperCase() + ":" + "NA_RECORDS");
	}

	public String networkCountryCodeKey(String network, String countryCode) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network.toUpperCase() + ":" + countryCode).toUpperCase();
	}

	public String networkKey(String network) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network.toUpperCase()).toUpperCase();
	}

	public String networkZipCodeKey(String network, String zipCode) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network + ":" + zipCode).toUpperCase();
	}

	public String getNetworkCountryCodeKey(String network, int countryCode) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + network + ":" + String.valueOf(countryCode)).toUpperCase();
	}

	public String getJSONCurrentRecordsKey() {
		return (keyspace + ":" + "CURRENT_RECORDS_JSON").toUpperCase();
	}

	public String getFacilityIdKey(String destinationTerminal) {
		return (keyspace + ":" + "CURRENT_RECORDS" + ":" + destinationTerminal).toUpperCase();
	}

	public String getFacilityHasDeltaKey(String keySpace, String key) {
		return (keySpace + ":" + "FACILITYHASDELTA:" + key).toUpperCase();
	}

	public Map<String, String> getZipToDestMap(ZipToDest zipToDest) {
		Map<String, String> map = new HashMap<>();
		map.put("network", zipToDest.getNetwork());
		map.put("zipcode", zipToDest.getZipCode());
		return map;
	}

	public String getZipToDestJson(Map<String, String> map) {

		// tOdO : CREATE ZIP TO DEST OBJECT AND RETURN LIST
		StringBuilder builder = new StringBuilder();

		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (builder.length() == 0) {
				builder.append("{").append(entry.getKey()).append(":").append(entry.getValue());
			} else {
				builder.append(",").append(entry.getKey()).append(":").append(entry.getValue());
			}

		}
		builder.append("}");
		return builder.toString();
	}

	public List<ZipToDest> getZipToDestfromRedis(String network, String countryCode) {

		Set<String> ids = selectSubKeyByNetwork(networkCountryCodeKey(network, countryCode));

		List<ZipToDest> output = new ArrayList<>();

		List<Object> hashes = getHashesFromRedis(ids);

		// call mapper to convert result to List<ZipToDest>
		hashes.forEach(m -> {
			@SuppressWarnings("unchecked")
			ZipToDest ziptodest = mapper.toObj((Map<String, String>) m);
			output.add(ziptodest);

		});

		return output;
	}

	private List<Object> getHashesFromRedis(Set<String> ids) {
		List<Object> result = strRedisTemplate.executePipelined(new SessionCallback<List<Map<String, String>>>() {

			@Override
			public List<Map<String, String>> execute(RedisOperations operations) throws DataAccessException {
				// operations.multi();

				for (String id : ids) {
					Map<String, String> map = operations.opsForHash().entries(id);

				}

				return null;
			}

		});
		return result;
	}

}
