package com.fedex.ziptodest.util;

import java.time.Duration;
import java.time.Instant;

public class ZdTimer {

	private Instant start;
	
	private Instant stop;
	
	public ZdTimer(){
		start = Instant.now();
	}	
	
	public static ZdTimer start(){
		return new ZdTimer();		 
	}
	
	public long stop(){
		stop = Instant.now();
		return Duration.between(start, stop).toMillis();
	}
	
	public void reset(){
		start = Instant.now();
	}
}
