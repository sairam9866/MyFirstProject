package com.fedex.ziptodest.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;

//@Embeddable
public class ZDOracleTransactionalPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "NETWORK")
	private String network;

//	protected int countryCode;

	@Column(name = "ZIP_CD")
	private String zipCode;

	@Column(name = "CREATION_DATE_TMSTP")
	private Timestamp creationDateTimestamp;	
	
	@Column(name = "DEST_TERMINAL")
	private String destinationTerminal;

	public ZDOracleTransactionalPK() {

	}

	public ZDOracleTransactionalPK(String network, String destinationTerminal, String zipCode, Timestamp creationDateTimestamp) {
		super();
		this.network = network;
		this.destinationTerminal = destinationTerminal;
		this.zipCode = zipCode;
		this.creationDateTimestamp = creationDateTimestamp;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Timestamp getCreationDateTimestamp() {
		return creationDateTimestamp;
	}

	public void setCreationDateTimestamp(Timestamp creationDateTimestamp) {
		this.creationDateTimestamp = creationDateTimestamp;
	}

	public String getDestinationTerminal() {
		return destinationTerminal;
	}

	public void setDestinationTerminal(String destinationTerminal) {
		this.destinationTerminal = destinationTerminal;
	}

	

}
