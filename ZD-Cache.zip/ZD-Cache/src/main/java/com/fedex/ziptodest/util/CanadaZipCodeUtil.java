package com.fedex.ziptodest.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CanadaZipCodeUtil {
	public static void getZipCodes(String network, String zip, String state, String terminal) {
		String inQry = "Insert into TRX_ZIP_TO_DEST (NETWORK,COUNTRY_CD,ZIP_CD,STATE,DEST_TERMINAL,CREATION_DATE_TMSTP,"
				+ "CREATION_USER,EFFECTIVE_DATE_TMSTP,PROCESSED_FLG,CURRENT_FLG,CANCELLED_FLG,UUID,TRANS_TYPE) "
				+ "values ('%s',124,'%s','%s',%S,SYSDATE,'SYSTEM',SYSDATE," + "'N','N','N','PATCH05192020','A');";
		int first = 0;
		int last = 0;
		char alpha = 65;
		try {
			CsvReader<ZipCodeMapper> csvReader = new CsvReader<ZipCodeMapper>();
			List<ZipCodeMapper> mapper =  csvReader.read(ZipCodeMapper.class, "zipcodes.csv");			
			BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/patch.sql"));
			writer.flush();
			while (alpha <= 90) {
				for (first = 0; first <= 9; first++) {
					for (last = 0; last <= 9; last++) {
						String zipCode = zip + first + (char) alpha + last;
						ZipCodeMapper content = new ZipCodeMapper(zipCode);						
						if (mapper.contains(content)) {
							int index = mapper.indexOf(new ZipCodeMapper(zipCode));
							writer.append(
									String.format(inQry, network, zipCode, state, mapper.get(index).getTerminal()));
						} else {
							writer.append(String.format(inQry, network, zipCode, state, terminal));
						}
						writer.newLine();
					}
				}
				alpha++;
			}
			System.out.println("done");
			writer.close();
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}
}
