package com.fedex.ziptodest.service;

public interface ZipToDestService {
	
	public String saveDataToRedis();
	public String deleteDataFromRedis();
	String deleteDataFromRedisLocal();
}
