/*package org.ZD.Cache;

import java.sql.Timestamp;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.model.FacilityDeltaOracle;
import com.fedex.ziptodest.model.FacilityDeltaPKOracle;
import com.fedex.ziptodest.model.MasterZDOracleFacilityId;
import com.fedex.ziptodest.model.MasterZDOracleFacilityIdPK;
import com.fedex.ziptodest.model.MasterZDOracleZipToDestination;
import com.fedex.ziptodest.model.MasterZDOracleZipToDestinationPK;
import com.fedex.ziptodest.model.ZipToDestHasDeltaOracle;
import com.fedex.ziptodest.repository.MasterZDRedisZipToDestRepository;
import com.fedex.ziptodest.util.ZipToDestUtil;

@RunWith(SpringRunner.class)
public class ZipToDestUtilTest {

	@InjectMocks
	ZipToDestUtil zipToDestUtil;

	MasterZDOracleZipToDestinationPK id;

	@Mock
	MasterZDRedisZipToDestRepository masterZDRedisTransactionalRepository;

	@Test
	public void zipToDestOracleDataToRedis() {

		@SuppressWarnings("deprecation")
		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);
		MasterZDOracleZipToDestination masterZDOracleZipToDestination = new MasterZDOracleZipToDestination();

		MasterZDOracleZipToDestinationPK masterZDOracleZipToDestinationPK = new MasterZDOracleZipToDestinationPK();
		masterZDOracleZipToDestination.setDestination(458);
		masterZDOracleZipToDestination.setState("UAS");
		masterZDOracleZipToDestination.setLastUpdateBy("USER");
		masterZDOracleZipToDestination.setLastUpdateTimestamp(timestamp);
		masterZDOracleZipToDestinationPK.setCountryCode(125);
		masterZDOracleZipToDestinationPK.setNetwork("LPN");
		masterZDOracleZipToDestinationPK.setZipCode("458711");
		masterZDOracleZipToDestination.setId(masterZDOracleZipToDestinationPK);

		// Mockito.doReturn(masterRedisZipToDestination).when()
		zipToDestUtil.zipToDestOracleDataToRedis(masterZDOracleZipToDestination);

	}

	@Test
	public void faclityOracleDataToRedis() {
		@SuppressWarnings("deprecation")
		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);
		MasterZDOracleFacilityId masterZDOracleFacilityId = new MasterZDOracleFacilityId();
		MasterZDOracleFacilityIdPK masterZDOracleFacilityIdPK = new MasterZDOracleFacilityIdPK();
		masterZDOracleFacilityId.setState("US");
		masterZDOracleFacilityId.setTransactionType('Y');
		masterZDOracleFacilityId.setUuId("test");
		masterZDOracleFacilityIdPK.setEffectiveDateTimestamp(timestamp);
		masterZDOracleFacilityIdPK.setNetwork("LPN");
		masterZDOracleFacilityIdPK.setZipCode("1452");
		masterZDOracleFacilityIdPK.setFacilityId(455);
		masterZDOracleFacilityId.setFacilityIdPK(masterZDOracleFacilityIdPK);

		zipToDestUtil.faclityOracleDataToRedis(masterZDOracleFacilityId);
	}

	@Test
	public void savefaclityOracleDataToRedisTest() {
		@SuppressWarnings("deprecation")
		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);
		FacilityDeltaOracle oracleFacility = new FacilityDeltaOracle();
		FacilityDeltaPKOracle pk = new FacilityDeltaPKOracle();

		pk.setEffectiveDateTimestamp(timestamp);
		pk.setFacilityId(1241);
		pk.setNetwork("LPN");
		pk.setZipCode("100");

		oracleFacility.setFacilityIdPK(pk);
		oracleFacility.setState("CA");
		oracleFacility.setTransactionType('A');
		oracleFacility.setUuId("1234");

		zipToDestUtil.savefaclityOracleDataToRedis(oracleFacility);
	}
	
	@Test
	public void saveZipToDestHasDeltaOracleDataToRedisTest(){
		
		ZipToDestHasDeltaOracle oracleZipToDestHasDelta=new ZipToDestHasDeltaOracle();
		@SuppressWarnings("deprecation")
		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);
		oracleZipToDestHasDelta.setLastUpdateTimestamp(timestamp);
		oracleZipToDestHasDelta.setNetwork("LPN");
		
		zipToDestUtil.saveZipToDestHasDeltaOracleDataToRedis(oracleZipToDestHasDelta);
	}

}
*/