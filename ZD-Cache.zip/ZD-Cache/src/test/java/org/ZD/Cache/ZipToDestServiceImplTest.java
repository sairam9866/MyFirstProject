/*package org.ZD.Cache;

import static org.junit.Assert.assertEquals;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.model.MasterRedisFaclityID;
import com.fedex.ziptodest.model.MasterZDOracleFacilityId;
import com.fedex.ziptodest.model.MasterZDOracleZipToDestination;
import com.fedex.ziptodest.model.MasterZDOracleZipToDestinationPK;
import com.fedex.ziptodest.model.RenderRedisResponse;
import com.fedex.ziptodest.model.ZipToDestination;
import com.fedex.ziptodest.repository.MasterZDOracleZipToDestRepository;
import com.fedex.ziptodest.repository.MasterZDRedisFacilityrepository;
import com.fedex.ziptodest.repository.MasterZDRedisZipToDestRepository;
import com.fedex.ziptodest.repository.ZDOracleFacilityrepository;
import com.fedex.ziptodest.service.impl.ZipToDestServiceImpl;
import com.fedex.ziptodest.util.ZipToDestUtil;

@RunWith(SpringRunner.class)
public class ZipToDestServiceImplTest {
	
	

	@InjectMocks
	ZipToDestServiceImpl zipToDestServiceImpl;
	@Mock
	MasterZDOracleZipToDestRepository masterZDOracleZipToDestRepository;

	@Mock
	MasterZDRedisZipToDestRepository masterZDRedisTransactionalRepository;

	@Mock
	ZDOracleFacilityrepository zDOracleFacilityrepository;

	@Mock
	MasterZDRedisFacilityrepository masterZDRedisFacilityrepository;

	@Mock
	ZipToDestUtil zipToDestUtil;

	@Test
	public void saveZipTodestDataToRedis() {
		RenderRedisResponse renderRedisResponse=new RenderRedisResponse();
		Timestamp timestamp = new Timestamp(2019, 02, 04, 02, 05, 01, 001);

		List<MasterZDOracleZipToDestination> listOfRecord = new ArrayList<MasterZDOracleZipToDestination>();
		MasterZDOracleZipToDestination destination = new MasterZDOracleZipToDestination();
		ZipToDestination masterRedisZipToDestination= new ZipToDestination();
		destination.setDestination(10);
		destination.setLastUpdateBy("User");
		destination.setLastUpdateTimestamp(timestamp);
		destination.setState("USA");
		listOfRecord.add(destination);
		masterRedisZipToDestination.setNetwork("FXG");
		masterRedisZipToDestination.setZipCode("12345");
		masterRedisZipToDestination.setCountryCode(840);		
		masterRedisZipToDestination.setDestination(1);
		masterRedisZipToDestination.setLastUpdateBy("ABC");
		masterRedisZipToDestination.setLastUpdateTimestamp(timestamp.getTime());
		masterRedisZipToDestination.buildKey();
		
		Mockito.doReturn(listOfRecord).when(masterZDOracleZipToDestRepository).findAll();
		Mockito.doReturn(masterRedisZipToDestination).when(zipToDestUtil).zipToDestOracleDataToRedis(destination);
		
		Mockito.doReturn(true).when(masterZDRedisTransactionalRepository).existsById(masterRedisZipToDestination.getId());	
		
		//renderRedisResponse=zipToDestServiceImpl.saveZipTodestDataToRedis();
		
		Mockito.doReturn(false).when(masterZDRedisTransactionalRepository).existsById(masterRedisZipToDestination.getId());
		//renderRedisResponse=zipToDestServiceImpl.saveZipTodestDataToRedis();

		//assertEquals("0", renderRedisResponse.getNoOfRowsExistsInRedis());
//		assertEquals(10, destination.getDestination());
//		assertEquals("USA", destination.getState());
	}

	@Test
	public void saveOracleFacilityDataToRedis() {
		RenderRedisResponse renderRedisResponse=new RenderRedisResponse();
		List<MasterZDOracleFacilityId> listOfRecord = new ArrayList<MasterZDOracleFacilityId>();
		MasterZDOracleFacilityId masterZDOracleFacilityId = new MasterZDOracleFacilityId();
		MasterRedisFaclityID redisFacility=new MasterRedisFaclityID();
		masterZDOracleFacilityId.setTransactionType('C');
		masterZDOracleFacilityId.setUuId("TXN");
		masterZDOracleFacilityId.setState("USA");
		listOfRecord.add(masterZDOracleFacilityId);
		redisFacility.setTransactionType('c');
		redisFacility.setUuId("USA");
		redisFacility.setNetwork("FXG");
		redisFacility.buildKey();
		Mockito.doReturn(listOfRecord).when(zDOracleFacilityrepository).findAll();
		Mockito.doReturn(redisFacility).when(zipToDestUtil).faclityOracleDataToRedis(masterZDOracleFacilityId);
		
		Mockito.doReturn(true).when(masterZDRedisFacilityrepository).existsById(redisFacility.getId());
		
		renderRedisResponse=zipToDestServiceImpl.saveOracleFacilityDataToRedis();
		
		Mockito.doReturn(false).when(masterZDRedisFacilityrepository).existsById(redisFacility.getId());
		renderRedisResponse=zipToDestServiceImpl.saveOracleFacilityDataToRedis();

		assertEquals("0", renderRedisResponse.getNoOfRowsExistsInRedis());

	}

	@Test
	public void deleteZipTodestRecordsFromRedis() {

		Mockito.doNothing().when(masterZDRedisTransactionalRepository).deleteAll();
		zipToDestServiceImpl.deleteZipTodestRecordsFromRedis();
	}

	@Test
	public void deleteAllFacilityRecardsfromRedis() {

		Mockito.doNothing().when(masterZDRedisFacilityrepository).deleteAll();
		zipToDestServiceImpl.deleteAllFacilityRecardsfromRedis();
	}
	
	

}
*/