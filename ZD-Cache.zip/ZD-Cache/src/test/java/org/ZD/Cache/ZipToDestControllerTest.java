/*package org.ZD.Cache;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.controller.ZipToDestController;
import com.fedex.ziptodest.model.FacilityDeltaOracle;
import com.fedex.ziptodest.model.MasterZDOracleFacilityId;
import com.fedex.ziptodest.model.MasterZDOracleZipToDestination;
import com.fedex.ziptodest.model.RenderRedisResponse;
import com.fedex.ziptodest.model.ZipToDestHasDeltaOracle;
import com.fedex.ziptodest.service.FacilityService;
import com.fedex.ziptodest.service.MasterZDOracleFacilityService;
import com.fedex.ziptodest.service.MasterZDOracleZipToDestService;
import com.fedex.ziptodest.service.ZipToDestHasDeltaService;
import com.fedex.ziptodest.service.ZipToDestService;

@RunWith(SpringRunner.class)
public class ZipToDestControllerTest {

	@InjectMocks
	ZipToDestController zipToDestController;
	
	@Mock
	MasterZDOracleFacilityService masterZDOracleFacilityService;

	@Mock
	ZipToDestService zipToDestService;
	
	@Mock
	MasterZDOracleZipToDestService masterzipToDestService;
	
	@Mock
	FacilityService facilityService;
	
	@Mock
	ZipToDestHasDeltaService zipToDestHasDeltaService;
	

	@Test
	public void saveZipTodestDataToRedis() {
		RenderRedisResponse response= new RenderRedisResponse();
		Mockito.doReturn(response).when(zipToDestService).saveZipTodestDataToRedis();
		zipToDestController.saveFacilityDeltaDataFromOracleToRedis();
		assertEquals(response, response);
	}
	
	@Test
	public void saveFacilityDataFromOracleToRedisTest(){
		RenderRedisResponse response= new RenderRedisResponse();
		Mockito.doReturn(response).when(facilityService).saveFacilityOracleFacilityDataToRedis();
		zipToDestController.saveFacilityDeltaDataFromOracleToRedis();
		
	}
	@Test
	public void saveZipToDestHasDeltaDataFromOracletoredisTest(){
		RenderRedisResponse response= new RenderRedisResponse();
		Mockito.doReturn(response).when(zipToDestHasDeltaService).saveZipToDestHasDeltaOracleDataToRedis();
		zipToDestController.saveZipToDestHasDeltaDataFromOracletoredis();
	}

}*/