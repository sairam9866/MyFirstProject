package com.fedex.ZDCache.ServiceValidation;

public class AddAPIDetails {
	
	/**
	 * method: createAddRequest
	 * @param countryCode
	 * @param creationUser
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param state
	 * @param timezone
	 * @param zipcode
	 * @return
	 */
	public static String createAddRequest(String countryCode, String creationUser, String destination,
			String effectiveDate, String network, String state, String timezone, int zipcode) {
		
		String add= "{   \r\n" + 
				"    \"countryCode\":\""+countryCode+"\",\r\n" + 
				"    \"creationUser\": \""+creationUser+"\",\r\n" + 
				"    \"destinationTerminal\":\""+destination+"\",\r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\",\r\n" +
				"    \"network\":\""+network+"\",\r\n" +
				"    \"state\":\""+state+"\",\r\n" +
				"    \"timeZone\":\""+timezone+"\",\r\n" +
				"    \"zipCode\":\""+zipcode+"\"\r\n" +
				"}";
		return add;
		
	}
	
	/**
	 * method: createAddRequestNoComma
	 * @param countryCode
	 * @param creationUser
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param state
	 * @param zipcode
	 * @return
	 */
	public static String createAddRequestNoComma(String countryCode, String creationUser, int destination,
			String effectiveDate, String network, String state, int zipcode) {
		
		String addInvalid= "{   \r\n" + 
				"    \"countryCode\":\""+countryCode+"\",\r\n" + 
				"    \"creationUser\": \""+creationUser+"\",\r\n" + 
				"    \"destinationTerminal\":\""+destination+"\"\r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\"\r\n" +
				"    \"network\":\""+network+"\"\r\n" +
				"    \"state\":\""+state+"\"\r\n" +
				"    \"zipCode\":\""+zipcode+"\"\r\n" +
				"}";
		return addInvalid;
		
	}
	
	/**
	 * method: editRequest
	 * @param destination
	 * @param effectiveDate
	 * @param network
	 * @param zipfrom
	 * @param zipto
	 * @return
	 */
	public static String editRequest(String destination,
			String effectiveDate, String network, String zipfrom, String zipto) {
		
		String modify= "{   \r\n" + 
				"    \"destinationTerminal\":\""+destination+"\"\r\n" + 
				"    \"effectiveDate\":\""+effectiveDate+"\"\r\n" +
				"    \"network\":\""+network+"\"\r\n" +
				"    \"zipFrom\":\""+zipfrom+"\"\r\n" +
				"    \"zipTo\":\""+zipto+"\"\r\n" +
				"}";
		return modify;
		
	}


	
}
