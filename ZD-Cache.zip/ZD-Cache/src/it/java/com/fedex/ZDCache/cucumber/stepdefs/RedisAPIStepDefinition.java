package com.fedex.ZDCache.cucumber.stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static com.fedex.ZDCache.utils.ConfigFileReader.RedisLoadAPIProp;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import org.junit.Ignore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fedex.ZDCache.cucumber.CucumberIntegrationTest;
import com.fedex.ZDCache.ServiceValidation.*;

@Ignore
public class RedisAPIStepDefinition extends CucumberIntegrationTest{

	Response response;
	ValidatableResponse json;
	
	public static Logger log = LoggerFactory.getLogger(RedisAPIStepDefinition.class.getName()); 
	
    @Given("^The base URI is up and running$")
    public void the_base_URI_is_up_and_running() {
        
    	RestAssured.baseURI = RedisLoadAPIProp.getProperty("RedisAPI.lcl.get");
    	log.info("Base URL is up and Running: " + RedisLoadAPIProp.getProperty("RedisAPI.lcl.get"));
    }
    
    @Then("^User should see the status code (\\d+)$")
	public void user_should_see_the_status_code(int statuscode) {
   	
		json = response.then().assertThat().statusCode(statuscode);
		json.log().all().extract();
				
	}
    
    @When("^User verifies \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" for json \"([^\"]*)\"$")
    public void user_verifies_json(String network, String countryCode,
    		String zipcode, String destination, String state, int row) {
        
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get();
    	
    	String network_json = response.jsonPath().getString("network["+row+"]");
    	System.out.println("Network  is: "+network_json);
    	assertEquals(network, network_json);
    	
    	String country_json = response.jsonPath().getString("countryCode["+row+"]");
    	System.out.println("country code is: "+country_json);
    	assertEquals(countryCode, country_json);
    	
    	String zip = response.jsonPath().getString("zipCode["+row+"]");
    	System.out.println("Zip code is: "+zip);
    	assertEquals(zipcode,zip);
    	
    	String state_json = response.jsonPath().getString("state["+row+"]");
    	System.out.println("State is: "+state_json);
    	assertEquals(state,state_json);
    	
    	String dest = response.jsonPath().getString("destinationTerminal["+row+"]");
    	System.out.println("destionation is: "+dest);
    	assertEquals(destination, dest);
    	
    }
    
    @When("^user performs invalid request$")
	public void user_perform_invalid_request() {
   	
       response = given().contentType(ContentType.JSON).accept(ContentType.JSON).when().get(RedisLoadAPIProp.getProperty("RedisAPIInvalidParameter"));
    
	}
    
    @Given("^The base URI is up and running for Add API$")
    public void the_base_URI_is_up_and_running_add() {
        
    	RestAssured.baseURI = RedisLoadAPIProp.getProperty("RedisAPI.lcl.post");
    	
    }
    
    @When("^User sends create request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" to add details$")
	public void user_sends_create_request_with_body(String countryCode, String creationUser, String destination,
			String effectiveDate, String network, String state, String timezone) {
    	 	
    	Random r = new Random(System.currentTimeMillis());
    	int zipcode = 10000+r.nextInt(99999);
    	System.out.println("Zip code is:" +zipcode);
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(AddAPIDetails.createAddRequest(countryCode, creationUser, destination, effectiveDate, network, state, timezone, zipcode)).when()
				.post(Resources.create_request);
		
	}
    
    @When("^User sends create request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" to add details$")
	public void user_sends_create_request_with_body_effectiveDate(String countryCode, String creationUser, String destination,
			 String network, String state, String timezone) {
    	 	
    	Random r = new Random(System.currentTimeMillis());
    	int zipcode = 10000+r.nextInt(99999);
    	System.out.println("Zip code is:" +zipcode);
    	
    	ZonedDateTime zdt = ZonedDateTime.now();
        String effectiveDate = zdt.plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd.HH:mm:ss"));
        System.out.println("Effective Date is:" +effectiveDate);
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(AddAPIDetails.createAddRequest(countryCode, creationUser, destination, effectiveDate, network, state, timezone, zipcode)).when()
				.post(Resources.create_request);
		
	}
    
    @When("^User sends create request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" to add details for Country Canada$")
	public void user_sends_create_request_with_body_Canada(String countryCode, String creationUser, String destination,
			 String network, String state, String timezone, int zipcode) {
    	
    	ZonedDateTime zdt = ZonedDateTime.now();
        String effectiveDate = zdt.plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd.HH:mm:ss"));
        System.out.println("Effective Date is:" +effectiveDate);
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(AddAPIDetails.createAddRequest(countryCode, creationUser, destination, effectiveDate, network, state, timezone, zipcode)).when()
				.post(Resources.create_request);
		
	}
    
    @When("^User sends create request with body \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" to add details invalid$")
	public void user_sends_create_request_with_body_InvalidDate(String countryCode, String creationUser, String destination,
			 String network, String state, String timezone) {
    	 	
    	Random r = new Random(System.currentTimeMillis());
    	int zipcode = 10000+r.nextInt(99999);
    	System.out.println("Zip code is:" +zipcode);
    	
    	ZonedDateTime zdt = ZonedDateTime.now();
        String effectiveDate = zdt.plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd.HH:mm:ss"));
        System.out.println("Effective Date is:" +effectiveDate);
    	
    	response = given().contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(AddAPIDetails.createAddRequest(countryCode, creationUser, destination, effectiveDate, network, state, timezone, zipcode)).when()
				.post(Resources.create_request_invalid);
		
	}
 
    
}