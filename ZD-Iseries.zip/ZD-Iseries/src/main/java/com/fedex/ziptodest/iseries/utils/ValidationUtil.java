package com.fedex.ziptodest.iseries.utils;

import org.apache.commons.lang3.StringUtils;

public final class ValidationUtil {
	private ValidationUtil() {
	}

	public static boolean isValidDestination(String destination) {
		boolean output = false;
		if (StringUtils.isNotBlank(destination) && StringUtils.isNumeric(destination)) {
			int dest = Integer.parseInt(destination);
			output = (dest >= 1 && dest <= 9999);
		}
		return output;
	}
}

