package com.fedex.ziptodest.iseries.repository.redis;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.iseries.model.CountryCode;

@Repository("countryCodeRedisRepository")
public interface CountryCodeRedisRepository extends CrudRepository<CountryCode, String> {
}
