package com.fedex.ziptodest.iseries.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.iseries.model.StateProvince;
import com.fedex.ziptodest.iseries.repository.redis.StateProvinceRedisRepository;

@Repository("stateProvinceRepository")
public class StateProvinceRepository implements StateProvinceRedisRepository {

	public static final Logger LOGGER = LoggerFactory.getLogger(StateProvinceRepository.class);
	
	@Autowired
	@Qualifier("stateProvinceRedisRepository")
	StateProvinceRedisRepository stateProvinceRedisRepository;

	@SuppressWarnings("unchecked")
	@Override
	public StateProvince save(StateProvince stateProvince) {
		return stateProvinceRedisRepository.save(stateProvince);
	}

	@Override
	public List<StateProvince> selectByCountryCode(String... countryCodes) {
		List<StateProvince> output = new ArrayList<>();
		LOGGER.info("No of Country Codes : {}", countryCodes.length);
		for(String countryCode : countryCodes){
			LOGGER.info("countryCode : {}", countryCode);
			output.addAll(stateProvinceRedisRepository.findByCntryc(countryCode));
		}
		return output;
	}
	
	@Override
	public List<StateProvince> findByCntryc(String countryCode) {
		return stateProvinceRedisRepository.findByCntryc(countryCode);
	}

	@Override
	public <S extends StateProvince> Iterable<S> saveAll(Iterable<S> entities) {
		return stateProvinceRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<StateProvince> findById(String id) {
		return stateProvinceRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(String id) {
		return stateProvinceRedisRepository.existsById(id);
	}

	@Override
	public Iterable<StateProvince> findAll() {
		return stateProvinceRedisRepository.findAll();
	}

	@Override
	public Iterable<StateProvince> findAllById(Iterable<String> ids) {
		return stateProvinceRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return stateProvinceRedisRepository.count();
	}

	@Override
	public void deleteById(String id) {
		stateProvinceRedisRepository.deleteById(id);
	}

	@Override
	public void delete(StateProvince entity) {
		stateProvinceRedisRepository.delete(entity);
	}

	@Override
	public void deleteAll(Iterable<? extends StateProvince> entities) {
		stateProvinceRedisRepository.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		stateProvinceRedisRepository.deleteAll();
	}
}
