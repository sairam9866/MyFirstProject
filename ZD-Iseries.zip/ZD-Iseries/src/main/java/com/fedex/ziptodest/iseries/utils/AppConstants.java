package com.fedex.ziptodest.iseries.utils;

public class AppConstants {
	
	private AppConstants(){		
	}

	public static final String HASH_KEY_DESTINATION = "{SRTPF508}";
	public static final String HASH_KEY_NETWORK = "NETWORK";
	public static final Character TERMINAL_STATUS_ADDED = 'A';
	public static final long SET_START_INDEX = 0L;
	public static final long SET_END_INDEX = -1L;
	public static final String COUNTRY_CODE_US = "US";
	public static final String COUNTRY_CODE_CA = "CA";
	
	
}
