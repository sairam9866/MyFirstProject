package com.fedex.ziptodest.iseries.model;

import java.util.Set;

public class StateProvinceResponse {
	private String status;
	private String message;
	private Set<State> data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Set<State> getData() {
		return data;
	}

	public void setData(Set<State> data) {
		this.data = data;
	}

	public StateProvinceResponse() {
		/**
		 * Defalt Constuctor
		 */
	}

	@Override
	public String toString() {
		return "StateProvinceResponse [status=" + status + ", message=" + message + ", data=" + data + "]";
	}
	
}
