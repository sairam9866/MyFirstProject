package com.fedex.ziptodest.iseries.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.fedex.ziptodest.iseries.model.Destination;
import com.fedex.ziptodest.iseries.repository.redis.DestinationRedisRepository;

@Repository("destinationRepository")
public class DestinationRepository implements DestinationRedisRepository{

	@Autowired
	@Qualifier("destinationRedisRepository")
	DestinationRedisRepository destinationRedisRepository;
	
	@Override
	public List<Destination> findByTerminalNumberAndTerminalStatus(Integer terminalNumber, Character terminalStatus) {
		return destinationRedisRepository.findByTerminalNumberAndTerminalStatus(terminalNumber, terminalStatus);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Destination save(Destination destination) {
		return destinationRedisRepository.save(destination);
	}

	@Override
	public <S extends Destination> Iterable<S> saveAll(Iterable<S> entities) {		
		return destinationRedisRepository.saveAll(entities);
	}

	@Override
	public Optional<Destination> findById(Integer id) {		
		return destinationRedisRepository.findById(id);
	}

	@Override
	public boolean existsById(Integer id) {		
		return destinationRedisRepository.existsById(id);
	}

	@Override
	public Iterable<Destination> findAll() {		
		return destinationRedisRepository.findAll();
	}

	@Override
	public Iterable<Destination> findAllById(Iterable<Integer> ids) {		
		return destinationRedisRepository.findAllById(ids);
	}

	@Override
	public long count() {
		return destinationRedisRepository.count();
	}

	@Override
	public void deleteById(Integer id) {
		destinationRedisRepository.deleteById(id);
	}

	@Override
	public void delete(Destination entity) {
		destinationRedisRepository.delete(entity);
	}

	@Override
	public void deleteAll(Iterable<? extends Destination> entities) {
		destinationRedisRepository.deleteAll(entities);
	}

	@Override
	public void deleteAll() {
		destinationRedisRepository.deleteAll();
	}
}

