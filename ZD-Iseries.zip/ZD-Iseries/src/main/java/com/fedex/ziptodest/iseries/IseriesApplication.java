package com.fedex.ziptodest.iseries;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;

@SpringBootApplication
@EnableRedisRepositories
public class IseriesApplication {	
	
	public static final Logger LOGGER = LoggerFactory.getLogger(IseriesApplication.class);
	
	@Value("${spring.profiles.active:Unknown}")
	private String activeProfile;
	
	@Value("${iseries.redis.port:6376}")
	private Integer redisPort;

	@Value("${iseries.redis.hostname:localhost}")
	private String redisHostName;
	
	@Value("${iseries.redis.password}")
	private String redisPassword;

	public static void main(String[] args) {
		SpringApplication.run(IseriesApplication.class, args);
	}

	@Bean(name="iseriesJedisConnectionFactory")
	JedisConnectionFactory jedisConnectionFactory() {
		LOGGER.info("Current Active Profile : {}", activeProfile);
		LOGGER.info("Redis Host : {}", redisHostName);
		LOGGER.info("Redis Port : {}", redisPort);		
		
		JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory();
		jedisConnectionFactory.setHostName(redisHostName);
		jedisConnectionFactory.setPort(redisPort);
		if(StringUtils.isNotBlank(redisPassword)){
			jedisConnectionFactory.setPassword(redisPassword);
		}		
		return jedisConnectionFactory;
	}

	@Bean(name="iseriesRedisTemplate")
	RedisTemplate<String, Object> redisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer());

		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}
}
