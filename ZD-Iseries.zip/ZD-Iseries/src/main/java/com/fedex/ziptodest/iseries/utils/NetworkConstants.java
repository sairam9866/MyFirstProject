package com.fedex.ziptodest.iseries.utils;

public class NetworkConstants {

	private NetworkConstants() {
	}

	public static final String PROP_ACTIVE_PROFILE = "active_profile";
	public static final String PROP_SORTATION_ROLE = "sortation_role";
	public static final String PROP_SVM_ROLE = "svm_role";
	public static final String PROP_JDBC_URL = "jdbc_url";
	public static final String PROP_DRIVER_CLASS = "jdbc_driver_class";
	public static final String PROP_JDBC_USER = "jdbc_username";
	public static final String PROP_JDBC_PD = "jdbc_password";
	public static final String PROP_CONTEXT_PATH = "context_path";
	public static final String PROP_SERVER_PORT = "server_port";
	public static final String PROP_SESSION_TIMEOUT = "session_timeout";
	public static final String PROP_LOG_LEVEL_FEDEX = "log_level_fedex";
	public static final String PROP_LOG_LEVEL_SPRING = "log_level_spring";
	public static final String PROP_LPI_BASE_URL = "base_url";
	public static final String PROP_LDAP_WS_URL = "ldap_ws_url";
	
	//External Network Property
	public static final String EXTERNAL_NETWORKS = "external-networks";
}
