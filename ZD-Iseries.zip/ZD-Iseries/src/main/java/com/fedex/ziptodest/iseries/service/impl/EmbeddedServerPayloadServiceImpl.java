package com.fedex.ziptodest.iseries.service.impl;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.iseries.model.CountryCode;
import com.fedex.ziptodest.iseries.model.Destination;
import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.model.StateProvince;
import com.fedex.ziptodest.iseries.repository.CountryCodeRepository;
import com.fedex.ziptodest.iseries.repository.DestinationRepository;
import com.fedex.ziptodest.iseries.repository.NetworkRepository;
import com.fedex.ziptodest.iseries.repository.StateProvinceRepository;
import com.fedex.ziptodest.iseries.service.EmbeddedServerPayloadService;
import com.fedex.ziptodest.iseries.utils.CsvReader;

@Service
@Profile("lcl")
public class EmbeddedServerPayloadServiceImpl implements EmbeddedServerPayloadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmbeddedServerPayloadServiceImpl.class);
	
	@Autowired
	DestinationRepository destinationRepository;

	@Autowired
	NetworkRepository networkRepository;

	@Autowired
	CountryCodeRepository countryCodeRepository;

	@Autowired
	StateProvinceRepository stateProvinceRepository;

	@Autowired
	CsvReader<Destination> destinationReader;

	@Autowired
	CsvReader<Network> networkReader;

	@Autowired
	CsvReader<CountryCode> countryCodeReader;

	@Autowired
	CsvReader<StateProvince> stateProvinceReader;

	@Override
	public void init() {
		saveDestinations();
		saveNetworks();
		saveCountryCode();
		saveStateProvince();
	}

	private void saveDestinations() {
		List<Destination> destinations = destinationReader.read(Destination.class, "destinations.csv");
		for (Destination destination : destinations) {
			destinationRepository.save(destination);
		}
	}

	private void saveNetworks() {
		List<Network> networks = networkReader.read(Network.class, "networks.csv");
		for (Network network : networks) {
			network.setCreatedBy("TEST");
			network.setCreatedDate(LocalDate.now(ZoneOffset.UTC));
			networkRepository.save(network);
		}
	}

	private void saveCountryCode() {
		List<CountryCode> countryCodes = countryCodeReader.read(CountryCode.class, "countryCodes.csv");
		for (CountryCode countryCode : countryCodes) {			
			countryCodeRepository.save(countryCode);
			LOGGER.info("Saving : {}", countryCode);
		}
	}

	private void saveStateProvince() {
		List<StateProvince> stateProvinces = stateProvinceReader.read(StateProvince.class, "stateProvinces.csv");
		for (StateProvince stateProvince : stateProvinces) {
			stateProvinceRepository.save(stateProvince);
		}
	}
}
