package com.fedex.ziptodest.iseries.utils;

import java.io.File;
import java.util.Collections;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

@Component
public class CsvReader<T> {

	Class<T> entity;

	public CsvReader() {
	}

	public CsvReader(Class<T> entity) {
		this.entity = entity;
	}

	public List<T> read(Class<T> entity, String fileName) {
		try {
			CsvSchema csvSchama = CsvSchema.emptySchema().withHeader();
			CsvMapper csvMapper = new CsvMapper();
			File csvFile = new ClassPathResource(fileName).getFile();
			MappingIterator<T> mappingIterator = csvMapper.reader().forType(entity).with(csvSchama).readValues(csvFile);
			return mappingIterator.readAll();
		} catch (Exception e) {
			return Collections.emptyList();
		}
	}

	public List<T> read(String fileName) {
		return read(entity, fileName);
	}
}
