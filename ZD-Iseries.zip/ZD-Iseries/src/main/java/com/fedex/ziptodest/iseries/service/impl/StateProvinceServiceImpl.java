package com.fedex.ziptodest.iseries.service.impl;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.iseries.model.CountryCode;
import com.fedex.ziptodest.iseries.model.State;
import com.fedex.ziptodest.iseries.model.StateProvince;
import com.fedex.ziptodest.iseries.model.StateProvinceResponse;
import com.fedex.ziptodest.iseries.repository.CountryCodeRepository;
import com.fedex.ziptodest.iseries.repository.StateProvinceRepository;
import com.fedex.ziptodest.iseries.service.StateProvinceService;
import com.fedex.ziptodest.iseries.utils.AppConstants;

@Service
public class StateProvinceServiceImpl implements StateProvinceService {

	private static final Logger LOGGER = LoggerFactory.getLogger(StateProvinceServiceImpl.class);
	
	@Autowired
	@Qualifier("stateProvinceRepository")
	private StateProvinceRepository stateProvinceRepository;
	
	@Autowired
	@Qualifier("countryCodeRepository")
	private CountryCodeRepository countryCodeRepository;

	@Override
	public StateProvinceResponse getStateCountryCode() { 
		LOGGER.info("request service : getStateCountryCode");

		StateProvinceResponse stateProvinceResponse = new StateProvinceResponse();
		List<StateProvince> stateProvinceList;
		List<CountryCode> countryCodeList;

		Set<State> stateSet = new TreeSet<>();
		stateProvinceList = stateProvinceRepository.selectByCountryCode(AppConstants.COUNTRY_CODE_US, AppConstants.COUNTRY_CODE_CA);
		 
		LOGGER.info("Found State Provices : {}", stateProvinceList.size());
		
		countryCodeList = countryCodeRepository.findAll();
		
		LOGGER.info("Found Country Code : {}", countryCodeList.size());

		for (StateProvince stateProvinceIterator : stateProvinceList) {
			for (CountryCode countryCodeIterate : countryCodeList) {
				if (stateProvinceIterator.getCntryc().equals(countryCodeIterate.getCycode())) {
					State state = new State();
					state.setStateName(stateProvinceIterator.getStaPro());
					state.setCode(countryCodeIterate.getCyclcu());
					stateSet.add(state);
				}
			}
		}

		if (!stateSet.isEmpty() && !stateProvinceList.isEmpty() && !countryCodeList.isEmpty()) {
			stateProvinceResponse.setStatus("success");
			stateProvinceResponse.setMessage("The state list has been generated successfully");
			stateProvinceResponse.setData(stateSet);

		} else {
			stateProvinceResponse.setStatus("failure");
			stateProvinceResponse.setMessage("The state list hasn't been generated becuase DB not connected");
			stateProvinceResponse.setData(null);
		}

		return stateProvinceResponse;
	}
	
}
