package com.fedex.ziptodest.iseries.service;

import com.fedex.ziptodest.iseries.model.StateProvinceResponse;

public interface StateProvinceService {
	public StateProvinceResponse getStateCountryCode();
	
}

