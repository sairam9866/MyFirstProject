package com.fedex.ziptodest.iseries.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.model.NetworkModel;
import com.fedex.ziptodest.iseries.model.NetworkRequest;
import com.fedex.ziptodest.iseries.service.NetworkService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class NetworkController {

	@Autowired
	private NetworkService networkService;
	private static Logger log = LoggerFactory.getLogger(NetworkController.class);

	/***
	 * Shows List of all Networks
	 * 
	 * @return List of Networks
	 */
	@ApiOperation(notes = "All Networks", value = "Shows output of all networks")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success.") })
	@GetMapping(value = "/network/get")
	public ResponseEntity<NetworkModel> getAllNetworks() {
		log.info("Request: allNetworks");
		return new ResponseEntity<>(networkService.getAllNetworks(), HttpStatus.OK);
	}

	@PostMapping("/network/save")
	public ResponseEntity<Network> saveNetwork(@RequestBody NetworkRequest networkRequest) {
		ResponseEntity<Network> output = null;
		Network netWork = networkService.save(networkRequest);
		if (netWork != null) {
			output = new ResponseEntity<>(netWork, HttpStatus.CREATED);
		} else {
			output = new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
		return output;
	}

}
