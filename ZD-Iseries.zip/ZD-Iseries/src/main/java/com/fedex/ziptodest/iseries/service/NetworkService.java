package com.fedex.ziptodest.iseries.service;

import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.model.NetworkModel;
import com.fedex.ziptodest.iseries.model.NetworkRequest;

public interface NetworkService {
	public NetworkModel getAllNetworks();	
	
	public Network save(NetworkRequest networkRequest);
}
