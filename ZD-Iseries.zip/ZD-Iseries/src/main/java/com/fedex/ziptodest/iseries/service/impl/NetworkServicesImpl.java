package com.fedex.ziptodest.iseries.service.impl;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.model.NetworkModel;
import com.fedex.ziptodest.iseries.model.NetworkRequest;
import com.fedex.ziptodest.iseries.repository.NetworkRepository;
import com.fedex.ziptodest.iseries.service.NetworkService;

@Service
public class NetworkServicesImpl implements NetworkService {

	@Autowired
	@Qualifier("networkRepository")
	private NetworkRepository networkRepository;
	
	@Autowired
	Environment environment; 
	
	private static Logger logs = LoggerFactory.getLogger(NetworkServicesImpl.class);

	
	@Override
	public NetworkModel getAllNetworks() {
		logs.debug("NetworkServicesImpl::getAllNetworks");
		NetworkModel networkModel = new NetworkModel();
		Set<String> networkSet = networkRepository.selectAllNetworks();
		
		if(CollectionUtils.isNotEmpty(networkSet)){			
			networkModel.setStatus("success");
			networkModel.setMessage("The network list has been generated successfully");
			networkModel.setData(networkSet);
		}else{
			networkModel.setMessage("failure");
			networkModel.setMessage("The network list ");
			networkModel.setData(null);
		}
		return networkModel;
	}

	@Override
	public Network save(NetworkRequest networkRequest) {
		Network network = new Network();
		network.setColocNum(networkRequest.getColocNum());
		network.setCreatedBy(networkRequest.getCreatedBy());
		network.setCreatedDate(LocalDate.now(ZoneOffset.UTC));
		network.setModelType(networkRequest.getModelType());
		network.setNetworkId(networkRequest.getNetwork());
		network.setRowId(networkRequest.getRowId());
		network.setTermNum(networkRequest.getTerminalNumber());
		Optional<Network> optNetwork = networkRepository.findById(network.getTermNum());
		if(optNetwork.isPresent()){
			return optNetwork.get();					
		}else{
			return networkRepository.save(network); 
		}		
	}
}
