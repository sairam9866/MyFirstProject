package com.fedex.ziptodest.iseries.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.iseries.model.CountryCode;
import com.fedex.ziptodest.iseries.model.Destination;
import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.model.StateProvince;
import com.fedex.ziptodest.iseries.repository.CountryCodeRepository;
import com.fedex.ziptodest.iseries.repository.DestinationRepository;
import com.fedex.ziptodest.iseries.repository.NetworkRepository;
import com.fedex.ziptodest.iseries.repository.StateProvinceRepository;
import com.fedex.ziptodest.iseries.utils.CsvReader;

@RunWith(SpringRunner.class)
public class EmbeddedServerPayloadServiceImplTest {

	@InjectMocks
	private EmbeddedServerPayloadServiceImpl embeddedServerPayloadService;
	
	@Mock
	DestinationRepository destinationRepository;

	@Mock
	NetworkRepository networkRepository;

	@Mock
	CountryCodeRepository countryCodeRepository;

	@Mock
	StateProvinceRepository stateProvinceRepository;

	@Mock
	CsvReader<Destination> destinationReader;

	@Mock
	CsvReader<Network> networkReader;

	@Mock
	CsvReader<CountryCode> countryCodeReader;

	@Mock
	CsvReader<StateProvince> stateProvinceReader;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void initTest(){		
		Mockito.doReturn(Collections.emptyList()).when(destinationReader).read(Destination.class, "destinations.csv");
		Mockito.doReturn(Collections.emptyList()).when(networkReader).read(Network.class, "networks.csv");
		Mockito.doReturn(Collections.emptyList()).when(countryCodeReader).read(CountryCode.class, "countryCodes.csv");
		Mockito.doReturn(Collections.emptyList()).when(stateProvinceReader).read(StateProvince.class, "stateProvinces.csv");		
		embeddedServerPayloadService.init();
		
		Destination destination = new Destination();
		destination.setTerminalNumber(1212);
				
		List<Destination> destinations = Arrays.asList(destination);
		Mockito.doReturn(destinations).when(destinationReader).read(Destination.class, "destinations.csv");
		
		Network network = new Network();
		network.setTermNum(1234L);
		List<Network> networks = Arrays.asList(network);
		Mockito.doReturn(networks).when(networkReader).read(Network.class, "networks.csv");
		
		CountryCode countryCode = new CountryCode();
		countryCode.setCyclcu(840);
		countryCode.setCycode("US");
		List<CountryCode> countryCodes = Arrays.asList(countryCode);
		Mockito.doReturn(countryCodes).when(countryCodeReader).read(CountryCode.class, "countryCodes.csv");
		
		StateProvince stateProvince = new StateProvince();
		stateProvince.setCntryc("CA");
		stateProvince.setSpName("Oratino");
		stateProvince.setStaPro("ON");
		List<StateProvince> stateProvinces = Arrays.asList(stateProvince);
		Mockito.doReturn(stateProvinces).when(stateProvinceReader).read(StateProvince.class, "stateProvinces.csv");		
		embeddedServerPayloadService.init();
		
		assertNotNull(stateProvinces);
	}
}
