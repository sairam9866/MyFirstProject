package com.fedex.ziptodest.iseries.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.fedex.ziptodest.iseries.model.Destination;

public class CsvReaderTest {


	@Test
	public void test(){
		CsvReader<Destination> reader1 = new CsvReader<>();
		
		CsvReader<Destination> reader2 = new CsvReader<>(Destination.class);
		
		List<Destination> destinations = reader1.read(Destination.class,"destinations.csv");
		
		List<Destination> emptyDestinations = reader1.read(Destination.class, "");
		
		List<Destination> destinations2 = reader2.read("destinations.csv");
		List<Destination> destinations3 = reader2.read("");
		
		assertFalse(destinations.isEmpty());
		assertFalse(destinations2.isEmpty());
		assertTrue(emptyDestinations.isEmpty());
		assertTrue(destinations3.isEmpty());
	}
}
