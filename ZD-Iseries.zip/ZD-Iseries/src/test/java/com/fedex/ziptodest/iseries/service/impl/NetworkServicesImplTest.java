package com.fedex.ziptodest.iseries.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.fedex.ziptodest.iseries.model.Network;
import com.fedex.ziptodest.iseries.model.NetworkModel;
import com.fedex.ziptodest.iseries.model.NetworkRequest;
import com.fedex.ziptodest.iseries.repository.NetworkRepository;

@RunWith(SpringRunner.class)
public class NetworkServicesImplTest {

	@InjectMocks
	private NetworkServicesImpl networkServicesImpl;

	@Mock
	private NetworkRepository networkRepository;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllNetorks_Positive() {

		Set<String> dataSet = new HashSet<String>();
		dataSet.add("FXGL");
		dataSet.add("FHDL");
		dataSet.add("FXG");
		dataSet.add("FHD");
		dataSet.add("FXSP");

		NetworkModel networkModel = new NetworkModel();
		networkModel.setData(dataSet);
		networkModel.setMessage("The message is getting success");
		networkModel.setStatus("success");
		Mockito.doReturn(dataSet).when(networkRepository).selectAllNetworks();
		networkServicesImpl.getAllNetworks();

		Mockito.doReturn(Collections.emptySet()).when(networkRepository).selectAllNetworks();
		networkServicesImpl.getAllNetworks();

		assertEquals("success", networkModel.getStatus());
		assertEquals("The message is getting success", networkModel.getMessage());
		assertTrue(networkModel.getData().contains("FXGL"));
		assertTrue(networkModel.getData().contains("FHDL"));
		assertTrue(networkModel.getData().contains("FXG"));
		assertTrue(networkModel.getData().contains("FXSP"));
		assertTrue(networkModel.getData().contains("FHD"));
	}

	@Test
	public void testGetAllNetorks_Negative() {

		Set<String> dataSet = new HashSet<String>();
		dataSet.add("FXGL");
		dataSet.add("FHDL");

		NetworkModel networkModel = new NetworkModel();
		networkModel.setData(dataSet);
		networkModel.setMessage("The message is getting success");
		networkModel.setStatus("success");
		Mockito.doReturn(dataSet).when(networkRepository).selectAllNetworks();

		networkServicesImpl.getAllNetworks();

		assertNotEquals("successs", networkModel.getStatus());
		assertNotEquals("The message is getting successs", networkModel.getMessage());
		assertTrue(networkModel.getData().contains("FXGL"));
		assertTrue(networkModel.getData().contains("FHDL"));
	}

	@Test
	public void testGetAllNetorks_DB_Positive() {

		Set<String> data = new HashSet<String>();
		data.add(null);

		NetworkModel networkModel = new NetworkModel();
		networkModel.setData(data);
		networkModel.setMessage("The message is Not getting success");
		networkModel.setStatus("failure");
		Mockito.doReturn(null).when(networkRepository).selectAllNetworks();
		networkServicesImpl.getAllNetworks();

		assertEquals("failure", networkModel.getStatus());
		assertEquals("The message is Not getting success", networkModel.getMessage());
		for (String network : networkModel.getData()) {
			assertEquals(null, network);
		}

	}

	@Test
	public void testGetAllNetorks_DB_Negative() {

		Set<String> networkSet = new HashSet<>();
		networkSet.add(null);

		NetworkModel networkModel = new NetworkModel();
		networkModel.setData(networkSet);
		networkModel.setMessage("The message is Not getting success");
		networkModel.setStatus("failure");
		Mockito.doReturn(null).when(networkRepository).selectAllNetworks();
		networkServicesImpl.getAllNetworks();

		assertNotEquals("failuree", networkModel.getStatus());
		assertNotEquals("The message is Not getting successs", networkModel.getMessage());
		assertFalse(networkModel.getData().contains("FXG"));
	}

	@Test
	public void testSave() {
		NetworkRequest networkRequest = new NetworkRequest();
		networkRequest.setColocNum(1234);
		networkRequest.setCreatedBy("TEST");
		networkRequest.setModelType("A");
		networkRequest.setNetwork("FXG");
		networkRequest.setRowId(0);
		networkRequest.setTerminalNumber(1111L);

		Network network = new Network();
		network.setColocNum(networkRequest.getColocNum());
		network.setCreatedBy(networkRequest.getCreatedBy());
		network.setModelType(networkRequest.getModelType());
		network.setNetworkId(networkRequest.getNetwork());
		network.setRowId(networkRequest.getRowId());
		network.setTermNum(networkRequest.getTerminalNumber());

		Optional<Network> optNetwork = Optional.of(network);
		Mockito.doReturn(optNetwork).when(networkRepository).findById(network.getTermNum());
		Network output = networkServicesImpl.save(networkRequest);		
		assertEquals(network, output);

		optNetwork = Optional.empty();
		Mockito.doReturn(optNetwork).when(networkRepository).findById(network.getTermNum());
		Mockito.doReturn(network).when(networkRepository).save(network);
		output = networkServicesImpl.save(networkRequest);
		assertEquals(network, output);
	}
}