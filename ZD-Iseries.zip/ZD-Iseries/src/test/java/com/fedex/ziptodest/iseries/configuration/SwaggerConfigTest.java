package com.fedex.ziptodest.iseries.configuration;

import static org.junit.Assert.assertNotNull;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class SwaggerConfigTest {
	@Test
	public void testISeriesApi() {
		SwaggerConfig swaggerConfig = new SwaggerConfig();
		assertNotNull(null, swaggerConfig.iSeriesApi());
	}

	@Test
	@SuppressWarnings("all")
	public void testPostPaths() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		SwaggerConfig swaggerConfig = new SwaggerConfig();
		Method method=SwaggerConfig.class.getDeclaredMethod("postPaths", null);
		method.setAccessible(true);
		Object returnValue=(Object)method.invoke(swaggerConfig, null);
		assertNotNull(null, returnValue);
	}
	@Test
	@SuppressWarnings("all")
	public void testApiInfo() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		SwaggerConfig swaggerConfig = new SwaggerConfig();
		Method method=SwaggerConfig.class.getDeclaredMethod("apiInfo", null);
		method.setAccessible(true);
		Object returnValue=(Object)method.invoke(swaggerConfig, null);
		assertNotNull(null, returnValue);
	}
	@Test
	@SuppressWarnings("all")
	public void testStateProvincePaths() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		SwaggerConfig swaggerConfig = new SwaggerConfig();
		Method method=SwaggerConfig.class.getDeclaredMethod("stateProvincePaths", null);
		method.setAccessible(true);
		Object returnValue=(Object)method.invoke(swaggerConfig, null);
		assertNotNull(null, returnValue);
	}

}
