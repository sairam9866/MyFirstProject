package com.fedex.ziptodest.iseries.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

import org.junit.Test;

public class ValidationUtilTest {

	@Test
	public void isValidDestination() {
		assertTrue(ValidationUtil.isValidDestination("1243"));
	}

	@Test
	public void isValidDestination_Negative() {
		assertFalse(ValidationUtil.isValidDestination("12434"));
		assertFalse(ValidationUtil.isValidDestination(""));
		assertFalse(ValidationUtil.isValidDestination("abcd"));
		assertFalse(ValidationUtil.isValidDestination("0"));
	}
	
	@Test
	public void tesPrivateConstructor() throws Exception {
		Constructor<ValidationUtil> constructor = ValidationUtil.class.getDeclaredConstructor();
		assertNotEquals(1,Modifier.isPrivate(constructor.getModifiers()));
		constructor.setAccessible(true);
		constructor.newInstance();
	}
}